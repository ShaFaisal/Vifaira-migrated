import express from "express";
import cors from "cors";
import helmet from "helmet";
import "dotenv/config";
import studentRouter from "./modules/student/student.routes.js";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGINS?.split(",").map(x => x.trim()) || [] }));
app.use(express.json({ limit: "2mb" }));
app.get("/api/health", (_, res) => res.json({ success: true, status: "ok", version: "1.7.0" }));
app.use("/api/student", studentRouter);

app.listen(Number(process.env.PORT || 5000), () => {
});
