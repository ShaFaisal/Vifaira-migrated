import { Router } from 'express';
import * as controller from './home.controller.js';
const router = Router();
router.post("/index", controller.index);
router.post("/login", controller.login);
router.post("/forgotpassword", controller.forgotPassword);
export default router;
