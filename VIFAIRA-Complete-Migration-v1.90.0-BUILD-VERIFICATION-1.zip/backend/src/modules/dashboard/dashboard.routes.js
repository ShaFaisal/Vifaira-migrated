import { Router } from 'express';
import * as controller from './dashboard.controller.js';
const router = Router();
router.post("/getuserdashord", controller.getUserDashord);
router.post("/getdashboardwidgetdata", controller.getDashboardWidgetData);
router.post("/getprofile", controller.getProfile);
export default router;
