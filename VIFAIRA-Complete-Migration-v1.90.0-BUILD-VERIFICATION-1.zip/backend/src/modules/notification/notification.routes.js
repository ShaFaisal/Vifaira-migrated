import { Router } from 'express';
import * as controller from './notification.controller.js';
const router = Router();
router.post("/notificationhubnoti", controller.notificationHubNoti);
router.post("/notificationhubgroup", controller.notificationHubGroup);
router.post("/markholiday", controller.markHoliday);
export default router;
