export async function notificationHubNoti(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function notificationHubGroup(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function markHoliday(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}