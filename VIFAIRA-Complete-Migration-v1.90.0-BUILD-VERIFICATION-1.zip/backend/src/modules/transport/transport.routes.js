import { Router } from 'express';
import * as controller from './transport.controller.js';
const router = Router();
router.post("/index", controller.index);
router.post("/getlist", controller.getList);
router.post("/get", controller.get);
router.post("/save", controller.save);
export default router;
