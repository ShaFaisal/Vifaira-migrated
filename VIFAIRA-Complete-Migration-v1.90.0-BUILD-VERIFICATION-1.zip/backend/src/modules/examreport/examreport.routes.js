import { Router } from 'express';
import * as controller from './examreport.controller.js';
const router = Router();
router.post("/reportcard", controller.reportCard);
router.post("/printreportcard", controller.printReportCard);
router.post("/gradesheet", controller.gradeSheet);
router.post("/studentreport", controller.studentReport);
router.post("/classwiserptsetup", controller.classWiseRptSetup);
export default router;
