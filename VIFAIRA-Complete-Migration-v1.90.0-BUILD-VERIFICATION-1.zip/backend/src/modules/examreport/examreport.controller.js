export async function reportCard(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function printReportCard(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function gradeSheet(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function studentReport(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function classWiseRptSetup(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}