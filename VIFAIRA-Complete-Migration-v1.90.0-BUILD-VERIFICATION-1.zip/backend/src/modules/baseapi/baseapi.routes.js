import { Router } from 'express';
import * as controller from './baseapi.controller.js';
const router = Router();

export default router;
