import { Router } from 'express';
import * as controller from './feereport.controller.js';
const router = Router();
router.post("/duesreport", controller.duesReport);
router.post("/studentledger", controller.studentLedger);
router.post("/miscreport", controller.miscReport);
router.post("/dailycollection", controller.dailyCollection);
router.post("/receiptreport", controller.receiptReport);
export default router;
