import { Router } from 'express';
import * as controller from './auth.controller.js';
const router = Router();
router.post("/login", controller.login);
router.post("/resetpassword", controller.resetPassword);
router.post("/updateloginstatus", controller.updateLoginStatus);
router.post("/logout", controller.logout);
router.post("/checkauth", controller.checkAuth);
export default router;
