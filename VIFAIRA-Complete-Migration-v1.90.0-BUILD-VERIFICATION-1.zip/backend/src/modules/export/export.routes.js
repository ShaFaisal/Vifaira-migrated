import { Router } from 'express';
import * as controller from './export.controller.js';
const router = Router();
router.post("/download", controller.download);
export default router;
