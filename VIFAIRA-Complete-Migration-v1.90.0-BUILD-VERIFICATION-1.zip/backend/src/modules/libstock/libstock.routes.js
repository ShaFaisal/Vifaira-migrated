import { Router } from 'express';
import * as controller from './libstock.controller.js';
const router = Router();
router.post("/periodsetup", controller.periodSetup);
router.post("/stockverification", controller.stockVerification);
router.post("/stockreport", controller.stockReport);
export default router;
