export async function periodSetup(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function stockVerification(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function stockReport(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}