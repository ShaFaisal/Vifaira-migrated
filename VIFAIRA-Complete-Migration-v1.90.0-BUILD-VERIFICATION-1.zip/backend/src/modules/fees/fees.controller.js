export async function installmentDateFees(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function saveFeeStrecture(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function getFeeStrecture(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function loadDefaultFeeStructData(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function addDefaultFeeStructure(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function applyDue(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function saveApplyDue(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function relaxation(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function saveRelaxation(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function searchRelaxRecord(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function cancelRelax(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function receiptSummary(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function createDue(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function createReceipt(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function getCancelReceipt(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function getReceptMore(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function cancelReceipt(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function printReceipt(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function getRefundDetails(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function refundSaveRequest(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function refundCancel(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function printRefund(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}