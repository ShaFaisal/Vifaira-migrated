import { Router } from 'express';
import * as controller from './libperiodicals.controller.js';
const router = Router();
router.post("/magazinesubscription", controller.magazineSubscription);
router.post("/magazinejournal", controller.magazineJournal);
router.post("/newspapersetup", controller.newsPaperSetup);
router.post("/newspaperentry", controller.newsPaperEntry);
export default router;
