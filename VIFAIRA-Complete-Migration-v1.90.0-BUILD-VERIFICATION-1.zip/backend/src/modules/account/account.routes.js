import { Router } from 'express';
import * as controller from './account.controller.js';
const router = Router();
router.post("/ledger", controller.ledger);
router.post("/vouchermaster", controller.voucherMaster);
router.post("/vouchersearch", controller.voucherSearch);
router.post("/voucherentry", controller.voucherEntry);
router.post("/voucherupdate", controller.voucherUpdate);
export default router;
