import { Router } from 'express';
import * as controller from './accountreport.controller.js';
const router = Router();
router.post("/daybook", controller.daybook);
router.post("/ledgerstatement", controller.ledgerStatement);
router.post("/trialbalance", controller.trialBalance);
router.post("/balancesheet", controller.balanceSheet);
export default router;
