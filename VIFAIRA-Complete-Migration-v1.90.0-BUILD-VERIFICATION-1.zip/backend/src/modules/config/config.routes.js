import { Router } from 'express';
import * as controller from './config.controller.js';
const router = Router();
router.post("/getwebconfig", controller.getWebConfig);
router.post("/smtpconfig", controller.smtpConfig);
router.post("/userrolemanage", controller.userRoleManage);
export default router;
