import { Router } from 'express';
import * as controller from './configsetting.controller.js';
const router = Router();
router.post("/userrolemaping", controller.userRoleMaping);
router.post("/index", controller.index);
export default router;
