import { Router } from 'express';
import * as controller from './libraryreport.controller.js';
const router = Router();
router.post("/opac", controller.oPAC);
router.post("/issuereturn", controller.issueReturn);
router.post("/bookbinding", controller.bookBinding);
router.post("/bookdetails", controller.bookDetails);
router.post("/fine", controller.fine);
export default router;
