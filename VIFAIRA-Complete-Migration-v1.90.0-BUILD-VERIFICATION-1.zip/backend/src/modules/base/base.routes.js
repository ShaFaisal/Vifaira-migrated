import { Router } from 'express';
import * as controller from './base.controller.js';
const router = Router();
router.post("/isdropdownloaded", controller.isDropdownLoaded);
router.post("/getdropdownlist", controller.getDropdownList);
router.post("/refreshdropdowns", controller.refreshDropdowns);
router.post("/getcachestats", controller.getCacheStats);
router.post("/clearcache", controller.clearCache);
export default router;
