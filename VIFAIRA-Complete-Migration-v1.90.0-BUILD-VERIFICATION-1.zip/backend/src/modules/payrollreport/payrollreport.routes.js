import { Router } from 'express';
import * as controller from './payrollreport.controller.js';
const router = Router();
router.post("/index", controller.index);
router.post("/salarydetails", controller.salaryDetails);
router.post("/empdetails", controller.empDetails);
router.post("/salaryslip", controller.salarySlip);
router.post("/headwisereport", controller.headwiseReport);
export default router;
