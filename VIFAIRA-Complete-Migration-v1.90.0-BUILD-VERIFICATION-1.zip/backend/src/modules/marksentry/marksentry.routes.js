import { Router } from 'express';
import * as controller from './marksentry.controller.js';
const router = Router();
router.post("/subjectwisemarksentrty", controller.subjectWiseMarksEntrty);
router.post("/studentwisemarksentry", controller.studentWiseMarksEntry);
router.post("/userpermissionformarksentry", controller.userPermissionForMarksEntry);
router.post("/remarksentry", controller.remarksEntry);
router.post("/assignmentmaster", controller.assignmentMaster);
export default router;
