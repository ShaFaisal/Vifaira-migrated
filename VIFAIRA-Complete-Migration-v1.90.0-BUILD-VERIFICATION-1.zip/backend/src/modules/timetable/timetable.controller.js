export async function manage(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function timeTableEntryManage(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}

export async function timeTableSubstitutionManage(req, res) {
  return res.status(501).json({ok:false,error:"NOT_IMPLEMENTED",migrationStatus:"source-implementation-required"});
}