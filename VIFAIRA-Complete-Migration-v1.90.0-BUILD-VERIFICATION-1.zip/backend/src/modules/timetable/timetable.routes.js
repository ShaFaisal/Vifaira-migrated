import { Router } from 'express';
import * as controller from './timetable.controller.js';
const router = Router();
router.post("/manage", controller.manage);
router.post("/timetableentrymanage", controller.timeTableEntryManage);
router.post("/timetablesubstitutionmanage", controller.timeTableSubstitutionManage);
export default router;
