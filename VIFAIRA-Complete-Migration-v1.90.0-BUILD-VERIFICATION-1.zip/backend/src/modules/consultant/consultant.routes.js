import { Router } from 'express';
import * as controller from './consultant.controller.js';
const router = Router();
router.post("/consultantmaster", controller.consultantMaster);
router.post("/counselormaster", controller.counselorMaster);
export default router;
