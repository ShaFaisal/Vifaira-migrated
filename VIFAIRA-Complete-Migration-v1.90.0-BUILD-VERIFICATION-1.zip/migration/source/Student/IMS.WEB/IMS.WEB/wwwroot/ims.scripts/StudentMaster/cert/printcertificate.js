﻿let printStudentTableInstance = null;
let printInfoModalInstance = null;
let certificatePrintPreviewModalInstance = null;
let historyModalInstance = null;

let currentPrintRow = null;
let currentPrintHtml = '';
let currentPrintStudentAutoData = null;
let isPrintListLoading = false;
let isPrintSaving = false;
let isDeleteCertificateProcessing = false;

$(function () {
    initPrintCertificatePage();
});

function initPrintCertificatePage() {
    initPrintValidation();
    initPrintEmptyState();
    bindPrintEvents();

    setTimeout(function () {
        fetchPrintStudentList();
    }, 300);
}

function bindPrintEvents() {
    $('#btnRefreshPrintList').off('click').on('click', function (e) {
        e.preventDefault();
        fetchPrintStudentList();
        return false;
    });

    $('#PrintSchoolID, #PrintSessionId, #PrintCourseId, #PrintBranchId, #PrintCertificateType')
        .off('change.printlist')
        .on('change.printlist', function () {
            fetchPrintStudentList();
        });

    $('#txtSearchPrint')
        .off('keyup.printsearch')
        .on('keyup.printsearch', debounce(function () {
            fetchPrintStudentList();
        }, 400));

    $(document).off('click', '.btn-open-print-info').on('click', '.btn-open-print-info', async function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $btn = $(this);

        const row = {
            certificateID: $btn.data('certificateid') || 0,
            studentID: $btn.data('studentid') || '',
            admissionNo: $btn.data('admissionno') || '',
            studentName: $btn.data('studentname') || '',
            fatherName: $btn.data('fathername') || '',
            motherName: $btn.data('mothername') || '',
            institute: $btn.data('institute') || '',
            session: $btn.data('session') || '',
            course: $btn.data('course') || '',
            branch: $btn.data('branch') || '',
            className: $btn.data('classname') || '',
            branchName: $btn.data('branchname') || '',
            sessionName: $btn.data('sessionname') || '',
            instituteName: $btn.data('institutename') || '',
            photo: $btn.data('photo') || '',
            type: ($btn.data('type') || '').toString().toUpperCase(),
            printCount: parseInt($btn.data('printcount') || 0, 10),
            issueDate: $btn.data('issuedate') || '',
            printedDate: $btn.data('printeddate') || '',
            remark: $btn.data('remark') || ''
        };

        await openPrintInfoModal(row);
        return false;
    });

    $(document).off('click', '.btn-delete-certificate').on('click', '.btn-delete-certificate', async function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $btn = $(this);

        const row = {
            certificateID: $btn.data('certificateid') || 0,
            studentID: $btn.data('studentid') || '',
            admissionNo: $btn.data('admissionno') || '',
            studentName: $btn.data('studentname') || '',
            institute: $btn.data('institute') || '',
            session: $btn.data('session') || '',
            course: $btn.data('course') || '',
            branch: $btn.data('branch') || '',
            type: ($btn.data('type') || '').toString().toUpperCase()
        };

        await deleteCertificateFromPrintList(row);
        return false;
    });

    $(document).off('click', '.btn-certificate-history').on('click', '.btn-certificate-history', async function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $btn = $(this);

        const meta = {
            studentId: $btn.data('studentid') || '',
            institute: $btn.data('institute') || '',
            session: $btn.data('session') || '',
            course: $btn.data('course') || '',
            branch: $btn.data('branch') || '',
            studentName: $btn.data('studentname') || ''
        };

        await openPrintCertificateHistory(meta);
        return false;
    });

    $('#btnConfirmCertificatePrint').off('click').on('click', async function (e) {
        e.preventDefault();
        e.stopPropagation();

        if (isPrintSaving) return false;

        await confirmAndPrintCertificate();
        return false;
    });

    $('#btnPrintCertificateDoc').off('click').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        printCertificatePreviewContent();
        return false;
    });

    $('#certificatePrintInfoModal').off('hidden.bs.modal').on('hidden.bs.modal', function () {
        resetPrintInfoModal();
    });

    $('#certificatePrintPreviewModal').off('hidden.bs.modal').on('hidden.bs.modal', function () {
        $('#certificatePrintPreviewContainer').html(`
            <div class="d-flex align-items-center justify-content-center py-5 text-muted">
                No preview loaded
            </div>
        `);
    });

    $('#txtCertificatePrintRemark').off('input').on('input', function () {
        const val = ($(this).val() || '').trim();
        if (val) {
            $(this).removeClass('is-invalid');
            $('#printRemarkValidation').addClass('d-none');
        }
    });
}

function initPrintValidation() {
    const $form = $('#form_printCertificate');

    if (!$form.length) return;

    if ($form.data('validator')) {
        $form.removeData('validator');
        $form.removeData('unobtrusiveValidation');
    }

    $form.validate({
        ignore: [],
        rules: {
            PrintSchoolID: { required: true },
            PrintSessionId: { required: true },
            PrintCertificateType: { required: true }
        },
        messages: {
            PrintSchoolID: 'Please select Institute',
            PrintSessionId: 'Please select Session',
            PrintCertificateType: 'Please select Certificate Type'
        },
        errorClass: 'is-invalid',
        validClass: 'is-valid',
        errorElement: 'div',
        errorPlacement: function (error, element) {
            error.addClass('invalid-feedback');
            if (element.parent('.input-group').length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass('is-invalid').removeClass('is-valid');
        },
        unhighlight: function (element) {
            $(element).removeClass('is-invalid').addClass('is-valid');
        }
    });
}

function initPrintEmptyState() {
    $('#printTableLayout').html(`
        <div class="text-center py-4">
            <div class="mb-2">
                <span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle px-3 py-2">
                    <i class="ti ti-printer me-1"></i> Print Certificate
                </span>
            </div>
            <h5 class="text-muted fw-semibold mt-2">No Data Found</h5>
            <p class="text-muted mb-2">Select filters to load issued certificate records</p>
            <div class="d-inline-flex align-items-center gap-2">
                <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle px-3 py-2">
                    <i class="ti ti-bolt me-1"></i> Auto search enabled
                </span>
            </div>
        </div>
    `);

    $('#totalPrintEntries').text('0');
    setPrintLastUpdated();
}

function showPrintTableLoading() {
    $('#printTableLayout').html(`
        <div class="border rounded-3 bg-light-subtle">
            <div class="d-flex flex-column align-items-center justify-content-center py-5">
                <div class="spinner-border text-primary mb-3" role="status" style="width:2.2rem;height:2.2rem;">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <h6 class="mb-1 text-dark fw-semibold">Loading certificate records...</h6>
                <div class="small text-muted">Please wait while data is being fetched</div>
            </div>
        </div>
    `);

    $('#totalPrintEntries').text('0');
}

function showPrintTableSkeleton() {
    let skeletonRows = '';

    for (let i = 0; i < 5; i++) {
        skeletonRows += `
            <tr>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-10"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-12"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-10"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-7"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-7"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-4"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-8"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-10"></span></div></td>
                <td><div class="placeholder-glow"><span class="placeholder col-4"></span></div></td>
            </tr>
        `;
    }

    $('#printTableLayout').html(`
        <div class="table-responsive">
            <table class="table table-bordered table-sm table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Sr No</th>
                        <th>Adm No</th>
                        <th>Reg No</th>
                        <th>Roll No</th>
                        <th>Student Name</th>
                        <th>Father Name</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Session</th>
                        <th>Status</th>
                        <th>Type</th>
                        <th>Issue Date</th>
                        <th>Print</th>
                        <th>Last Printed</th>
                        <th>Remark</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${skeletonRows}
                </tbody>
            </table>
        </div>
    `);

    $('#totalPrintEntries').text('0');
}

async function fetchPrintStudentList() {
    if (isPrintListLoading) return;

    const institute = $('#PrintSchoolID').val() || '';
    const session = $('#PrintSessionId').val() || '';
    const type = ($('#PrintCertificateType').val() || '').trim().toUpperCase();

    if (!institute || !session || !type) {
        initPrintEmptyState();
        return;
    }

    const $form = $('#form_printCertificate');
    if ($form.length && !$form.valid()) return;

    const $btn = $('#btnRefreshPrintList');
    const oldHtml = $btn.html();

    isPrintListLoading = true;
    $btn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Loading...`);

    showPrintTableSkeleton();

    try {
        const parms = {
            Institute: institute,
            Session: session,
            Course: $('#PrintCourseId').val() || '',
            Branch: $('#PrintBranchId').val() || '',
            txtSearch: $('#txtSearchPrint').val() || '',
            Type: type,
            mode: 'GetCertificatePrintStudentList'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const data = normalizeResultArray(res);

        if (Array.isArray(data) && data.length > 0) {
            renderPrintStudentTable(data);
            $('#totalPrintEntries').text(data.length);
        } else {
            initPrintEmptyState();
        }

        setPrintLastUpdated();
    } catch (error) {
        console.error(error);
        initPrintEmptyState();
        notify('danger', 'Unable to load print list');
    } finally {
        isPrintListLoading = false;
        $btn.prop('disabled', false).html(oldHtml);
    }
}

function renderPrintStudentTable(data) {
    const rows = data.map((item, index) => {
        const certificateID = getValueByKeyContains(item, ['certificateid', 'id'], 0);
        const admissionNo = getValueByKeyContains(item, ['admissionno', 'admno', 'stu_id', 'studentid'], '');
        const regNo = getValueByKeyContains(item, ['adm_regno', 'regno', 'registrationno'], '') || '-';
        const rollNo = getValueByKeyContains(item, ['adm_rollno', 'rollno'], '') || '-';

        const rawStudentName = getValueByKeyContains(item, ['studentname', 'sname'], '');
        const studentName = rawStudentName && String(rawStudentName).trim() !== '' ? rawStudentName : admissionNo;

        const rawStudentId = getValueByKeyContains(item, ['studentid', 'stu_id'], '');
        const studentId = rawStudentId && String(rawStudentId).trim() !== '' ? rawStudentId : admissionNo;

        const fatherName = getValueByKeyContains(item, ['fathername'], '') || '-';
        const motherName = getValueByKeyContains(item, ['mothername'], '') || '-';
        const courseName = getValueByKeyContains(item, ['course_name', 'coursename'], '') || '-';
        const branchName = getValueByKeyContains(item, ['branch_name', 'branchname'], '') || '-';

        const batchName = getValueByKeyContains(item, ['batch_name', 'session_name'], '');
        const sessionIdValue = getValueByKeyContains(item, ['session_id', 'session'], '');
        const sessionName = batchName && String(batchName).trim() !== '' ? batchName : (sessionIdValue || '-');

        const instituteName = getValueByKeyContains(item, ['institutename'], '') || '-';
        const instituteId = getValueByKeyContains(item, ['institute_id', 'institute'], '') || $('#PrintSchoolID').val() || '';
        const sessionId = sessionIdValue || $('#PrintSessionId').val() || '';
        const courseId = getValueByKeyContains(item, ['course_id', 'course'], '') || $('#PrintCourseId').val() || '';
        const branchId = getValueByKeyContains(item, ['branch_id', 'branch'], '') || $('#PrintBranchId').val() || '';

        const status = getValueByKeyContains(item, ['admissionstatus'], '') || '-';
        const certificateType = (getValueByKeyContains(item, ['certificatetype', 'type'], '') || '').toUpperCase();
        const remark = getValueByKeyContains(item, ['remark', 'issueremark'], '') || '-';
        const issueDate = formatDisplayDateTime(getValueByKeyContains(item, ['issuedate'], ''));
        const printCount = parseInt(getValueByKeyContains(item, ['printcount'], 0) || 0, 10);
        const printedDate = formatDisplayDateTime(getValueByKeyContains(item, ['printeddate'], ''));
        const studentPhoto = getValueByKeyContains(item, ['picture'], '') || '';

        const actionHtml = `
            <div class="dropdown text-center">
                <button class="btn btn-outline-secondary btn-sm px-2 py-1"
                        type="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                        title="Actions">
                    <i class="ti ti-dots-vertical"></i>
                </button>

                <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                    <li>
                        <button type="button"
                                class="dropdown-item btn-open-print-info"
                                data-certificateid="${escapeHtml(String(certificateID))}"
                                data-studentid="${escapeHtml(studentId)}"
                                data-admissionno="${escapeHtml(admissionNo)}"
                                data-studentname="${escapeHtml(studentName)}"
                                data-fathername="${escapeHtml(fatherName)}"
                                data-mothername="${escapeHtml(motherName)}"
                                data-institute="${escapeHtml(instituteId)}"
                                data-session="${escapeHtml(sessionId)}"
                                data-course="${escapeHtml(courseId)}"
                                data-branch="${escapeHtml(branchId)}"
                                data-classname="${escapeHtml(courseName)}"
                                data-branchname="${escapeHtml(branchName)}"
                                data-sessionname="${escapeHtml(sessionName)}"
                                data-institutename="${escapeHtml(instituteName)}"
                                data-photo="${escapeHtml(studentPhoto)}"
                                data-type="${escapeHtml(certificateType)}"
                                data-printcount="${escapeHtml(String(printCount))}"
                                data-issuedate="${escapeHtml(issueDate)}"
                                data-printeddate="${escapeHtml(printedDate)}"
                                data-remark="${escapeHtml(remark)}">
                            <i class="ti ti-printer me-2 text-primary"></i> Print
                        </button>
                    </li>

                    <li>
                        <button type="button"
                                class="dropdown-item btn-certificate-history"
                                data-studentid="${escapeHtml(studentId)}"
                                data-institute="${escapeHtml(instituteId)}"
                                data-session="${escapeHtml(sessionId)}"
                                data-course="${escapeHtml(courseId)}"
                                data-branch="${escapeHtml(branchId)}"
                                data-studentname="${escapeHtml(studentName)}">
                            <i class="ti ti-history me-2 text-info"></i> History
                        </button>
                    </li>

                    <li><hr class="dropdown-divider my-1"></li>

                    <li>
                        <button type="button"
                                class="dropdown-item text-danger btn-delete-certificate"
                                data-certificateid="${escapeHtml(String(certificateID))}"
                                data-studentid="${escapeHtml(studentId)}"
                                data-admissionno="${escapeHtml(admissionNo)}"
                                data-studentname="${escapeHtml(studentName)}"
                                data-institute="${escapeHtml(instituteId)}"
                                data-session="${escapeHtml(sessionId)}"
                                data-course="${escapeHtml(courseId)}"
                                data-branch="${escapeHtml(branchId)}"
                                data-type="${escapeHtml(certificateType)}">
                            <i class="ti ti-trash me-2"></i> Delete
                        </button>
                    </li>
                </ul>
            </div>
        `;

        return [
            `<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle rounded-pill">${index + 1}</span>`,
            `<span class="fw-semibold text-dark">${escapeHtml(admissionNo || '-')}</span>`,
            `<span class="text-dark">${escapeHtml(regNo)}</span>`,
            `<span class="text-dark">${escapeHtml(rollNo)}</span>`,
            `<div class="fw-semibold text-dark">${escapeHtml(studentName || '-')}</div>`,
            `<div class="text-dark">${escapeHtml(fatherName)}</div>`,
            `<span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle rounded-pill">${escapeHtml(courseName)}</span>`,
            `<span class="badge bg-success-subtle text-success-emphasis border border-success-subtle rounded-pill">${escapeHtml(branchName)}</span>`,
            `<span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle rounded-pill">${escapeHtml(sessionName)}</span>`,
            `<span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle rounded-pill">${escapeHtml(status)}</span>`,
            `<span class="badge bg-info-subtle text-info-emphasis border border-info-subtle rounded-pill">${escapeHtml(certificateType || '-')}</span>`,
            `<span class="small text-dark">${escapeHtml(issueDate || '-')}</span>`,
            `<span class="badge bg-success-subtle text-success-emphasis border border-success-subtle rounded-pill">${escapeHtml(String(printCount))}</span>`,
            `<span class="small text-dark">${escapeHtml(printedDate || '-')}</span>`,
            `<span class="small text-dark">${escapeHtml(remark)}</span>`,
            actionHtml
        ];
    });

    $('#printTableLayout').html(`
        <div class="table-responsive">
            <table class="table table-bordered table-sm table-hover mb-0 align-middle" id="printStudentTable"></table>
        </div>
    `);

    if ($.fn.DataTable.isDataTable('#printStudentTable')) {
        $('#printStudentTable').DataTable().destroy();
        $('#printStudentTable').empty();
    }

    printStudentTableInstance = $('#printStudentTable').DataTable({
        data: rows,
        paging: true,
        lengthChange: false,
        searching: false,
        ordering: false,
        info: true,
        autoWidth: false,
        scrollX: true,
        destroy: true,
        pageLength: 10,
        columnDefs: [
            { targets: -1, className: 'text-center', width: '95px' }
        ],
        columns: [
            { title: 'Sr No' },
            { title: 'Adm No' },
            { title: 'Reg No' },
            { title: 'Roll No' },
            { title: 'Student Name' },
            { title: 'Father Name' },
            { title: 'Class' },
            { title: 'Section' },
            { title: 'Session' },
            { title: 'Status' },
            { title: 'Type' },
            { title: 'Issue Date' },
            { title: 'Print' },
            { title: 'Last Printed' },
            { title: 'Remark' },
            { title: 'Action' }
        ]
    });
}

async function openPrintInfoModal(row) {
    try {
        resetPrintInfoModal();
        currentPrintRow = row;
        currentPrintHtml = '';
        currentPrintStudentAutoData = null;

        fillPrintStudentCardFromRow(row);

        const modalEl = document.getElementById('certificatePrintInfoModal');
        if (!modalEl) {
            notify('warning', 'Print popup not available on page');
            return;
        }

        if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
            notify('danger', 'Bootstrap modal not loaded');
            return;
        }

        printInfoModalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
        printInfoModalInstance.show();

        await loadPrintStudentAutoData(row);
        await loadPrintCertificateData(row);
    } catch (error) {
        console.error(error);
        notify('danger', 'Unable to load print details');
    }
}

function fillPrintStudentCardFromRow(row) {

    $('#printInfoStudentName').text(row.studentName || '-');
    $('#printInfoStudentID').text(row.studentID || '-');
    $('#printInfoAdmissionNo').text(row.admissionNo || '-');
    $('#printInfoFatherName').text(row.fatherName || '-');
    $('#printInfoMotherName').text(row.motherName || '-');
    $('#printInfoCourse').text(row.className || '-');
    $('#printInfoBranch').text(row.branchName || '-');
    $('#printInfoSession').text(row.sessionName || '-');
    $('#printInfoIssueDate').text(row.issueDate || '-');
    $('#printInfoPrintCount').text(row.printCount || 0);
    $('#printInfoPrintedDate').text(row.printedDate || '-');
    $('#printInfoIssueRemark').text(row.remark || '-');
    $('#printInfoCertificateType').text(formatCertificateType(row.type || '-'));
    setPrintStudentPhotoSafe(row.picture || '');
}

async function loadPrintStudentAutoData(meta) {
    currentPrintStudentAutoData = null;

    try {
        const parms = {
            StudID: meta.studentID || meta.admissionNo || '',
            StudentID: meta.studentID || meta.admissionNo || '',
            Institute: meta.institute || $('#PrintSchoolID').val() || '',
            Batch: meta.session || $('#PrintSessionId').val() || '',
            Session: meta.session || $('#PrintSessionId').val() || '',
            Course: meta.course || $('#PrintCourseId').val() || '',
            Branch: meta.branch || $('#PrintBranchId').val() || '',
            mode: 'GetStudentSearchForTC'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const data = normalizeResultArray(res);

        if (Array.isArray(data) && data.length > 0) {
            currentPrintStudentAutoData = data[0];
            applyPrintStudentAutoData(currentPrintStudentAutoData, meta);
        }
    } catch (error) {
        console.error(error);
    }
}

function applyPrintStudentAutoData(data, meta) {
    const setText = (selector, value, fallback = '-') => {
        const finalVal = (value !== undefined && value !== null && String(value).trim() !== '') ? value : fallback;
        $(selector).text(finalVal);
    };

    setText('#printInfoStudentName', getValueByKeyContains(data, ['studentname', 'sname'], meta.studentName || '-'));
    setText('#printInfoStudentID', getValueByKeyContains(data, ['studentid', 'stu_id'], meta.studentID || meta.admissionNo || '-'));
    setText('#printInfoAdmissionNo', getValueByKeyContains(data, ['admno', 'admissionno', 'studentid'], meta.admissionNo || meta.studentID || '-'));
    setText('#printInfoFatherName', getValueByKeyContains(data, ['fathername'], meta.fatherName || '-'));
    setText('#printInfoMotherName', getValueByKeyContains(data, ['mothername'], meta.motherName || '-'));
    setText('#printInfoCourse', getValueByKeyContains(data, ['course_name', 'coursename'], meta.className || '-'));
    setText('#printInfoBranch', getValueByKeyContains(data, ['branch_name', 'branchname'], meta.branchName || '-'));
    setText('#printInfoSession', getValueByKeyContains(data, ['session_name', 'batch_name'], meta.sessionName || '-'));

    const picture = getValueByKeyContains(data, ['picture'], meta.photo || '');
    setPrintStudentPhotoSafe(picture);
}

async function loadPrintCertificateData(row) {
    const $btn = $('#btnConfirmCertificatePrint');
    const oldHtml = $btn.html();

    $btn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Loading...`);

    try {
        const parms = {
            Institute: row.institute || '',
            Session: row.session || '',
            Course: row.course || '',
            Branch: row.branch || '',
            StudentID: row.studentID || row.admissionNo || '',
            Type: (row.type || '').toUpperCase(),
            mode: 'GetCertificateForPrint'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        bindPrintCertificateData(res, row);
    } catch (error) {
        console.error(error);
    } finally {
        $btn.prop('disabled', false).html(oldHtml);
    }
}

function bindPrintCertificateData(data, row) {
    $('#printInfoCertificateType').text(formatCertificateType(getValueByKeyContains(data, ['certificatetype'], row.type || '-')));
    $('#printInfoIssueDate').text(formatDisplayDateTime(getValueByKeyContains(data, ['issuedate'], row.issueDate || '')) || '-');
    $('#printInfoPrintCount').text(parseInt(getValueByKeyContains(data, ['printcount'], row.printCount || 0) || 0, 10));
    $('#printInfoPrintedDate').text(formatDisplayDateTime(getValueByKeyContains(data, ['printeddate'], row.printedDate || '')) || '-');
    $('#printInfoIssueRemark').text(getValueByKeyContains(data, ['issueremark', 'remark'], row.remark || '-') || '-');

    const printRemark = getValueByKeyContains(data, ['printremark'], '');
    $('#txtCertificatePrintRemark').val(printRemark || '');

    const picture = getValueByKeyContains(data, ['picture'], row.photo || '');
    setPrintStudentPhotoSafe(picture);
}

async function confirmAndPrintCertificate() {
    if (isPrintSaving || !currentPrintRow) return;

    const remark = ($('#txtCertificatePrintRemark').val() || '').trim();

    if (!remark) {
        $('#txtCertificatePrintRemark').addClass('is-invalid');
        $('#printRemarkValidation').removeClass('d-none');
        $('#txtCertificatePrintRemark').focus();
        return;
    }

    $('#txtCertificatePrintRemark').removeClass('is-invalid');
    $('#printRemarkValidation').addClass('d-none');

    const confirmResult = await Swal.fire({
        title: `Confirm ${formatCertificateType(currentPrintRow?.type || '')} Print`,
        text: 'Are you sure you want to continue?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Continue',
        cancelButtonText: 'Cancel'
    });

    if (!confirmResult.isConfirmed) return;

    const $btn = $('#btnConfirmCertificatePrint');
    const oldHtml = $btn.html();

    isPrintSaving = true;
    $btn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Processing...`);

    try {
        await updateCertificatePrintRemark();

        const html = await loadCertificatePrintHtmlFromServer();

        if (!html) {
            throw new Error('Print HTML not received');
        }

        if (printInfoModalInstance) {
            printInfoModalInstance.hide();
        }

        showCertificatePrintPreview(html);

        await updateCertificatePrintCount();
        await fetchPrintStudentList();

        notify('success', 'Print preview loaded successfully');
    } catch (error) {
        console.error(error);
        await Swal.fire({
            icon: 'error',
            title: 'Something Went Wrong',
            text: error?.message || 'Unable to load certificate print preview.'
        });
    } finally {
        isPrintSaving = false;
        $btn.prop('disabled', false).html(oldHtml);
    }
}

async function updateCertificatePrintRemark() {
    const parms = {
        Institute: currentPrintRow.institute || '',
        Session: currentPrintRow.session || '',
        Course: currentPrintRow.course || '',
        Branch: currentPrintRow.branch || '',
        StudentID: currentPrintRow.studentID || currentPrintRow.admissionNo || '',
        Type: (currentPrintRow.type || '').toUpperCase(),
        Remark: ($('#txtCertificatePrintRemark').val() || '').trim(),
        mode: 'UpdateCertificatePrintRemark'
    };

    const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);

    if (res && res.statusCode && parseInt(res.statusCode, 10) !== 200) {
        throw new Error(res.message || 'Unable to save print remark');
    }

    return true;
}

async function updateCertificatePrintCount() {
    const parms = {
        Institute: currentPrintRow.institute || '',
        Session: currentPrintRow.session || '',
        Course: currentPrintRow.course || '',
        Branch: currentPrintRow.branch || '',
        StudentID: currentPrintRow.studentID || currentPrintRow.admissionNo || '',
        Type: (currentPrintRow.type || '').toUpperCase(),
        mode: 'UpdateCertificatePrintCount'
    };

    const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);

    if (res && res.statusCode && parseInt(res.statusCode, 10) !== 200) {
        throw new Error(res.message || 'Unable to update print count');
    }

    return true;
}

async function loadCertificatePrintHtmlFromServer() {
    const parms = {
        Institute: currentPrintRow.institute || '',
        Session: currentPrintRow.session || '',
        Course: currentPrintRow.course || '',
        Branch: currentPrintRow.branch || '',
        StudentID: currentPrintRow.studentID || currentPrintRow.admissionNo || '',
        Type: (currentPrintRow.type || '').toUpperCase(),
        mode: 'GetCertificateForPrint'
    };

    const res = await new IMSClient().request('/student/PrintTcNso', 'POST', parms, true, 'html');

    const html = extractHtmlResponse(res);

    if (!html || !String(html).trim()) {
        throw new Error('Empty HTML response from print endpoint');
    }

    currentPrintHtml = html;
    return html;
}

function showCertificatePrintPreview(html) {
    const modalEl = document.getElementById('certificatePrintPreviewModal');
    if (!modalEl) {
        throw new Error('Preview modal not found');
    }

    $('#certificatePrintPreviewContainer').html(html);

    if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
        throw new Error('Bootstrap modal not loaded');
    }

    certificatePrintPreviewModalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
    certificatePrintPreviewModalInstance.show();
}

function printCertificatePreviewContent() {
    const html = $('#certificatePrintPreviewContainer').html() || currentPrintHtml || '';

    if (!html || !String(html).trim()) {
        notify('warning', 'No preview available to print');
        return;
    }

    const printWindow = window.open('', '_blank', 'width=1200,height=800');

    if (!printWindow) {
        notify('warning', 'Popup blocked. Please allow popups for printing.');
        return;
    }

    printWindow.document.open();
    printWindow.document.write(`
        <html>
            <head>
                <title>Certificate Print</title>
                <style>
                    html, body {
                        margin: 0;
                        padding: 0;
                        background: #fff;
                    }
                    @page {
                        size: auto;
                        margin: 8mm;
                    }
                    @media print {
                        body {
                            margin: 0;
                            padding: 0;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                    }
                </style>
            </head>
            <body>
                ${html}
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.focus();

    setTimeout(function () {
        printWindow.print();
    }, 500);
}

async function deleteCertificateFromPrintList(row) {
    if (isDeleteCertificateProcessing) return;

    const confirmResult = await Swal.fire({
        title: `Delete ${formatCertificateType(row.type || '')} Certificate`,
        text: `Are you sure you want to delete certificate for ${row.studentName || row.admissionNo || row.studentID || 'student'}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Delete',
        cancelButtonText: 'Cancel'
    });

    if (!confirmResult.isConfirmed) return;

    isDeleteCertificateProcessing = true;

    try {
        const parms = {
            Institute: row.institute || '',
            Session: row.session || '',
            Course: row.course || '',
            Branch: row.branch || '',
            StudentID: row.studentID || row.admissionNo || '',
            Type: (row.type || '').toUpperCase(),
            CUser: $('#hdnUserID').val() || $('#UserID').val() || '',
            mode: 'DeleteCertificate'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);

        if (res && res.statusCode && parseInt(res.statusCode, 10) !== 200) {
            await Swal.fire({
                icon: 'warning',
                title: 'Unable to Delete',
                text: res.message || 'Operation failed'
            });
            return;
        }

        await Swal.fire({
            icon: 'success',
            title: 'Certificate Deleted Successfully',
            text: res?.message || 'Deleted successfully'
        });

        await fetchPrintStudentList();
    } catch (error) {
        console.error(error);
        await Swal.fire({
            icon: 'error',
            title: 'Something Went Wrong',
            text: 'Unable to delete certificate.'
        });
    } finally {
        isDeleteCertificateProcessing = false;
    }
}

async function openPrintCertificateHistory(meta) {
    try {
        const modalEl = document.getElementById('certificateHistoryModal');

        if (!modalEl) {
            notify('warning', 'History popup not available on page');
            return;
        }

        if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
            notify('danger', 'Bootstrap modal is not loaded properly');
            return;
        }

        historyModalInstance = bootstrap.Modal.getInstance(modalEl);
        if (!historyModalInstance) {
            historyModalInstance = new bootstrap.Modal(modalEl, {
                backdrop: true,
                keyboard: true,
                focus: true
            });
        }

        $('#historyContainer').html(`
            <div class="text-center py-4">
                <div class="spinner-border spinner-border-sm text-primary me-2"></div>
                <span class="small text-muted">Loading certificate history...</span>
            </div>
        `);

        historyModalInstance.show();

        const parms = {
            Institute: meta.institute || '',
            Session: meta.session || '',
            Course: meta.course || '',
            Branch: meta.branch || '',
            StudentID: meta.studentId || '',
            mode: 'GetCertificateHistory'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const data = normalizeResultArray(res);

        if (!Array.isArray(data) || data.length === 0) {
            $('#historyContainer').html(`
                <div class="text-center py-4">
                    <span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle px-3 py-2">
                        <i class="ti ti-history-off me-1"></i> No certificate history found
                    </span>
                </div>
            `);
            return;
        }

        let html = `
            <div class="table-responsive">
                <table class="table table-sm table-bordered table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width:55px;" class="text-center">#</th>
                            <th style="min-width:140px;">Type</th>
                            <th style="min-width:130px;">Issue Date</th>
                            <th style="min-width:180px;">Remark</th>
                            <th style="width:90px;" class="text-center">Print</th>
                            <th style="min-width:130px;">Printed</th>
                            <th style="min-width:130px;">Created</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        data.forEach((item, index) => {
            const certificateType = formatCertificateType(
                getValueByKeyContains(item, ['certificateType', 'certificatetype', 'type'], '-')
            );

            const issueDate = formatDisplayDateTime(
                getValueByKeyContains(item, ['issueDate', 'issuedate'], '')
            ) || '-';

            const issueRemark = getValueByKeyContains(item, ['remark', 'issueremark'], '-') || '-';

            const printCount = parseInt(
                getValueByKeyContains(item, ['printCount', 'printcount'], 0) || 0,
                10
            );

            const printedDate = formatDisplayDateTime(
                getValueByKeyContains(item, ['printedDate', 'printeddate'], '')
            ) || '-';

            const createdDate = formatDisplayDateTime(
                getValueByKeyContains(item, ['createdDate', 'createddate'], '')
            ) || '-';

            const printBadgeClass = printCount > 0
                ? 'bg-success-subtle text-success-emphasis border border-success-subtle'
                : 'bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle';

            html += `
                <tr>
                    <td class="text-center small">${index + 1}</td>
                    <td>
                        <span class="badge bg-info-subtle text-info-emphasis border border-info-subtle rounded-pill px-2 py-1 small">
                            <i class="ti ti-file-certificate me-1"></i>${escapeHtml(certificateType)}
                        </span>
                    </td>
                    <td class="small">${escapeHtml(issueDate)}</td>
                    <td class="small text-truncate" style="max-width:220px;" title="${escapeHtml(issueRemark)}">
                        ${escapeHtml(issueRemark)}
                    </td>
                    <td class="text-center">
                        <span class="badge ${printBadgeClass} rounded-pill px-2 py-1 small">
                            ${escapeHtml(String(printCount))}
                        </span>
                    </td>
                    <td class="small">${escapeHtml(printedDate)}</td>
                    <td class="small">${escapeHtml(createdDate)}</td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        $('#historyContainer').html(html);
    } catch (error) {
        console.error(error);

        $('#historyContainer').html(`
            <div class="text-center py-4">
                <span class="badge bg-danger-subtle text-danger-emphasis border border-danger-subtle px-3 py-2">
                    <i class="ti ti-alert-circle me-1"></i> Unable to load history
                </span>
            </div>
        `);

        notify('danger', 'Unable to load certificate history');
    }
}

function resetPrintInfoModal() {
    currentPrintRow = null;
    currentPrintHtml = '';
    currentPrintStudentAutoData = null;

    $('#printInfoStudentName').text('-');
    $('#printInfoStudentID').text('-');
    $('#printInfoAdmissionNo').text('-');
    $('#printInfoFatherName').text('-');
    $('#printInfoMotherName').text('-');
    $('#printInfoCertificateType').text('-');
    $('#printInfoCourse').text('-');
    $('#printInfoBranch').text('-');
    $('#printInfoSession').text('-');
    $('#printInfoIssueDate').text('-');
    $('#printInfoPrintCount').text('0');
    $('#printInfoPrintedDate').text('-');
    $('#printInfoIssueRemark').text('-');

    $('#txtCertificatePrintRemark').val('').removeClass('is-invalid');
    $('#printRemarkValidation').addClass('d-none');

    $('#printStudentPhoto').attr('src', '').hide();
    $('#printStudentPhotoFallback').show();
}

function setPrintLastUpdated() {
    if ($('#printLastUpdated').length) {
        $('#printLastUpdated').text(new Date().toLocaleTimeString());
    }
}

function extractHtmlResponse(res) {
    if (!res) return '';

    if (typeof res === 'string' && looksLikeHtml(res)) return res;
    if (typeof res?.result === 'string' && looksLikeHtml(res.result)) return res.result;
    if (typeof res?.Result === 'string' && looksLikeHtml(res.Result)) return res.Result;
    if (typeof res?.data === 'string' && looksLikeHtml(res.data)) return res.data;
    if (typeof res?.Data === 'string' && looksLikeHtml(res.Data)) return res.Data;
    if (typeof res?.d === 'string' && looksLikeHtml(res.d)) return res.d;

    return '';
}

function looksLikeHtml(value) {
    if (!value || typeof value !== 'string') return false;
    const s = value.trim().toLowerCase();
    return s.startsWith('<!doctype') || s.startsWith('<html') || s.includes('<body') || s.includes('<div') || s.includes('<table');
}

function setPrintStudentPhotoSafe(photoPath) {
    console.log(photoPath)
    const $img = $('#printStudentPhoto');
    const $fallback = $('#printStudentPhotoFallback');

    if (!$img.length) return;

    const finalPath = normalizeBase64Image(photoPath);

    if (!finalPath) {
        $img.attr('src', getNoImageUrl()).show();
        $fallback.hide();
        return;
    }

    $img.off('load error');

    $img.on('load', function () {
        $img.show();
        $fallback.hide();
    });

    $img.on('error', function () {
        $img.attr('src', getNoImageUrl());
        $fallback.hide();
    });

    $img.attr('src', finalPath);
}



function getNoImageUrl() {
    return '/theme/admin/assets/images/avatar/07.png';
}

function normalizeBase64Image(value) {
    if (!value) return '';

    const v = String(value).trim();

    if (!v) return '';

    if (v.startsWith('data:image')) return v;

    if (v.length > 100) {
        return 'data:image/png;base64,' + v;
    }

    return v;
}



function formatCertificateType(type) {
    const t = (type || '').toString().trim().toUpperCase();

    switch (t) {
        case 'CHARACTER': return 'Character';
        case 'PROVISIONAL': return 'Provisional';
        case 'MIGRATION': return 'Migration';
        case 'DMC': return 'DMC';
        case 'BONAFIDE': return 'Bonafide';
        default:
            return t ? (t.charAt(0) + t.slice(1).toLowerCase()) : '-';
    }
}

function formatDisplayDateTime(value) {
    if (!value) return '';

    try {
        const d = new Date(value);
        if (!isNaN(d.getTime())) {
            return d.toLocaleString();
        }
    } catch (e) { }

    return String(value);
}

function getValueByKeyContains(obj, keys, fallback = '') {
    if (!obj || typeof obj !== 'object') return fallback;

    const entries = Object.keys(obj).map(k => ({ key: k, lower: k.toLowerCase() }));

    for (const searchKey of keys) {
        const target = String(searchKey).toLowerCase();

        const exact = entries.find(x => x.lower === target);
        if (exact && obj[exact.key] !== undefined && obj[exact.key] !== null) {
            return obj[exact.key];
        }

        const contains = entries.find(x => x.lower.includes(target));
        if (contains && obj[contains.key] !== undefined && obj[contains.key] !== null) {
            return obj[contains.key];
        }
    }

    return fallback;
}

function normalizeResultArray(res) {
    if (!res) return [];

    if (Array.isArray(res)) return res;
    if (Array.isArray(res.result)) return res.result;
    if (Array.isArray(res.data)) return res.data;
    if (Array.isArray(res.Data)) return res.Data;
    if (Array.isArray(res.d)) return res.d;

    if (res.result && typeof res.result === 'object') {
        const firstArrayKey = Object.keys(res.result).find(k => Array.isArray(res.result[k]));
        if (firstArrayKey) return res.result[firstArrayKey];
    }

    if (typeof res.d === 'string') {
        try {
            const parsed = JSON.parse(res.d);
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) { }
    }

    return [];
}

function escapeHtml(value) {
    if (value === null || value === undefined) return '';
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function debounce(func, wait) {
    let timeout;
    return function () {
        const context = this;
        const args = arguments;
        clearTimeout(timeout);
        timeout = setTimeout(function () {
            func.apply(context, args);
        }, wait);
    };
}

function notify(type, message) {
    if (typeof ShowNotification === 'function') {
        ShowNotification(type, message, 'center');
        return;
    }

    if (typeof Swal !== 'undefined' && Swal.fire) {
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: type === 'danger' ? 'error' : (type === 'warning' ? 'warning' : 'success'),
            title: message,
            showConfirmButton: false,
            timer: 2500
        });
        return;
    }

    console.log(type + ': ' + message);
}