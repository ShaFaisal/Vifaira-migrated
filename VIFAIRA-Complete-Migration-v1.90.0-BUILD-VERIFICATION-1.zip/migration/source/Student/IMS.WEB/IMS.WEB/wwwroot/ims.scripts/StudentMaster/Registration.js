﻿$(function () {
  
    $('#bulkUploadBtn').on('click', function () {
        $('#bulkUploadSection').removeClass('d-none');
        $('#registration_table_layout').addClass('d-none');
        $('#form_registration_layout').addClass('d-none');
    });

    $('#closeBulkUploadBtn').on('click', function () {
        $('#bulkUploadSection').addClass('d-none');
        $('#form_registration_layout').addClass('d-none');
        $('#registration_table_layout').removeClass('d-none');
    });

    $('[data-bs-toggle="tooltip"]').tooltip();
    $('#studentTable').DataTable({
        searching: false,
        paging: true,
        info: true,
        lengthChange: false
});

    $('#addNewButton').on('click', (e) => {
        $('#bulkUploadSection').addClass('d-none');
        $('#addNewButton').addClass('d-none');
        $('#registration_table_layout').addClass('d-none');
        $('#form_registration_layout').removeClass('d-none');
    });

    $('#closeFormBtn').on('click', (e) => {
        $('#bulkUploadSection').addClass('d-none');
        $('#addNewButton').removeClass('d-none');
        $('#form_registration_layout').addClass('d-none');
        $('#registration_table_layout').removeClass('d-none');
    });

    $('#form_filter_data select').on('change', (e) => {
        fetchRegistration();
    })

    $('#form_filter_data input').on('input', (e) => {
        fetchRegistration();
    })



    $("#form_registration").validate({
        rules: {
            FirstName: { required: true },
            StudDOB: { required: true },
            StudMobile: { required: true },
            Program: { required: true },
            Branch: { required: true },
            FatherName: { required: true },
            MotherName: { required: true },
            Gender: { required: true },
            LstQualification: { required: true },
            RegDate: { required: true },
            CurrAddress: { required: true },
            State: { required: true },
        },
        messages: {
            FirstName: { required: "Please enter first name" },
            StudDOB: { required: "Please enter date of birth" },
            StudMobile: { required: "Please enter student mobile" },
            Program: { required: "Please select program" },
            Branch: { required: "Please select branch" },
            FatherName: { required: "Please enter father’s name" },
            MotherName: { required: "Please enter mother’s name" },
            Gender: { required: "Please select gender" },
            LstQualification: { required: "Please select last qualification" },
            RegDate: { required: "Please enter registration date" },
            CurrAddress: { required: "Please enter full address" },
            State: { required: "Please select state" },
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            if (element.parent(".form-floating").length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        },
        submitHandler: function (form, event) {
            event.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to save this data?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, save it!',
                cancelButtonText: 'No, cancel',
                buttonsStyling: false,
                customClass: {
                    confirmButton: 'btn btn-primary me-2',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const $btn = $("#SaveRecord");
                    $btn.addClass("pe-none").html(`
                        <span class="spinner-border spinner-border-sm me-2 ms-2" role="status"></span>
                        Please Wait...
                    `);

                    new IMSClient().request('/Student/Registration', 'POST', new FormData(form), true)
                        .then((res) => {
                            if (res.statusCode === 200) {
                                form.reset();
                                $(form).validate().resetForm();
                                $(form).find('.is-valid, .is-invalid').removeClass('is-valid is-invalid');
                             
                                Swal.fire({
                                    title: 'Student Registered Successfully!',
                                    text: res.message || 'Student has been successfully registered.',
                                    icon: 'success',
                                    showCancelButton: false,
                                    confirmButtonText: 'OK',
                                    buttonsStyling: false,
                                    customClass: {
                                        confirmButton: 'btn btn-success'
                                    }
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        resetBulkUpload();

                                        setTimeout(() => {
                                            $('#addNewButton').removeClass('d-none');
                                            $('#form_registration_layout').addClass('d-none');
                                            $('#registration_table_layout').removeClass('d-none');
                                        }, 1000);
                                    }
                                });



                             
                            } else {
                                ShowNotification("danger", res.message, "center");
                            }
                        })
                        .catch((err) => {
                            ShowNotification("danger", err.message || "Something went wrong", "center");
                        })
                        .finally(() => {
                            $btn.removeClass("pe-none").html("SAVE");
                        });
                }
            });

            return false;
        }
    });
});

var exportData=[];
function fetchRegistration() {
    
    const InstituteFilter = $('#InstituteFilter').val() || '';
    const ProgramFilter = $('#ProgramFilter').val() || '';
    const BranchFilter = $('#BranchFilter').val() || '';
    const CategoryFilter = $('#CategoryFilter').val() || '';
    const GenderFilter = $('#GenderFilter').val() || '';
    const SearchTextFilter = $('#SearchTextFilter').val() || '';

    const formData = {
        Action: 'list',
        InstituteID: InstituteFilter,
        Program: ProgramFilter,
        Branch: BranchFilter,
        Category: CategoryFilter,
        Gender: GenderFilter,
        ID: SearchTextFilter
    };

    new IMSClient().request('/Student/Registration', 'POST', formData, true)
        .then((res) => {
         

            if (res.statusCode === 200) {
                createStudentTable(res.result);
                exportData = res.result;
            } else {
                ShowNotification("danger", res.message, "center");
            }
        })
        .catch((err) => {
            ShowNotification("danger", err.message || "Something went wrong", "center");
        });
}


function createStudentTable(data) {
    $('#table_body_student').empty();

    if ($.fn.DataTable.isDataTable('#studentTable')) {
        $('#studentTable').DataTable().clear().destroy();
    }

    data.forEach(item => {
        const fullName = `${item.firstName || ''} ${item.middleName || ''} ${item.lastName || ''}`.trim();
        const dob = item.studDOB ? new Date(item.studDOB).toLocaleDateString() : '-';
        const address = `${item.currAddress}, ${item.city}, ${item.district}, ${item.state_Name} - ${item.zipcode}`;

        const row = `
    <tr>
        <td><span class="badge bg-primary">${item.regID || 'N/A'}</span></td>
        <td>${fullName}</td>
        <td><span class="badge bg-danger">${item.course_name || 'N/A'}</span></td>
        <td>${item.branch_name || 'N/A'}</td>
        <td>${item.instituteName || 'N/A'}</td>
        <td><span class="badge bg-info">${item.gender || '-'}</span></td>
        <td>${dob}</td>
        <td>${item.studEmail || '-'}</td>
        <td><span class="badge bg-success">${item.studMobile || '-'}</span></td>
        <td class="text-truncate" style="max-width: 200px;" title="${address}">${address}</td>
        <td>
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="ti ti-settings me-1"></i> Actions
                </button>
         <ul class="dropdown-menu">
    ${item.regStatus == 0 ? `
    <li>
        <a class="dropdown-item" href="/Admin/Student/Admission?token=${item.hash}">
            <i class="ti ti-edit me-1"></i> Go To Admission
        </a>
    </li>
    ` : ''}
    <li>
        <a class="dropdown-item" href="#" 
           onclick='viewStudentDetails(${JSON.stringify(item).replace(/'/g, "\\'")})' 
           data-bs-toggle="modal" data-bs-target="#viewStudentModal">
            <i class="ti ti-eye me-1"></i> View Details
        </a>
    </li>
</ul>
            </div>
        </td>
    </tr>
    `;

        $('#table_body_student').append(row);
    });

    
    $('#studentTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'excelHtml5',
                text: '<i class="ti ti-file-type-xls me-1"></i> Export Excel',
                title: 'Student Registration Data',
                className: 'btn btn-success',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdfHtml5',
                text: '<i class="ti ti-file-type-pdf me-1"></i> Export PDF',
                title: 'Student Registration Data',
                className: 'btn btn-danger',
                exportOptions: {
                    columns: ':visible'
                }
            }
        ],
        searching: false,
        paging: true,
        info: true,
        lengthChange: false,
        pageLength: 10,
        responsive: true
    });
}
// Format date to DD-MM-YYYY
function formatDate(dateStr) {
    if (!dateStr) return '-';
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return '-';
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    } catch (e) {
        return '-';
    }
}

// Format date to DD-MM-YYYY HH:MM
function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return '-';
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${day}-${month}-${year} ${hours}:${minutes}`;
    } catch (e) {
        return '-';
    }
}

// Format full name
function formatFullName(firstName, middleName, lastName) {
    const name = `${firstName || ''} ${middleName || ''} ${lastName || ''}`.trim();
    return name || '-';
}

// Format address
function formatAddress(student) {
    const parts = [];
    if (student.currAddress) parts.push(student.currAddress);
    if (student.city) parts.push(student.city);
    if (student.district) parts.push(student.district);
    if (student.state_Name) parts.push(student.state_Name);
    if (student.zipcode) parts.push(student.zipcode);
    return parts.length > 0 ? parts.join(', ') : '-';
}

// View Student Details - Sets data in BOTH top and card sections
function viewStudentDetails(student) {
    console.log('Student Data:', student);

    // Get values with proper fallbacks
    const courseName = student.course_name || '-';
    const branchName = student.branch_name || '-';
    const sessionName = student.session_Name || '-';
    const instituteName = student.instituteName || '-';
    const fullName = formatFullName(student.firstName, student.middleName, student.lastName);
    const address = formatAddress(student);
    const dob = formatDate(student.studDOB);
    const regDate = formatDate(student.regDate);
    const createDate = formatDateTime(student.createDate);

    // ====== TOP SECTION (Header Cards) ======
    $('#viewName').text(fullName);
    $('#viewRegID').text(student.regID || 'N/A');
    $('#viewGender').text(student.gender || '-');
    $('#viewCourseTop').text(courseName);
    $('#viewSessionTop').text(sessionName);
    $('#viewInstituteTop').text(instituteName);

    // ====== PERSONAL INFORMATION CARD ======
    $('#viewDOB').text(dob);
    $('#viewCategory').text(student.category_name || student.category || '-');
    $('#viewQualification').text(student.lstQualification || '-');
    $('#viewAadhar').text(student.studAadhar || '-');
    $('#viewPan').text(student.studPancard || '-');

    // ====== CONTACT INFORMATION CARD ======
    $('#viewEmail').text(student.studEmail || '-');
    $('#viewMobile').text(student.studMobile || '-');
    $('#viewAddress').text(address);

    // ====== ACADEMIC INFORMATION CARD ======
    $('#viewCourse').text(courseName);
    $('#viewBranch').text(branchName);
    $('#viewSession').text(sessionName);
    $('#viewInstitute').text(instituteName);

    // ====== FATHER'S INFORMATION CARD ======
    $('#viewFatherName').text(student.fatherName || '-');
    $('#viewFatherMobile').text(student.fatherMob || '-');
    $('#viewFatherEmail').text(student.fatherEmail || '-');
    $('#viewFatherAadhar').text(student.fatherAadhar || '-');

    // ====== MOTHER'S INFORMATION CARD ======
    $('#viewMotherName').text(student.motherName || '-');
    $('#viewMotherMobile').text(student.motherMob || '-');
    $('#viewMotherEmail').text(student.motherEmail || '-');
    $('#viewMotherAadhar').text(student.motherAadhar || '-');

    // ====== REGISTRATION DETAILS CARD ======
    $('#viewRegDate').text(regDate);
    $('#viewCreateBy').text(student.createBy || '-');
    $('#viewCreateDate').text(createDate);
}
