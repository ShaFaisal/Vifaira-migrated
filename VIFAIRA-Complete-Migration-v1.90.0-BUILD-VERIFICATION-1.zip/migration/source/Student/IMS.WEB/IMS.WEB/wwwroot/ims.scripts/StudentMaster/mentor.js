﻿let mentorSelectedStudents = new Set();

$(function () {
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 500);

    updateLabelsBasedOnInstituteType($('.ims-institute').val());
    $('[data-bs-toggle="tooltip"]').tooltip();

    initFormValidation();
    bindMentorEvents();
    bindMentorDropdown();
});

function bindMentorEvents() {
    $('#searchBtn').off('click').on('click', function (e) {
        e.preventDefault();
        $('#formMentorAllocation').submit();
    });

    $('#formMentorAllocation').off('submit').on('submit', function (e) {
        e.preventDefault();
        if ($(this).valid()) {
            fetchMentorStudents(this);
        }
    });

    $('#btnAssignMentor').off('click').on('click', function () {
        saveMentorAllocation();
    });

    $('#btnRemoveMentor').off('click').on('click', function () {
        removeMentorAllocation();
    });

    $('.ims-institute').off('change').on('change', async function () {
        await handleInstituteTypeOnFilterChange($(this).val());
        bindMentorDropdown();
    });

    $(document).off("change", "#checkAll").on("change", "#checkAll", function () {
        const isChecked = this.checked;
        syncAllCheckboxes(isChecked);
    });

    $(document).off('change', '.student-check').on('change', '.student-check', function () {
        const val = String($(this).val());
        if (this.checked) {
            mentorSelectedStudents.add(val);
        } else {
            mentorSelectedStudents.delete(val);
        }
        updateSelectedCountDisplay();
        updateCheckAllCheckbox();
    });

    $(document).off('click', '.btn-row-remove').on('click', '.btn-row-remove', function () {
        const admissionNo = $(this).data('id');
        const mentorId = $(this).data('mentor');
        removeSingleMentor(admissionNo, mentorId);
    });
}

function initFormValidation() {
    if ($("#formMentorAllocation").data('validator')) {
        $("#formMentorAllocation").removeData("validator");
        $("#formMentorAllocation").removeData("unobtrusiveValidation");
    }

    $("#formMentorAllocation").validate({
        ignore: [],
        rules: {
            Institute: { required: true },
            Session: { required: true },
            Program_id: { required: true },
            Branch_Id: { required: true },
            Semester_id: {
                required: function () {
                    return $("#sem").is(":visible");
                }
            }
        },
        messages: {
            Institute: "Please select Institute",
            Session: "Please select Session",
            Program_id: "Please select Program/Class",
            Branch_Id: "Please select Branch/Section",
            Semester_id: "Please select Semester"
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback").insertAfter(element);
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        }
    });
}

async function bindMentorDropdown() {
    let parms = {
        Institute_Id: $('#Institute').val() || '',
        Program_id: '',
        Branch_Id: '',
        Batch_ID: '',
        Semester_id: '',
        Stu_id: '',
        MentorID: '',
        createdby: '',
        Mode: 'MentorDetail'
    };

    try {
        const res = await new IMSClient().request('/Student/mentor', 'POST', parms, true);
        const data = res?.result || res?.data || [];

        $('#MentorID').empty().append(`<option value="">--All Mentors--</option>`);
        $('#MentorIDAction').empty().append(`<option value="">--Select Mentor--</option>`);

        data.forEach((item) => {
            const mentorId = item.mentorID || item.MentorID || '';
            const staffName = item.staffName || item.StaffName || '';
            $('#MentorID').append(`<option value="${mentorId}">${staffName}</option>`);
            $('#MentorIDAction').append(`<option value="${mentorId}">${staffName}</option>`);
        });
    } catch {
        ShowNotification("danger", "Unable to load mentor list", "center");
    }
}

async function fetchMentorStudents(form) {
    const btn = $("#searchBtn");
    const html = btn.html();
    btn.prop("disabled", true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Searching...`);

    // Clear previous selections
    mentorSelectedStudents.clear();
    

    let parms = {
        Institute_Id: $('#Institute').val() || '',
        Program_id: $('#Program_id').val() || '',
        Branch_Id: $('#Branch_Id').val() || '',
        Batch_ID: $('#Session').val() || '',
        Semester_id: $('#Semester_id').val() || '',
        Stu_id: '',
        MentorID: $('#MentorID').val() || '',
        createdby: '',
        Mode: $('#ViewMode').val() || 'getdataMentor'
    };

    try {
        const res = await new IMSClient().request('/Student/mentor', 'POST', parms, true);
        btn.prop("disabled", false).html(html);

        const data = res?.result || res?.data || [];
       
        if ((res.statusCode === 200 || res.StatusCode === 200 || data.length > 0) && data.length > 0) {
            convertMentorStudentArray(data);
            updateSummaryCards(data);
            ShowNotification("success", `Found ${data.length} student(s)`, "center");
        } else {
            showEmptyState();
            resetSummaryCards();
            ShowNotification("info", "No students found", "center");
        }

        updateSelectedCountDisplay();
        updateCheckAllCheckbox();
    } catch (error) {
        btn.prop("disabled", false).html(html);
        showEmptyState();
        resetSummaryCards();
        updateSelectedCountDisplay();
        updateCheckAllCheckbox();
        ShowNotification("danger", "Something went wrong", "center");
        console.error(error);
    }
}

function showEmptyState() {
    $('#mentorStudentTable').html(`
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            
            <div class="card-body text-center py-4">
                <div class="d-inline-flex align-items-center justify-content-center rounded-circle border border-secondary-subtle mb-2" style="width:52px;height:52px;">
                    <i class="fas fa-user-graduate fs-5 text-secondary opacity-75"></i>
                </div>
                <h6 class="text-dark mb-1 small fw-semibold">No Students Found</h6>
                <p class="text-secondary small mb-0">Use filters and click Search.</p>
            </div>
        </div>
    `);
}
function convertMentorStudentArray(data) {
    const rows = [];
    const isSchool = $("#sem").hasClass("d-none");

    data.forEach((item) => {
        const admissionNo = item.admissionNo || item.AdmissionNo || '';
        const name = item.name || item.Name || '';
        const course = item.course || item.Course || item.Course_Name || '';
        const branch = item.branch || item.Branch || item.Branch_Name || '';
        const semester = item.semester || item.Semester || item.Semester_Name || '';
        const mentorName = item.mentorName || item.MentorName || 'Not Mapped';
        const mentorID = item.mentorID || item.MentorID || '';
        const mappingStatus = item.mappingStatus || item.MappingStatus || 'Not Mapped';

        const isMapped = String(mappingStatus).toLowerCase() === 'mapped';

        const checkbox = `
            <div class="d-flex justify-content-center">
                <input type="checkbox" class="student-check form-check-input rounded-2 mt-0" value="${admissionNo}" ${mentorSelectedStudents.has(String(admissionNo)) ? 'checked' : ''} style="cursor:pointer;">
            </div>`;

        const admissionHtml = `
            <div class="d-flex align-items-center gap-2">
                <i class="fas fa-id-card text-primary fs-6"></i>
                <span class="fw-semibold text-dark">${admissionNo || '-'}</span>
            </div>`;

        const nameHtml = `
            <div class="d-flex align-items-center gap-2">
                <i class="fas fa-user-graduate text-success fs-6"></i>
                <span class="fw-semibold text-dark">${name || '-'}</span>
            </div>`;

        const courseHtml = `
            <span class="badge bg-info-subtle text-info-emphasis border border-info-subtle rounded-pill px-3 py-2">
                <i class="fas fa-graduation-cap me-1"></i>${course || '—'}
            </span>`;

        const branchHtml = `
            <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle rounded-pill px-3 py-2">
                <i class="fas fa-code-branch me-1"></i>${branch || '—'}
            </span>`;

        const semesterHtml = semester
            ? `<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle rounded-pill px-3 py-2">
                    <i class="fas fa-calendar-alt me-1"></i>${semester}
               </span>`
            : `<span class="text-secondary">—</span>`;

        const mentorHtml = isMapped
            ? `<div class="d-flex align-items-center gap-2">
                    <i class="fas fa-chalkboard-user text-warning fs-6"></i>
                    <span class="fw-semibold text-dark">${mentorName}</span>
               </div>`
            : `<span class="badge bg-danger-subtle text-danger-emphasis border border-danger-subtle rounded-pill px-3 py-2">
                    <i class="fas fa-user-slash me-1"></i>Not Mapped
               </span>`;

        const statusHtml = isMapped
            ? `<span class="badge bg-success-subtle text-success-emphasis border border-success-subtle rounded-pill px-3 py-2">
                    <i class="fas fa-check-circle me-1"></i>Mapped
               </span>`
            : `<span class="badge bg-danger-subtle text-danger-emphasis border border-danger-subtle rounded-pill px-3 py-2">
                    <i class="fas fa-times-circle me-1"></i>Not Mapped
               </span>`;

        const actionHtml = isMapped
            ? `<button type="button" class="btn btn-outline-danger btn-sm btn-row-remove rounded-pill px-3 py-1" data-id="${admissionNo}" data-mentor="${mentorID}" title="Remove Mentor">
                    <i class="fas fa-user-minus me-1"></i>Remove
               </button>`
            : `<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle rounded-pill px-3 py-2">
                    <i class="fas fa-ban me-1"></i>No Action
               </span>`;

        if (isSchool) {
            rows.push([
                checkbox,
                admissionHtml,
                nameHtml,
                courseHtml,
                branchHtml,
                mentorHtml,
                statusHtml,
                actionHtml
            ]);
        } else {
            rows.push([
                checkbox,
                admissionHtml,
                nameHtml,
                courseHtml,
                branchHtml,
                semesterHtml,
                mentorHtml,
                statusHtml,
                actionHtml
            ]);
        }
    });

    renderDataTable(rows, isSchool);
}

function renderDataTable(dataRows, isSchool) {
    const cols = isSchool ? [
        { title: `<div class="d-flex justify-content-center"><input type="checkbox" class="form-check-input rounded-2 mt-0 check-all-header" style="cursor:pointer;"></div>`, width: "50px", className: "text-center align-middle" },
        { title: '<i class="fas fa-id-card me-1"></i> Adm No', width: "140px", className: "align-middle" },
        { title: '<i class="fas fa-user-graduate me-1"></i> Student Name', width: "240px", className: "align-middle" },
        { title: '<i class="fas fa-graduation-cap me-1"></i> Class', width: "150px", className: "align-middle" },
        { title: '<i class="fas fa-code-branch me-1"></i> Section', width: "150px", className: "align-middle" },
        { title: '<i class="fas fa-chalkboard-user me-1"></i> Mentor', width: "200px", className: "align-middle" },
        { title: '<i class="fas fa-info-circle me-1"></i> Status', width: "140px", className: "align-middle text-center" },
        { title: '<i class="fas fa-cog me-1"></i> Action', width: "140px", className: "align-middle text-center" }
    ] : [
        { title: `<div class="d-flex justify-content-center"><input type="checkbox" class="form-check-input rounded-2 mt-0 check-all-header" style="cursor:pointer;"></div>`, width: "50px", className: "text-center align-middle" },
        { title: '<i class="fas fa-id-card me-1"></i> Adm No', width: "140px", className: "align-middle" },
        { title: '<i class="fas fa-user-graduate me-1"></i> Student Name', width: "240px", className: "align-middle" },
        { title: '<i class="fas fa-graduation-cap me-1"></i> Program', width: "150px", className: "align-middle" },
        { title: '<i class="fas fa-code-branch me-1"></i> Branch', width: "150px", className: "align-middle" },
        { title: '<i class="fas fa-calendar-alt me-1"></i> Sem', width: "100px", className: "align-middle text-center" },
        { title: '<i class="fas fa-chalkboard-user me-1"></i> Mentor', width: "200px", className: "align-middle" },
        { title: '<i class="fas fa-info-circle me-1"></i> Status', width: "140px", className: "align-middle text-center" },
        { title: '<i class="fas fa-cog me-1"></i> Action', width: "140px", className: "align-middle text-center" }
    ];



    if ($.fn.DataTable.isDataTable('#mentorStudentTable')) {
        $('#mentorStudentTable').DataTable().destroy();
        $('#mentorStudentTable').empty();
    }

    $('#mentorStudentTable').DataTable({
        data: dataRows,
        paging: true,
        pageLength: 10,
        searching: true,
        ordering: false,
        info: true,
        lengthChange: true,
        autoWidth: false,
        responsive: false,
        scrollX: true,
        destroy: true,
        columns: cols,
      
        headerCallback: function (thead) {
            $(thead).find('th').addClass('fw-semibold text-dark  border-bottom py-3 px-3 small');
        },
        drawCallback: function () {
            $('#mentorStudentTable tbody tr').addClass('small');
            $('#mentorStudentTable tbody td').addClass('py-3 px-3 align-middle');

            $('#mentorStudentTable_wrapper .dataTables_length select').addClass('form-select form-select-sm');
            $('#mentorStudentTable_wrapper .dataTables_filter input').addClass('form-control form-control-sm');
            $('#mentorStudentTable_wrapper .dataTables_filter label').addClass('w-100');
            $('#mentorStudentTable_wrapper .dataTables_filter input').css('max-width', '240px');

            updateCheckAllCheckbox();
            updateSelectedCountDisplay();

            $('.check-all-table').off('change').on('change', function () {
                const isChecked = this.checked;
                syncAllCheckboxes(isChecked);
            });

            $('.check-all-header').off('change').on('change', function () {
                const isChecked = this.checked;
                syncAllCheckboxes(isChecked);
            });
        }
    });
}

// Helper function to sync all checkboxes
function syncAllCheckboxes(isChecked) {
    $('.student-check').each(function () {
        const val = String($(this).val());
        $(this).prop('checked', isChecked);

        if (isChecked) {
            mentorSelectedStudents.add(val);
        } else {
            mentorSelectedStudents.delete(val);
        }
    });

    $('.check-all-header').prop('checked', isChecked);
    $('.check-all-table').prop('checked', isChecked);
    $('#checkAll').prop('checked', isChecked);

    updateSelectedCountDisplay();
}

async function saveMentorAllocation() {
    let selectedStudents = getSelectedStudents();

    if (selectedStudents.length === 0) {
        ShowNotification("warning", "Please select at least one student", "center");
        return;
    }

    const mentorId = $('#MentorIDAction').val() || $('#MentorID').val();
    if (!mentorId) {
        ShowNotification("warning", "Please select a mentor", "center");
        return;
    }

    let parms = {
        Institute_Id: $('#Institute').val() || '',
        Program_id: $('#Program_id').val() || '',
        Branch_Id: $('#Branch_Id').val() || '',
        Batch_ID: $('#Session').val() || '',
        Semester_id: $('#Semester_id').val() || '',
        Stu_id: selectedStudents.join(';'),
        MentorID: mentorId,
        createdby: '',
        Mode: 'saveMentor'
    };

    const btn = $("#btnAssignMentor");
    const html = btn.html();
    btn.prop("disabled", true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Assigning...`);

    try {
        const res = await new IMSClient().request('/Student/mentor', 'POST', parms, true);
        btn.prop("disabled", false).html(html);

        if (res.statusCode === 200 || res.StatusCode === 200) {
            clearAllSelections(false);
            ShowNotification("success", res.message || res.Message || "Mentor allocation saved successfully", "center");
            refreshStudentList();
        } else {
            ShowNotification("warning", res.message || res.Message || "Unable to save mentor allocation", "center");
        }
    } catch (error) {
        btn.prop("disabled", false).html(html);
        ShowNotification("danger", "Something went wrong", "center");
        console.error(error);
    }
}

async function removeMentorAllocation() {
    let selectedStudents = getSelectedStudents();

    if (selectedStudents.length === 0) {
        ShowNotification("warning", "Please select at least one student", "center");
        return;
    }

    // Filter only mapped students for removal
    const mappedStudents = [];
    $('.student-check').each(function () {
        const $row = $(this).closest('tr');
        const statusCell = isSchool() ? $row.find('td:eq(6)') : $row.find('td:eq(7)');
        const isMapped = statusCell.text().includes('Mapped');

        if (isMapped && $(this).prop('checked')) {
            mappedStudents.push(String($(this).val()));
        }
    });

    if (mappedStudents.length === 0) {
        ShowNotification("warning", "No mapped students selected for removal", "center");
        return;
    }

    const confirmMessage = mappedStudents.length === 1
        ? "Are you sure you want to remove mentor for this student?"
        : `Are you sure you want to remove mentor for ${mappedStudents.length} students?`;

    if (!confirm(confirmMessage)) {
        return;
    }

    let parms = {
        Institute_Id: $('#Institute').val() || '',
        Program_id: $('#Program_id').val() || '',
        Branch_Id: $('#Branch_Id').val() || '',
        Batch_ID: $('#Session').val() || '',
        Semester_id: $('#Semester_id').val() || '',
        Stu_id: mappedStudents.join(';'),
        MentorID: '',
        createdby: '',
        Mode: 'RemoveMentorAllocation'
    };

    const btn = $("#btnRemoveMentor");
    const html = btn.html();
    btn.prop("disabled", true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Removing...`);

    try {
        const res = await new IMSClient().request('/Student/mentor', 'POST', parms, true);
        btn.prop("disabled", false).html(html);

        if (res.statusCode === 200 || res.StatusCode === 200) {
            // Remove only the removed students from the Set
            mappedStudents.forEach(studentId => {
                mentorSelectedStudents.delete(String(studentId));
            });

            updateSelectedCountDisplay();
            updateCheckAllCheckbox();

            ShowNotification("success", res.message || res.Message || `${mappedStudents.length} mentor(s) removed successfully`, "center");

            // Refresh the student list
            setTimeout(() => {
                refreshStudentList();
            }, 500);
        } else {
            ShowNotification("warning", res.message || res.Message || "Unable to remove mentor", "center");
        }
    } catch (error) {
        btn.prop("disabled", false).html(html);
        ShowNotification("danger", "Something went wrong", "center");
        console.error(error);
    }
}

async function removeSingleMentor(admissionNo, mentorId) {
    if (!confirm("Are you sure you want to remove mentor for this student?")) {
        return;
    }

    let parms = {
        Institute_Id: $('#Institute').val() || '',
        Program_id: $('#Program_id').val() || '',
        Branch_Id: $('#Branch_Id').val() || '',
        Batch_ID: $('#Session').val() || '',
        Semester_id: $('#Semester_id').val() || '',
        Stu_id: admissionNo,
        MentorID: mentorId || '',
        createdby: '',
        Mode: 'RemoveMentorAllocation'
    };

    try {
        const res = await new IMSClient().request('/Student/mentor', 'POST', parms, true);

        if (res.statusCode === 200 || res.StatusCode === 200) {
            mentorSelectedStudents.delete(String(admissionNo));
            updateSelectedCountDisplay();
            updateCheckAllCheckbox();

            ShowNotification("success", res.message || res.Message || "Mentor removed successfully", "center");

            setTimeout(() => {
                refreshStudentList();
            }, 500);
        } else {
            ShowNotification("warning", res.message || res.Message || "Unable to remove mentor", "center");
        }
    } catch (error) {
        ShowNotification("danger", "Something went wrong", "center");
        console.error(error);
    }
}

function getSelectedStudents() {
    // Sync with actual checkboxes
    $('.student-check').each(function () {
        const val = String($(this).val());
        if ($(this).prop('checked')) {
            if (!mentorSelectedStudents.has(val)) {
                mentorSelectedStudents.add(val);
            }
        } else {
            if (mentorSelectedStudents.has(val)) {
                mentorSelectedStudents.delete(val);
            }
        }
    });
    return Array.from(mentorSelectedStudents);
}

function getSelectedStudentCount() {
    return getSelectedStudents().length;
}

function updateSelectedCountDisplay() {
    const selectedCount = getSelectedStudentCount();
    $('#selectedCountDisplay').text(selectedCount);
    $('#selectedCountDisplayTop').text(selectedCount);
}

function updateCheckAllCheckbox() {
    const visibleStudents = $('.student-check');
    const totalVisible = visibleStudents.length;
    let selectedVisible = 0;

    visibleStudents.each(function () {
        const val = String($(this).val());
        if (mentorSelectedStudents.has(val)) {
            selectedVisible++;
            $(this).prop('checked', true);
        } else {
            $(this).prop('checked', false);
        }
    });

    const isAllVisibleChecked = totalVisible > 0 && selectedVisible === totalVisible;

    $('.check-all-header').prop('checked', isAllVisibleChecked).prop('disabled', totalVisible === 0);
    $('.check-all-table').prop('checked', isAllVisibleChecked).prop('disabled', totalVisible === 0);
    $('#checkAll').prop('checked', isAllVisibleChecked).prop('disabled', totalVisible === 0);
}

function updateSummaryCards(data) {
    const total = data.length;
    let mapped = 0;
    let notMapped = 0;

    data.forEach(item => {
        const status = String(item.mappingStatus || item.MappingStatus || 'Not Mapped').toLowerCase();
        if (status === 'mapped') mapped++;
        else notMapped++;
    });

    $('#totalRecords').text(total);
    $('#mappedCount').text(mapped);
    $('#notMappedCount').text(notMapped);
}

function resetSummaryCards() {
    $('#totalRecords').text(0);
    $('#mappedCount').text(0);
    $('#notMappedCount').text(0);
}

function refreshStudentList() {
    $('#formMentorAllocation').submit();
}

function clearAllSelections(showMsg = true) {
    mentorSelectedStudents.clear();

    $('.student-check').prop('checked', false);
    $('.check-all-header').prop('checked', false);
    $('.check-all-table').prop('checked', false);
    $('#checkAll').prop('checked', false);

    updateSelectedCountDisplay();

    if (showMsg) {
        ShowNotification("info", "All selections cleared", "center");
    }
}

function resetMentorFilters() {
    $('#formMentorAllocation')[0].reset();
    $('#ViewMode').val('getdataMentor');
    $('#Semester_id').val('');
    clearAllSelections(false);
    resetSummaryCards();
    showEmptyState();
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 300);
}

function isSchool() {
    return $("#sem").hasClass("d-none");
}

async function handleInstituteTypeOnFilterChange(inst) {
    await updateLabelsBasedOnInstituteType(inst);

    if (!inst) {
        $("#sem").removeClass("d-none");
        return;
    }

    try {
        const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
            { InId: inst, Action: 'GetInstituteType' }, true);

        let type = res?.result?.[0]?.value || "";

        $('#Semester_id').val("");
        type === "School" ? $("#sem").addClass("d-none") : $("#sem").removeClass("d-none");
    } catch {
        $("#sem").removeClass("d-none");
    }
}

async function updateLabelsBasedOnInstituteType(inst) {
    if (!inst) {
        $("#programClassLabel").html('<i class="fas fa-graduation-cap me-1 text-muted"></i>Program/Class');
        $("#branchSectionLabel").html('<i class="fas fa-code-branch me-1 text-muted"></i>Branch/Section');
        return;
    }

    try {
        const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
            { InId: inst, Action: 'GetInstituteType' }, true);

        let type = res?.result?.[0]?.value || "";

        if (type === "School") {
            $("#programClassLabel").html('<i class="fas fa-chalkboard me-1 text-muted"></i>Class');
            $("#branchSectionLabel").html('<i class="fas fa-layer-group me-1 text-muted"></i>Section');
        } else {
            $("#programClassLabel").html('<i class="fas fa-graduation-cap me-1 text-muted"></i>Program');
            $("#branchSectionLabel").html('<i class="fas fa-code-branch me-1 text-muted"></i>Branch');
        }
    } catch {
        $("#programClassLabel").html('<i class="fas fa-graduation-cap me-1 text-muted"></i>Program/Class');
        $("#branchSectionLabel").html('<i class="fas fa-code-branch me-1 text-muted"></i>Branch/Section');
    }
}