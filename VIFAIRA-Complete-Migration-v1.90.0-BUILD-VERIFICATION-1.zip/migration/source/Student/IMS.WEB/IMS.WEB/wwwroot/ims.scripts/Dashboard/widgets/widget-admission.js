﻿const AdmissionDashboardRenderer = (function () {
    function renderLoading(widget) {
        const container = DashboardCommonRenderer.getWidgetContainer(widget);
        if (!container.length) return;
        container.html(createAdmissionLoadingCard());
    }

    function render(widget, rawData) {
        const container = DashboardCommonRenderer.getWidgetContainer(widget);
        if (!container.length) return;

        const data = unwrapWidgetData(rawData);
        const model = normalizeAdmissionTables(data.result || []);
        const chartId = 'dashboardAdmissionChart_' + uniqueId();

        container.html(`
            <div class="card h-100 dashboard-analytic-card">
                <div class="card-body p-3 p-md-4">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
                        <div>
                            <h5 class="mb-1">Admission Summary</h5>
                            <small class="text-muted">${DashboardCommonRenderer.escapeHtml(model.currentSessionName || 'Current Session')}</small>
                        </div>
                        <span class="badge bg-warning text-dark">Admission</span>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            ${createMiniStatCard('warning', 'ph-users-three', 'Total', formatSmartValue(model.totalAdmission))}
                        </div>
                        <div class="col-6">
                            ${createMiniStatCard('primary', 'ph-student', 'Current', formatSmartValue(model.currentSessionTotal))}
                        </div>
                        <div class="col-6">
                            ${createMiniStatCard('danger', 'ph-calendar-check', 'Previous', formatSmartValue(model.previousSessionTotal))}
                        </div>
                        <div class="col-6">
                            ${createMiniStatCard('info', 'ph-chart-donut', 'Diff', formatSignedValue(model.differenceCount))}
                        </div>
                    </div>

                    <div class="dashboard-chart-block">
                        <div id="${chartId}"></div>
                    </div>
                </div>
            </div>
        `);

        setTimeout(() => {
            renderAdmissionChart(chartId, model);
        }, 50);
    }

    function renderFallback(widget, message) {
        const container = DashboardCommonRenderer.getWidgetContainer(widget);
        if (!container.length) return;

        container.html(createChartFallbackCard('Admission Summary', message || 'No admission data available', 'warning', 'ph-chart-bar'));
    }

    return {
        renderLoading,
        render,
        renderFallback
    };
})();

function normalizeAdmissionTables(result) {
    const table1 = getTableData(result, 'Table1');
    const table2 = getTableData(result, 'Table2');
    const summary = table1[0] || {};

    const instituteRows = table2.map(r => ({
        InstituteName: r.InstituteName || 'Unknown Institute',
        CurrentSessionTotal: Number(r.CurrentSessionTotal || 0),
        PreviousSessionTotal: Number(r.PreviousSessionTotal || 0),
        CurrentSessionName: r.CurrentSessionName || null,
        PreviousSessionName: r.PreviousSessionName || null
    }));

    const currentSessionTotal = Number(summary.CurrentSessionTotal || 0);
    const previousSessionTotal = Number(summary.PreviousSessionTotal || 0);
    const differenceCount = Number(summary.DifferenceCount || (currentSessionTotal - previousSessionTotal));
    const comparisonPercent = Number(summary.DifferencePercent || calculateComparisonPercent(currentSessionTotal, previousSessionTotal));

    const currentSessionName = instituteRows.find(x => x.CurrentSessionName)?.CurrentSessionName || 'Current Session';
    const previousSessionName = instituteRows.find(x => x.PreviousSessionName)?.PreviousSessionName || 'Previous Session';

    return {
        instituteCount: Number(summary.InstituteCount || 0),
        userType: summary.UserType || 'MULTIPLE',
        currentSessionTotal,
        previousSessionTotal,
        differenceCount,
        comparisonPercent,
        totalAdmission: currentSessionTotal + previousSessionTotal,
        currentSessionName,
        previousSessionName,
        instituteRows
    };
}

function renderAdmissionChart(chartId, model) {
    const el = document.querySelector('#' + chartId);
    if (!el || typeof ApexCharts === 'undefined') return;

    destroyChart(chartId);

    const rows = (model.instituteRows || []).slice(0, 6);

    if (rows.length === 0) {
        el.innerHTML = '<div class="text-center py-5">No institute data available</div>';
        return;
    }

    dashboardChartInstances[chartId] = new ApexCharts(el, {
        chart: {
            height: 280,
            type: 'bar',
            toolbar: { show: false },
            fontFamily: '"Rubik", sans-serif',
            background: 'transparent'
        },
        series: [
            { name: 'Previous Session', data: rows.map(x => Number(x.PreviousSessionTotal || 0)) },
            { name: 'Current Session', data: rows.map(x => Number(x.CurrentSessionTotal || 0)) }
        ],
        colors: ['#dc3545', '#ffc107'],
        plotOptions: {
            bar: {
                borderRadius: 8,
                columnWidth: '50%',
                borderRadiusApplication: 'end',
                distributed: false
            }
        },
        dataLabels: { enabled: false },
        xaxis: {
            categories: rows.map(x => shortenLabel(x.InstituteName || 'Unknown', 12)),
            labels: {
                style: { fontSize: '10px', fontWeight: 400, colors: '#6b7280' }
            }
        },
        yaxis: {
            labels: {
                formatter: function (val) { return formatSmartValue(val); },
                style: { fontSize: '11px' }
            }
        },
        grid: { borderColor: '#f3f4f6', strokeDashArray: 5 },
        legend: {
            position: 'top',
            horizontalAlign: 'center',
            fontSize: '11px',
            offsetY: 0,
            markers: { radius: 8 }
        },
        tooltip: {
            theme: 'light',
            y: {
                formatter: function (val) { return formatSmartValue(val); }
            }
        }
    });

    dashboardChartInstances[chartId].render();
}