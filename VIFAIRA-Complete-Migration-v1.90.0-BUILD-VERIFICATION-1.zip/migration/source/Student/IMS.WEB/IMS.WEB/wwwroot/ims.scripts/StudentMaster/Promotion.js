﻿$(function () {
    let submitButtonId = "";
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 500); 

    $('#Action').on('change', function () {
        getInstTypeForPromotion($('.ims-institute').val(), $(this).val());
    });

    $('.ims-institute').on('change', function () {
        handleInstituteTypeOnFilterChange($(this).val());
    });

    $(document).on("change", "#checkAll", function () {
        $('.student-check').prop('checked', this.checked);
    });

    $('[data-bs-toggle="tooltip"]').tooltip();

    $(document).on("click", "button[type=submit]", function () {
        submitButtonId = this.id;
    });
    updateLabelsBasedOnInstituteType($('.ims-institute').val());
    $("#form_studpromotion").validate({
        ignore: [],
        rules: {
            Institute: { required: true },
            Session: { required: true },
            Course: { required: true },
            Branch: { required: true },
            semester: {
                required: () => $("#sem").is(":visible")
            },
            Action: {
                required: () => submitButtonId === "promoteBtn"
            },
            promotClass: {
                required: () => submitButtonId === "promoteBtn" && $("#layout_school").is(":visible")
            },
            promotSection: {
                required: () => submitButtonId === "promoteBtn" && $("#layout_school").is(":visible")
            },
            promotSem: {
                required: () => submitButtonId === "promoteBtn" && $("#layout_clg").is(":visible")
            }
        },

        messages: {
            Institute: "Please select Institute",
            Session: "Please select Session",
            Course: "Please select Course",
            Branch: "Please select Branch",
            semester: "Please select Semester",
            Action: "Please select Action To Be Performed",
            promotClass: "Please select Promote Class",
            promotSection: "Please select Promote Section",
            promotSem: "Please select Promote Semester"
        },

        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",

        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback").insertAfter(element);
        },

        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },

        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        },

        submitHandler: function (form, event) {
            event.preventDefault();

            if (submitButtonId === "searchBtn") {
                fetchPromotion(form);
            } else if (submitButtonId === "promoteBtn") {
                // Show confirmation before promoting
                showPromotionConfirmation(form);
            } else {
                ShowNotification("error", "No Event Found");
            }

            setTimeout(() => { submitButtonId = ""; }, 200);
        }
    });
});


function showPromotionConfirmation(form) {
    const selectedCount = $('#promotion_table_layout input:checked').length;
    const action = $('#Action').val();

    let title = 'Are you sure?';
    let text = '';

    if (action === 'Promote') {
        title = 'Confirm Student Promotion';
        text = `You are about to promote ${selectedCount} student(s). This action cannot be undone.`;
    } else if (action === 'ReAdmit') {
        title = 'Confirm Student Re-Admission';
        text = `You are about to re-admit ${selectedCount} student(s).`;
    } else if (action === 'Back') {
        title = 'Confirm Revert to Previous Semester';
        text = `You are about to revert ${selectedCount} student(s) to their previous semester.`;
    } else {
        text = `You are about to perform this action on ${selectedCount} student(s).`;
    }

    Swal.fire({
        title: title,
        text: text,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, proceed!',
        cancelButtonText: 'No, cancel',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary me-2',
            cancelButton: 'btn btn-secondary'
        },
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            PromoteStudents(form);
        } else {
            // Reset the promote button state if cancelled
            $('#promoteBtn').prop('disabled', false).html('Promote Students');
        }
    });
}

async function handleInstituteTypeOnFilterChange(inst) {
    await updateLabelsBasedOnInstituteType(inst);

    if (!inst) {
        $("#sem").removeClass("d-none");
        return;
    }

    const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
        { InId: inst, Action: 'GetInstituteType' }, true);

    let type = res?.result?.[0]?.value || "";

    $('#semester').val("");
    type === "School" ? $("#sem").addClass("d-none") : $("#sem").removeClass("d-none");

    $("#layout_school, #layout_clg").addClass("d-none");
    $("#Action").val("");
}

async function updateLabelsBasedOnInstituteType(inst) {
    if (!inst) {
        $("#programClassLabel").text("Program/Class");
        $("#branchSectionLabel").text("Branch/Section");
        $("#promoteClassLabel").text("Class");
        $("#promoteSectionLabel").text("Section");
        return;
    }

    try {
        const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
            { InId: inst, Action: 'GetInstituteType' }, true);

        let type = res?.result?.[0]?.value || "";

        if (type === "School") {
            $("#programClassLabel").text("Class");
            $("#branchSectionLabel").text("Section");
            $("#promoteClassLabel").text("Class");
            $("#promoteSectionLabel").text("Section");
            $("#Course").prev('label').text("Class");
            $("#Branch").prev('label').text("Section");
            $("#Course option:first").text("--All Classes--");
            $("#Branch option:first").text("--All Sections--");
        } else {
            $("#programClassLabel").text("Program");
            $("#branchSectionLabel").text("Branch");
            $("#promoteClassLabel").text("Program");
            $("#promoteSectionLabel").text("Branch");
            $("#Course").prev('label').text("Program");
            $("#Branch").prev('label').text("Branch");
            $("#Course option:first").text("--All Programs--");
            $("#Branch option:first").text("--All Branches--");
        }
    } catch {
        $("#programClassLabel").text("Program/Class");
        $("#branchSectionLabel").text("Branch/Section");
    }
}

function fetchPromotion(form) {
    const btn = $("#searchBtn");
    const html = btn.html();
    btn.prop("disabled", true).html(`<span class="spinner-border spinner-border-sm"></span> Searching...`);

    $("#promotionOptionsCard, #promoteBtn, #layout_school, #layout_clg").addClass("d-none");
    $("#Action").val("");

    let formData = new FormData(form);
    formData.append('mode', "StudentDetail");

    new IMSClient().request('/Student/Suffling', 'POST', formData, true)
        .then((res) => {
            btn.prop("disabled", false).html(html);

            if (res.statusCode === 200 && res.result?.length) {
                convertStudentArray(res.result);
                exportData = res.result;
                $("#promotionOptionsCard, #layout_promoteType, #promoteBtn").removeClass("d-none");

                ShowNotification("primary", `Found ${res.result.length} student(s)`, "center");
            } else {
                $("#promotionOptionsCard, #promoteBtn").addClass("d-none");
                ShowNotification("danger", "No students found", "center");

                $('#promotion_table_layout').html(`
                    <div class="text-center py-4">
                        <i class="ti ti-users-off fs-1 text-muted"></i>
                        <p class="text-muted mt-2">No students found</p>
                    </div>`);
            }
        })
        .catch(() => {
            btn.prop("disabled", false).html(html);
            ShowNotification("danger", "Something went wrong", "center");
        });
}

function convertStudentArray(data) {
    const rows = [];
    const isSchool = $("#sem").hasClass("d-none");


    data.forEach((item) => {
        // For School data
        if (isSchool) {
            rows.push([
                `<input type="checkbox" class="student-check" value="${item.admissionNo}">`,
                `<span class="badge bg-primary px-3 py-2"><i class="ti ti-user me-1"></i>${item.admissionNo}</span>`,
                item.adm_rollno || '—',
                `<b class="text-primary">${item.sName}</b>`,
                item.instituteName,
                item.batch_Name ? `<span class="badge bg-info px-3 py-2">${item.batch_Name}</span>` : '—',
                item.session_Name,
                `<span class="badge bg-secondary px-3 py-2">${item.course_Name}</span>`,
                `<span class="badge bg-warning text-dark px-3 py-2">${item.branch_Name}</span>`,
                item.admissionStatus === "Active"
                    ? `<span class="badge bg-success"><i class="ti ti-check me-1"></i> Active</span>`
                    : `<span class="badge bg-danger"><i class="ti ti-x me-1"></i> ${item.admissionStatus || 'Inactive'}</span>`
            ]);
        }
        // For College data
        else {
            rows.push([
                `<input type="checkbox" class="student-check" value="${item.admissionNo}">`,
                `<span class="badge bg-primary px-3 py-2"><i class="ti ti-user me-1"></i>${item.admissionNo}</span>`,
                item.adm_rollno || '—',
                `<b class="text-primary">${item.sName}</b>`,
                item.instituteName,
                item.batch_Name ? `<span class="badge bg-info px-3 py-2">${item.batch_Name}</span>` : '—',
                item.session_Name,
                `<span class="badge bg-secondary px-3 py-2">${item.course_Name}</span>`,
                `<span class="badge bg-warning text-dark px-3 py-2">${item.branch_Name}</span>`,
                item.semester_Name ? `<span class="badge bg-dark px-3 py-2">${item.semester_Name}</span>` : '—',
                item.admissionStatus === "Active"
                    ? `<span class="badge bg-success"><i class="ti ti-check me-1"></i> Active</span>`
                    : `<span class="badge bg-danger"><i class="ti ti-x me-1"></i> ${item.admissionStatus || 'Inactive'}</span>`
            ]);
        }
    });

    datasetStudentTable(rows, isSchool);
}

function datasetStudentTable(dataRows, isSchool) {
    $('#promotion_table_layout').html(`
        <table class="display table-bottom-border app-data-table table-box-hover w-100" id="studentTable"></table>
    `);

    // Define columns based on institute type
    const cols = isSchool ? [
        { title: `<input type="checkbox" id="checkAll">`, width: "50px" },
        { title: "Admission No", width: "120px" },
        { title: "Roll No", width: "100px" },
        { title: "Student Name", width: "200px" },
        { title: "Institute", width: "150px" },
        { title: "Batch", width: "100px" },
        { title: "Session", width: "120px" },
        { title: "Class", width: "100px" },
        { title: "Section", width: "100px" },
        { title: "Status", width: "100px" }
    ] : [
        { title: `<input type="checkbox" id="checkAll">`, width: "50px" },
        { title: "Admission No", width: "120px" },
        { title: "Roll No", width: "100px" },
        { title: "Student Name", width: "200px" },
        { title: "Institute", width: "150px" },
        { title: "Batch", width: "100px" },
        { title: "Session", width: "120px" },
        { title: "Program", width: "120px" },
        { title: "Branch", width: "120px" },
        { title: "Semester", width: "100px" },
        { title: "Status", width: "100px" }
    ];

    $('#studentTable').DataTable({
        data: dataRows,
        paging: true,
        ordering: false,
        searching: false,
        pageLength: 10,
        lengthChange: false,
        autoWidth: false,
        scrollX: true,
        destroy: true,
        responsive: true,
        columns: cols,
        language: {
            emptyTable: "No students found",
            zeroRecords: "No matching students found"
        },
        dom: '<"top">rt<"bottom"lip><"clear">'
    });

    // Re-initialize checkAll functionality
    $(document).off("change", "#checkAll").on("change", "#checkAll", function () {
        $('.student-check').prop('checked', this.checked);
    });
}

async function getInstTypeForPromotion(inst, promoteType) {
    if (!inst || promoteType !== "Promote") return;

    const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
        { InId: inst, Action: 'GetInstituteType' }, true);

    let type = res?.result?.[0]?.value || "";

    $("#layout_school, #layout_clg").addClass("d-none");

    if (type === "School") $("#layout_school").removeClass("d-none");
    if (type === "College") $("#layout_clg").removeClass("d-none");
}

function PromoteStudents(form) {
    const btn = $("#promoteBtn");
    const originalHTML = btn.html();

    btn.prop("disabled", true).html(`
        <span class="spinner-border spinner-border-sm"></span> Processing...
    `);

    let formData = new FormData(form);
    let AdmNo = $('#promotion_table_layout .student-check:checked')
        .map(function () {
            return this.value;
        })
        .get()
        .join(';');



    if (!AdmNo.trim()) {
        btn.prop("disabled", false).html(originalHTML);
        Swal.fire({
            icon: 'error',
            title: 'No Students Selected',
            text: 'Please select at least one student.',
            confirmButtonColor: '#d33'
        });
        return;
    }

    formData.append("Admno", AdmNo);
    formData.append("Userid", window.currentUser?.UserId || "System");

    new IMSClient().request('/Student/Promote', 'POST', formData, true)
        .then((res) => {
            btn.prop("disabled", false).html(originalHTML);

            if (res.statusCode === 200) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: res.message || "Students promoted successfully!",
                    confirmButtonColor: '#3085d6'
                });

                resetAfterPromotion();
            }
            else if (res.statusCode === 300) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Warning',
                    text: res.message || "Promotion completed with warnings.",
                    confirmButtonColor: '#f59e0b'
                });
            }
            else {
                Swal.fire({
                    icon: 'error',
                    title: 'Failed',
                    text: res.message || "Promotion failed.",
                    confirmButtonColor: '#d33'
                });
            }
        })
        .catch((error) => {
            btn.prop("disabled", false).html(originalHTML);

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error.message || "Something went wrong during promotion.",
                confirmButtonColor: '#d33'
            });
        });
}

function resetAfterPromotion() {
    $('#form_studpromotion')[0]?.reset();
    clearFormValidation();
    clearStudentTable();
    resetUIState();
}

function clearFormValidation() {
    $('.form-control').removeClass('is-invalid is-valid');
    $('.invalid-feedback').remove();

    const validator = $('#form_studpromotion').validate();
    if (validator) validator.resetForm();
}

function clearStudentTable() {
    if ($.fn.DataTable && $.fn.DataTable.isDataTable('#studentTable')) {
        $('#studentTable').DataTable().destroy();
    }

    $('#promotion_table_layout').html(`
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-users fa-2x text-muted mb-3"></i>
                <h5 class="text-muted">No Students Found</h5>
                <p class="text-muted">Search again to view students.</p>
            </div>
        </div>
    `);
}

function resetUIState() {
    $("#promotionOptionsCard").addClass("d-none");
    $("#layout_promoteType").addClass("d-none");
    $("#promoteBtn").addClass("d-none");
    $("#layout_school, #layout_clg").addClass("d-none");

    $('input[type="checkbox"]').prop('checked', false);

    if ($.fn.select2) {
        $('select').val(null).trigger('change');
    } else {
        $('select').val('');
    }

    $('button[type="submit"]').prop('disabled', false);

    $('#searchBtn').html('Search');
    $('#promoteBtn').html('Promote Students');
}