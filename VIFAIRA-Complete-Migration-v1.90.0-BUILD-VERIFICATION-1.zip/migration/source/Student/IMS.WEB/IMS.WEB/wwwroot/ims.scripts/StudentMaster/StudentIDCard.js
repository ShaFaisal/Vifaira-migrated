﻿$(function () {
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 500); 

    updateLabelsBasedOnInstituteType($('.ims-institute').val());
    $('[data-bs-toggle="tooltip"]').tooltip();

    // Initialize form validation
    initFormValidation();

    // Search button handler
    $('#searchBtn').on('click', function (e) {
        e.preventDefault();
        if ($("#formIDCARD").valid()) {
            fetchPromotion($('#formIDCARD')[0]);
        }
    });

    // Generate ID Cards button (Print button)
    $('#openModal').on('click', function () {
        generateIDCards();
    });

    // Print button in modal
    $('#btnPrintCard').on('click', function () {
        printIDCardsDirect();
    });

    // Institute change handler
    $('.ims-institute').on('change', function () {
        handleInstituteTypeOnFilterChange($(this).val());
    });

    // Check All checkbox
    $(document).on("change", "#checkAll", function () {
        $('.student-check').prop('checked', this.checked);
        updateSelectedCountDisplay();
    });

    // Individual student checkbox change
    $(document).on('change', '.student-check', function () {
        updateSelectedCountDisplay();
        updateCheckAllCheckbox();
    });
});

// Initialize form validation
function initFormValidation() {
    $("#formIDCARD").validate({
        ignore: [],
        rules: {
            Institute: { required: true },
            Session: { required: true },
            Course: { required: true },
            Branch: { required: true },
            semester: {
                required: function () {
                    return $("#sem").is(":visible");
                }
            }
        },
        messages: {
            Institute: "Please select Institute",
            Session: "Please select Session",
            Course: "Please select Course",
            Branch: "Please select Branch",
            semester: "Please select Semester"
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback").insertAfter(element);
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        },
        submitHandler: function (form, event) {
            event.preventDefault();
            fetchPromotion(form);
        }
    });
}

// Update selected count display
function updateSelectedCountDisplay() {
    const selectedCount = getSelectedStudentCount();
    $('#selectedCountDisplay').text(selectedCount);

    // Update print button text
    const printBtn = $('#openModal');
    if (selectedCount > 0) {
        printBtn.html(`<i class="fas fa-id-card"></i> PRINT (${selectedCount})`);
    } else {
        printBtn.html(`<i class="fas fa-id-card"></i> PRINT`);
    }
}

// Update check all checkbox based on individual selections
function updateCheckAllCheckbox() {
    const totalStudents = $('.student-check').length;
    const selectedStudents = $('.student-check:checked').length;

    if (totalStudents === 0) {
        $('#checkAll').prop('checked', false);
        $('#checkAll').prop('disabled', true);
    } else {
        $('#checkAll').prop('disabled', false);
        $('#checkAll').prop('checked', selectedStudents === totalStudents);
    }
}

// Generate ID Cards
function generateIDCards() {
    let selectedStudents = getSelectedStudents();

    if (selectedStudents.length === 0) {
        ShowNotification("warning", "Please select at least one student", "center");
        return;
    }

    if (selectedStudents.length > 50) {
        ShowNotification("warning", "Please select maximum 50 students at a time", "center");
        return;
    }

    showLoadingState(true);

    let parms = {
        StudentID: selectedStudents.join(','),
        InstituteID: $('#Institute').val()
    };

    $.ajax({
        url: "/Api/Student/IDCardPreview",
        method: "POST",
        data: parms,
        success: function (html) {
            $("#idCardPreview").html(html);
            new bootstrap.Modal("#idCardModal").show();
            showLoadingState(false);
            ShowNotification("success", `Generated ${selectedStudents.length} ID Card(s)`, "center");
        },
        error: function (xhr, status, error) {
            ShowNotification("danger", "Error generating ID cards: " + error, "center");
            showLoadingState(false);
        }
    });
}

// Get selected students
function getSelectedStudents() {
    return $('#promotion_table_layout input.student-check:checked')
        .map(function () { return this.value; })
        .get();
}

// Print ID Cards
function printIDCardsDirect() {
    var originalContents = document.body.innerHTML;
    var printContents = document.getElementById("idCardPreview").innerHTML;

    if (!printContents || printContents.trim() === '') {
        ShowNotification("warning", "No ID Cards to print", "center");
        return;
    }

    // Check if it's just the empty state
    if (printContents.includes('No ID Cards to Preview') ||
        printContents.includes('fas fa-id-card fa-3x')) {
        ShowNotification("warning", "No ID Cards to print", "center");
        return;
    }

    // Hide all elements except print content
    var originalBody = document.body.cloneNode(true);
    var printDiv = document.createElement('div');
    printDiv.innerHTML = printContents;

    // Hide current body content
    var allElements = document.body.children;
    for (var i = 0; i < allElements.length; i++) {
        allElements[i].style.display = 'none';
    }

    // Add print content
    document.body.appendChild(printDiv);

    // Print
    window.print();

    // Restore original content
    document.body.removeChild(printDiv);
    for (var i = 0; i < allElements.length; i++) {
        allElements[i].style.display = '';
    }

    // Show success message
    ShowNotification("success", "Print completed successfully", "center");
}

// Show loading state
function showLoadingState(show) {
    const btn = $("#openModal");
    if (show) {
        btn.prop("disabled", true).html(`<span class="spinner-border spinner-border-sm"></span> Generating...`);
    } else {
        const selectedCount = getSelectedStudentCount();
        if (selectedCount > 0) {
            btn.prop("disabled", false).html(`<i class="fas fa-id-card"></i> PRINT (${selectedCount})`);
        } else {
            btn.prop("disabled", false).html(`<i class="fas fa-id-card"></i> PRINT`);
        }
    }
}

// Get selected student count
function getSelectedStudentCount() {
    return $('.student-check:checked').length;
}

// Toggle select all
function toggleSelectAll(selectAll) {
    $('.student-check').prop('checked', selectAll);
    $('#checkAll').prop('checked', selectAll);
    updateSelectedCountDisplay();
}

// Refresh student list
function refreshStudentList() {
    $('#searchBtn').click();
}

// Clear all selections
function clearAllSelections() {
    $('.student-check').prop('checked', false);
    $('#checkAll').prop('checked', false);
    updateSelectedCountDisplay();
    ShowNotification("info", "All selections cleared", "center");
}

// Validate before generate
function validateBeforeGenerate() {
    const selectedCount = getSelectedStudentCount();
    if (selectedCount === 0) {
        ShowNotification("warning", "Please select at least one student", "center");
        return false;
    }
    if (selectedCount > 50) {
        ShowNotification("warning", "Please select maximum 50 students at a time", "center");
        return false;
    }
    return true;
}

// Handle institute type change
async function handleInstituteTypeOnFilterChange(inst) {
    await updateLabelsBasedOnInstituteType(inst);

    if (!inst) {
        $("#sem").removeClass("d-none");
        return;
    }

    const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
        { InId: inst, Action: 'GetInstituteType' }, true);

    let type = res?.result?.[0]?.value || "";

    $('#semester').val("");
    type === "School" ? $("#sem").addClass("d-none") : $("#sem").removeClass("d-none");
}

// Update labels based on institute type
async function updateLabelsBasedOnInstituteType(inst) {
    if (!inst) {
        $("#programClassLabel").text("Program/Class");
        $("#branchSectionLabel").text("Branch/Section");
        $("#Course").prev('label').text("Program/Class");
        $("#Branch").prev('label').text("Branch/Section");
        $("#Course option:first").text("--All Programs--");
        $("#Branch option:first").text("--All Branches--");
        return;
    }

    try {
        const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
            { InId: inst, Action: 'GetInstituteType' }, true);

        let type = res?.result?.[0]?.value || "";

        if (type === "School") {
            $("#programClassLabel").text("Class");
            $("#branchSectionLabel").text("Section");
            $("#Course").prev('label').text("Class");
            $("#Branch").prev('label').text("Section");
            $("#Course option:first").text("--All Classes--");
            $("#Branch option:first").text("--All Sections--");
        } else {
            $("#programClassLabel").text("Program");
            $("#branchSectionLabel").text("Branch");
            $("#Course").prev('label').text("Program");
            $("#Branch").prev('label').text("Branch");
            $("#Course option:first").text("--All Programs--");
            $("#Branch option:first").text("--All Branches--");
        }
    } catch {
        $("#programClassLabel").text("Program/Class");
        $("#branchSectionLabel").text("Branch/Section");
        $("#Course").prev('label').text("Program/Class");
        $("#Branch").prev('label').text("Branch/Section");
    }
}

// Fetch promotion data
async function fetchPromotion(form) {
    const btn = $("#searchBtn");
    const html = btn.html();
    btn.prop("disabled", true).html(`<span class="spinner-border spinner-border-sm"></span> Searching...`);

    $("#promotionOptionsCard, #promoteBtn, #layout_school, #layout_clg").addClass("d-none");
    $("#Action").val("");

    let formData = new FormData(form);
    formData.append('mode', "StudentDetail");

    await new IMSClient().request('/Student/Suffling', 'POST', formData, true)
        .then((res) => {
            btn.prop("disabled", false).html(html);

            if (res.statusCode === 200 && res.result?.length) {

                convertStudentArray(res.result);
                ShowNotification("success", `Found ${res.result.length} student(s)`, "center");
                updateSelectedCountDisplay();
                updateCheckAllCheckbox();
            } else {
                $("#promotionOptionsCard, #promoteBtn").addClass("d-none");
                ShowNotification("info", "No students found", "center");

                $('#promotion_table_layout').html(`
                    <div class="text-center py-5">
                        <i class="ti ti-users-off fs-1 text-muted"></i>
                        <p class="text-muted mt-2">No students found</p>
                    </div>`);

                // Reset counts
                updateSelectedCountDisplay();
                updateCheckAllCheckbox();
            }
        })
        .catch(() => {
            btn.prop("disabled", false).html(html);
            ShowNotification("danger", "Something went wrong", "center");
        });
}

// Convert student array to table
function convertStudentArray(data) {
    const rows = [];
    const isSchool = $("#sem").hasClass("d-none");

    data.forEach((item) => {
        if (isSchool) {
            rows.push([
                `<input type="checkbox" class="student-check" value="${item.admissionNo}">`,
                `<span class="badge bg-primary px-3 py-2"><i class="ti ti-user me-1"></i>${item.admissionNo}</span>`,
                item.adm_rollno || '—',
                `<b class="text-primary">${item.sName}</b>`,
                item.instituteName,
                item.batch_Name ? `<span class="badge bg-info px-3 py-2">${item.batch_Name}</span>` : '—',
                item.session_Name,
                `<span class="badge bg-secondary px-3 py-2">${item.course_Name}</span>`,
                `<span class="badge bg-warning text-dark px-3 py-2">${item.branch_Name}</span>`,
                item.admissionStatus === "Active"
                    ? `<span class="badge bg-success"><i class="ti ti-check me-1"></i> Active</span>`
                    : `<span class="badge bg-danger"><i class="ti ti-x me-1"></i> ${item.admissionStatus || 'Inactive'}</span>`
            ]);
        } else {
            rows.push([
                `<input type="checkbox" class="student-check" value="${item.admissionNo}">`,
                `<span class="badge bg-primary px-3 py-2"><i class="ti ti-user me-1"></i>${item.admissionNo}</span>`,
                item.adm_rollno || '—',
                `<b class="text-primary">${item.sName}</b>`,
                item.instituteName,
                item.batch_Name ? `<span class="badge bg-info px-3 py-2">${item.batch_Name}</span>` : '—',
                item.session_Name,
                `<span class="badge bg-secondary px-3 py-2">${item.course_Name}</span>`,
                `<span class="badge bg-warning text-dark px-3 py-2">${item.branch_Name}</span>`,
                item.semester_Name ? `<span class="badge bg-dark px-3 py-2">${item.semester_Name}</span>` : '—',
                item.admissionStatus === "Active"
                    ? `<span class="badge bg-success"><i class="ti ti-check me-1"></i> Active</span>`
                    : `<span class="badge bg-danger"><i class="ti ti-x me-1"></i> ${item.admissionStatus || 'Inactive'}</span>`
            ]);
        }
    });

    datasetStudentTable(rows, isSchool);
}

// Dataset student table
function datasetStudentTable(dataRows, isSchool) {
    $('#promotion_table_layout').html(`
        <table class="display table-bottom-border app-data-table table-box-hover w-100" id="studentTable"></table>
    `);

    const cols = isSchool ? [
        { title: `<input type="checkbox" id="checkAllHeader">`, width: "50px" },
        { title: "Admission No", width: "120px" },
        { title: "Roll No", width: "100px" },
        { title: "Student Name", width: "200px" },
        { title: "Institute", width: "150px" },
        { title: "Batch", width: "100px" },
        { title: "Session", width: "120px" },
        { title: "Class", width: "100px" },
        { title: "Section", width: "100px" },
        { title: "Status", width: "100px" }
    ] : [
        { title: `<input type="checkbox" id="checkAllHeader">`, width: "50px" },
        { title: "Admission No", width: "120px" },
        { title: "Roll No", width: "100px" },
        { title: "Student Name", width: "200px" },
        { title: "Institute", width: "150px" },
        { title: "Batch", width: "100px" },
        { title: "Session", width: "120px" },
        { title: "Program", width: "120px" },
        { title: "Branch", width: "120px" },
        { title: "Semester", width: "100px" },
        { title: "Status", width: "100px" }
    ];

    $('#studentTable').DataTable({
        data: dataRows,
        paging: true,
        ordering: false,
        searching: false,
        pageLength: 10,
        lengthChange: false,
        autoWidth: false,
        scrollX: true,
        destroy: true,
        responsive: true,
        columns: cols,
        language: {
            emptyTable: "No students found",
            zeroRecords: "No matching students found"
        },
        dom: '<"top">rt<"bottom"lip><"clear">',
        drawCallback: function () {
            // Update checkboxes after table is drawn
            updateCheckAllCheckbox();
            updateSelectedCountDisplay();
        }
    });

    // Re-initialize checkAll functionality for header checkbox
    $(document).off("change", "#checkAllHeader").on("change", "#checkAllHeader", function () {
        $('.student-check').prop('checked', this.checked);
        $('#checkAll').prop('checked', this.checked);
        updateSelectedCountDisplay();
    });
}