﻿let issueTcNsoModalInstance = null;
let selectedStudentMeta = null;
let currentTcQuestionList = [];
let currentStudentAutoData = null;
let isListLoading = false;
let isIssueSaving = false;
let issueTcStudentTableInstance = null;

$(function () {
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 500);

    bindIssueTcEvents();
    initSearchValidation();
    initIssueValidation();
    initIssueTcEmptyState();
    setTodayDate();
    ensureTopActionBar();

    $('#issueTcNsoModal').on('hidden.bs.modal', function () {
        resetIssueForm();
    });
});

function bindIssueTcEvents() {
    $('#BtnSave').off('click').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        $('#form_isseuTC').trigger('submit');
        return false;
    });

    $('#form_isseuTC').off('submit').on('submit', function (e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        if (isListLoading) return false;

        if ($(this).valid()) {
            fetchStudentDetailList();
        }
        return false;
    });

    $('#form_isseuTC').off('keydown.issueenter').on('keydown.issueenter', 'input', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            $('#form_isseuTC').trigger('submit');
            return false;
        }
    });

    $('#refreshsubjectTable').off('click').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        resetSearchArea();
        return false;
    });

    $('#IssueType').off('change').on('change', async function () {
        const val = ($(this).val() || 'TC').toUpperCase();

        if (val === 'TC') {
            $('#IssueSubStatus').val('Transferred');
        } else if (val === 'NSO') {
            $('#IssueSubStatus').val('Regular');
        } else {
            $('#IssueSubStatus').val('Regular');
        }

        updateTypeBadge(val);

        if (selectedStudentMeta) {
            await loadTcQuestionsForIssue(selectedStudentMeta);
        }
    });

    $('#btnSaveTcNso').off('click').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (isIssueSaving) return false;
        saveStudentTcNso();
        return false;
    });

    $('#formIssueTcNso').off('submit').on('submit', function (e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        if (isIssueSaving) return false;
        saveStudentTcNso();
        return false;
    });

    $('#formIssueTcNso').off('keydown.issueform').on('keydown.issueform', 'input, select, textarea', function (e) {
        if (e.key === 'Enter' && $(this).prop('tagName').toLowerCase() !== 'textarea') {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
    });

    $(document).off('click', '.btn-issue-tc-nso').on('click', '.btn-issue-tc-nso', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $btn = $(this);

        const meta = {
            studentId: $btn.data('studentid') || '',
            institute: $btn.data('institute') || '',
            session: $btn.data('session') || '',
            course: $btn.data('course') || '',
            branch: $btn.data('branch') || '',
            photo: $btn.data('photo') || '',
            studentName: $btn.data('studentname') || '',
            fatherName: $btn.data('fathername') || '',
            motherName: $btn.data('mothername') || '',
            className: $btn.data('classname') || '',
            branchName: $btn.data('branchname') || '',
            sessionName: $btn.data('sessionname') || '',
            instituteName: $btn.data('institutename') || '',
            admissionNo: $btn.data('admissionno') || '',
            balance: $btn.data('balance') || ''
        };

        openIssueModal(meta);
        return false;
    });
}

function ensureTopActionBar() {
    if ($('#issueTcTopActionBar').length) return;

    const html = `
        <div id="issueTcTopActionBar" class="d-flex justify-content-end align-items-center gap-2 mb-2">
            <button type="button" id="btnPrintSelectedTc" class="btn btn-outline-success btn-sm rounded-pill px-3" style="display:none;">
                <i class="ti ti-printer me-1"></i> Print Selected
            </button>
        </div>
    `;

    $('#table_layout').before(html);
}

function initSearchValidation() {
    if ($("#form_isseuTC").data('validator')) {
        $("#form_isseuTC").removeData("validator");
        $("#form_isseuTC").removeData("unobtrusiveValidation");
    }

    $("#form_isseuTC").validate({
        ignore: [],
        rules: {
            SchoolID: { required: true }
        },
        messages: {
            SchoolID: "Please select Institute"
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback").insertAfter(element);
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        }
    });
}

function initIssueValidation() {
    if ($("#formIssueTcNso").data('validator')) {
        $("#formIssueTcNso").removeData("validator");
        $("#formIssueTcNso").removeData("unobtrusiveValidation");
    }

    $("#formIssueTcNso").validate({
        ignore: [],
        rules: {
            Type: { required: true },
            Date: { required: true },
            Remark: { required: true }
        },
        messages: {
            Type: "Please select Type",
            Date: "Please select Date",
            Remark: "Please enter Remark"
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback").insertAfter(element);
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        }
    });
}

function setTodayDate() {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    $('#Date').val(`${yyyy}-${mm}-${dd}`);
}

function initIssueTcEmptyState() {
    $('#table_layout').html(`
        <div class="text-center py-5">
            <i class="fas fa-id-card fa-3x text-muted opacity-25"></i>
            <h5 class="text-muted fw-semibold mt-2">No Student Data Found</h5>
            <p class="text-muted mb-2">Use filters above to load eligible student records for TC / NSO.</p>
        </div>
    `);

    $('#totalSubjects').text('0');
    $('#lastUpdated').text('Just now');
    $('#btnPrintSelectedTc').hide();
}

async function fetchStudentDetailList() {
    if (isListLoading) return;

    const btn = $('#BtnSave');
    const html = btn.html();

    isListLoading = true;
    btn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Searching...`);

    try {
        const parms = {
            Institute: $('#SchoolID').val() || '',
            Session: $('#SessionId').val() || '',
            Course: $('#clsid').val() || '',
            Branch: $('#SectionID').val() || '',
            Status: $('#Status').val() || '',
            SubStatus: $('#SubStatus').val() || '',
            txtSearch: $('#txtSearch').val() || '',
            mode: 'StudentDetail'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        let data = normalizeResultArray(res);

        data = dedupeStudentRows(data);

        if (Array.isArray(data) && data.length > 0) {
            renderStudentTable(data);
            $('#totalSubjects').text(data.length);
            $('#lastUpdated').text(new Date().toLocaleTimeString());
            ShowNotification("success", `Found ${data.length} student(s)`, "center");
        } else {
            initIssueTcEmptyState();
            ShowNotification("info", "No student found", "center");
        }

    } catch (error) {
        initIssueTcEmptyState();
        console.error(error);
        ShowNotification("danger", "Something went wrong", "center");
    } finally {
        isListLoading = false;
        btn.prop('disabled', false).html(html);
    }
}

function dedupeStudentRows(data) {
    if (!Array.isArray(data)) return [];

    const map = new Map();

    data.forEach(item => {
        const admissionNo = getValueByKeyContains(item, ['admissionno', 'admno'], '').trim();
        const studentId = getValueByKeyContains(item, ['stu_id', 'studentid', 'student_id'], '').trim();
        const key = `${admissionNo}|${studentId}`;

        if (!admissionNo && !studentId) return;

        if (!map.has(key)) {
            map.set(key, item);
            return;
        }

        const oldItem = map.get(key);

        const oldBalance = parseFloat(getValueByKeyContains(oldItem, ['balance'], 0) || 0);
        const newBalance = parseFloat(getValueByKeyContains(item, ['balance'], 0) || 0);

        if (newBalance > oldBalance) {
            map.set(key, item);
        }
    });

    return Array.from(map.values());
}

function renderStudentTable(data) {
    const rows = data.map((item, index) => {
        const admissionNo = getValueByKeyContains(item, ['admissionno', 'admno'], '');
        const regNo = getValueByKeyContains(item, ['adm_regno', 'regno'], '');
        const rollNo = getValueByKeyContains(item, ['adm_rollno', 'rollno'], '');
        const studentName = getValueByKeyContains(item, ['studentname', 'sname'], '');
        const studentId = getValueByKeyContains(item, ['stu_id', 'studentid', 'student_id'], admissionNo);
        const fatherName = getValueByKeyContains(item, ['fathername'], '');
        const motherName = getValueByKeyContains(item, ['mothername'], '');
        const courseName = getValueByKeyContains(item, ['course_name', 'classname', 'course'], '');
        const branchName = getValueByKeyContains(item, ['branch_name', 'sectionname', 'branch'], '');
        const sessionName = getValueByKeyContains(item, ['session_name', 'batch_name', 'session'], '');
        const instituteName = getValueByKeyContains(item, ['institutename'], '');
        const instituteId = getValueByKeyContains(item, ['institute_id', 'school', 'institute'], '');
        const sessionId = getValueByKeyContains(item, ['session_id'], '');
        const courseId = getValueByKeyContains(item, ['course_id', 'class'], '');
        const branchId = getValueByKeyContains(item, ['branch_id', 'section'], '');
        const status = getValueByKeyContains(item, ['admissionstatus', 'status'], '');
        const subStatus = getValueByKeyContains(item, ['admissionsubstatus', 'substatus'], '');
        const balance = parseFloat(getValueByKeyContains(item, ['balance'], 0) || 0);
        const studentPhoto = getValueByKeyContains(item, ['picture', 'photo'], '');

        const balanceHtml = balance <= 0
            ? `<span class="badge bg-success-subtle text-success border rounded-pill">0 / Clear</span>`
            : `<span class="badge bg-danger-subtle text-danger border rounded-pill">${escapeHtml(balance.toString())}</span>`;

        const actionHtml = `
            <button type="button"
                    class="btn btn-outline-primary btn-sm btn-issue-tc-nso"
                    data-studentid="${escapeHtml(studentId)}"
                    data-institute="${escapeHtml(instituteId)}"
                    data-session="${escapeHtml(sessionId)}"
                    data-course="${escapeHtml(courseId)}"
                    data-branch="${escapeHtml(branchId)}"
                    data-photo="${escapeHtml(studentPhoto)}"
                    data-studentname="${escapeHtml(studentName)}"
                    data-fathername="${escapeHtml(fatherName)}"
                    data-mothername="${escapeHtml(motherName)}"
                    data-classname="${escapeHtml(courseName)}"
                    data-branchname="${escapeHtml(branchName)}"
                    data-sessionname="${escapeHtml(sessionName)}"
                    data-institutename="${escapeHtml(instituteName)}"
                    data-admissionno="${escapeHtml(admissionNo)}"
                    data-balance="${escapeHtml(balance.toString())}">
                <i class="ti ti-file-certificate me-1"></i> Issue
            </button>
        `;

        return [
            index + 1,
            escapeHtml(admissionNo),
            escapeHtml(regNo),
            escapeHtml(rollNo),
            escapeHtml(studentName),
            escapeHtml(fatherName),
            escapeHtml(courseName),
            escapeHtml(branchName),
            escapeHtml(sessionName),
            `<span class="badge text-dark border rounded-pill">${escapeHtml(status || '-')}</span>`,
            `<span class="badge text-dark border rounded-pill">${escapeHtml(subStatus || '-')}</span>`,
            balanceHtml,
            actionHtml
        ];
    });

    const tableHtml = `
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-header bg-transparent py-2 px-3 border-bottom">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <h6 class="mb-0 small fw-semibold text-dark">
                        <i class="fas fa-users me-1 text-info"></i> Student List
                    </h6>
                    <span class="badge bg-primary-subtle text-primary border rounded-pill px-3 py-2">
                        Total: ${data.length}
                    </span>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive app-scroll app-datatable-default project-table">
                    <table class="table table-bordered table-sm table-hover mb-0 align-middle" id="issueTcStudentTable"></table>
                </div>
            </div>
        </div>
    `;

    $('#table_layout').html(tableHtml);

    if ($.fn.DataTable.isDataTable('#issueTcStudentTable')) {
        $('#issueTcStudentTable').DataTable().destroy();
        $('#issueTcStudentTable').empty();
    }

    issueTcStudentTableInstance = $('#issueTcStudentTable').DataTable({
        data: rows,
        paging: true,
        lengthChange: false,
        searching: false,
        ordering: false,
        info: true,
        autoWidth: false,
        responsive: false,
        scrollX: true,
        destroy: true,
        columns: [
            { title: 'Sr No', width: "60px", className: "align-middle text-center" },
            { title: 'Adm No', width: "120px", className: "align-middle" },
            { title: 'Reg No', width: "100px", className: "align-middle" },
            { title: 'Roll No', width: "100px", className: "align-middle" },
            { title: 'Student Name', width: "220px", className: "align-middle" },
            { title: 'Father Name', width: "180px", className: "align-middle" },
            { title: 'Class', width: "100px", className: "align-middle text-center" },
            { title: 'Section', width: "100px", className: "align-middle text-center" },
            { title: 'Session', width: "120px", className: "align-middle text-center" },
            { title: 'Status', width: "100px", className: "align-middle text-center" },
            { title: 'Sub Status', width: "120px", className: "align-middle text-center" },
            { title: 'Balance', width: "110px", className: "align-middle text-center" },
            { title: 'Action', width: "140px", className: "align-middle text-center" }
        ],
        headerCallback: function (thead) {
            $(thead).find('th').addClass('fw-semibold text-dark border-bottom py-3 px-3 small');
        }
    });

    $('#btnPrintSelectedTc').hide();
}

async function openIssueModal(meta) {
    try {
        resetIssueForm();

        selectedStudentMeta = meta;

        $('#ModalInstitute').val(meta.institute || '');
        $('#ModalSession').val(meta.session || '');
        $('#ModalCourse').val(meta.course || '');
        $('#ModalBranch').val(meta.branch || '');
        $('#ModalStudentID').val(meta.studentId || '');
        $('#CreatedBy').val($('#hdnUserID').val() || $('#UserID').val() || '');

        fillIssueStudentCard(meta);

        const defaultType = ($('#IssueType').val() || 'TC').toUpperCase();
        if (defaultType === 'TC') {
            $('#IssueSubStatus').val('Transferred');
        } else if (defaultType === 'NSO') {
            $('#IssueSubStatus').val('Regular');
        } else {
            $('#IssueSubStatus').val('Regular');
        }

        updateTypeBadge(defaultType);

        const modalEl = document.getElementById('issueTcNsoModal');
        issueTcNsoModalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
        issueTcNsoModalInstance.show();

        await loadStudentAutoData(meta);
        await loadTcQuestionsForIssue(meta);

    } catch (error) {
        console.error(error);
        ShowNotification("danger", "Unable to load student details", "center");
    }
}

async function loadStudentAutoData(meta) {
    currentStudentAutoData = null;

    try {
        const parms = {
            StudID: meta.studentId || meta.admissionNo || '',
            StudentID: meta.studentId || meta.admissionNo || '',
            Institute: $('#SchoolID').val() || meta.institute || '',
            Batch: $('#SessionId').val() || meta.session || '',
            Session: $('#SessionId').val() || meta.session || '',
            Course: $('#clsid').val() || meta.course || '',
            Branch: $('#SectionID').val() || meta.branch || '',
            mode: 'GetStudentSearchForTC'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const data = normalizeResultArray(res);

        if (Array.isArray(data) && data.length > 0) {
            currentStudentAutoData = data[0];
            applyStudentAutoData(currentStudentAutoData, meta);
        }
    } catch (error) {
        console.error(error);
    }
}

function applyStudentAutoData(data, meta) {
    const admissionNo = getValueByKeyContains(data, ['admno', 'admissionno'], meta.admissionNo || meta.studentId || '-');
    const studentName = getValueByKeyContains(data, ['studentname', 'sname'], meta.studentName || '-');
    const fatherName = getValueByKeyContains(data, ['fathername'], meta.fatherName || '-');
    const motherName = getValueByKeyContains(data, ['mothername'], meta.motherName || '-');
    const className = getValueByKeyContains(data, ['course_name', 'classname', 'course'], meta.className || '-');
    const branchName = getValueByKeyContains(data, ['branch_name', 'sectionname', 'branch'], meta.branchName || '-');
    const sessionName = getValueByKeyContains(data, ['session_name', 'batch_name', 'session'], meta.sessionName || '-');
    const instituteName = getValueByKeyContains(data, ['institutename'], meta.instituteName || '-');
    const studentId = getValueByKeyContains(data, ['studentid', 'stu_id', 'student_id'], meta.studentId || admissionNo || '-');
    const dob = getValueByKeyContains(data, ['dob'], '-');

    const duesText = getValueByKeyContains(data, ['dues'], '-');
    const relaxationText = getValueByKeyContains(data, ['relaxation'], '-');
    const schoolNo = getValueByKeyContains(data, ['schoolno'], '');
    const affliationNo = getValueByKeyContains(data, ['affliationno', 'affiliationno'], '');
    const renewed = getValueByKeyContains(data, ['renewed', 'renewedup'], '');
    const registrationNo = getValueByKeyContains(data, ['registrationno', 'registartionno'], '');
    const serialNo = getValueByKeyContains(data, ['serialno', 'srno'], '');
    const category = getValueByKeyContains(data, ['category'], '');
    const categoryName = getValueByKeyContains(data, ['category_name'], '');

    $('#DisplayStudentNameText').text(studentName);
    $('#DisplayAdmissionNoText').text(admissionNo);
    $('#DisplayFatherNameText').text(fatherName);
    $('#DisplayMotherNameText').text(motherName);
    $('#DisplayDobText').text(dob);
    $('#DisplayClassText').text(className);
    $('#DisplayBranchText').text(branchName);
    $('#DisplaySessionText').text(sessionName);
    $('#DisplayInstituteText').text(instituteName);
    $('#DisplayStudentIdText').text(studentId);

    $('#DisplayDuesBadge')
        .removeClass('bg-warning-subtle text-warning bg-success-subtle text-success bg-danger-subtle text-danger text-bg-primary')
        .addClass(String(duesText).toLowerCase() === 'yes' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning')
        .html(`<i class="ti ti-wallet me-1"></i> ${escapeHtml(duesText)}`);

    $('#DisplayAdmissionNo').val(admissionNo);
    $('#DisplayStudentName').val(studentName);
    $('#DisplayFatherName').val(fatherName);
    $('#DisplayMotherName').val(motherName);
    $('#DisplayClass').val(className);
    $('#DisplaySession').val(sessionName);
    $('#DisplayInstitute').val(instituteName);
    $('#DisplayDues').val(duesText);

    setStudentPhotoSafe(getValueByKeyContains(data, ['picture', 'photo'], meta.photo || ''));

    currentStudentAutoData = {
        ...data,
        SchoolNo: schoolNo,
        AffliationNo: affliationNo,
        RenewedUp: renewed,
        Renewed: renewed,
        RegistrationNo: registrationNo,
        SrNo: serialNo,
        SerialNo: serialNo,
        Category: category,
        Category_Name: categoryName,
        Dues: duesText,
        Relaxation: relaxationText
    };
}

function fillIssueStudentCard(meta) {
    const studentId = meta.studentId || '-';
    const admissionNo = meta.admissionNo || '-';
    const studentName = meta.studentName || '-';
    const fatherName = meta.fatherName || '-';
    const motherName = meta.motherName || '-';
    const className = meta.className || '-';
    const branchName = meta.branchName || '-';
    const sessionName = meta.sessionName || '-';
    const instituteName = meta.instituteName || '-';

    const dueNum = parseFloat(meta.balance || 0);
    const duesText = dueNum > 0 ? `Dues ₹${dueNum}` : 'No Dues';

    $('#DisplayStudentNameText').text(studentName);
    $('#DisplayAdmissionNoText').text(admissionNo);
    $('#DisplayFatherNameText').text(fatherName);
    $('#DisplayMotherNameText').text(motherName);
    $('#DisplayClassText').text(className);
    $('#DisplayBranchText').text(branchName);
    $('#DisplaySessionText').text(sessionName);
    $('#DisplayInstituteText').text(instituteName);
    $('#DisplayStudentIdText').text(studentId);

    $('#DisplayDuesBadge')
        .removeClass('bg-warning-subtle text-warning bg-success-subtle text-success bg-danger-subtle text-danger text-bg-primary')
        .addClass(dueNum > 0 ? 'bg-warning-subtle text-warning' : 'bg-success-subtle text-success')
        .html(`<i class="ti ti-wallet me-1"></i> ${escapeHtml(duesText)}`);

    setStudentPhotoSafe(meta.photo || '');
}

function updateTypeBadge(type) {
    const t = String(type || 'TC').toUpperCase();
    let icon = 'ti ti-file';
    if (t === 'TC') icon = 'ti ti-file';
    else if (t === 'NSO') icon = 'ti ti-checkbox';
    else if (t === 'PROVISIONAL') icon = 'ti ti-school';
    else if (t === 'CHARACTER') icon = 'ti ti-star';
    else if (t === 'MIGRATION') icon = 'ti ti-globe';
    else if (t === 'DMC') icon = 'ti ti-chart-bar';
    else if (t === 'BONAFIDE') icon = 'ti ti-id';

    $('#DisplayTypeBadge').html(`<i class="${icon} me-1"></i> ${escapeHtml(t)}`);
}

function resetIssueForm() {
    if ($('#formIssueTcNso').length) {
        $('#formIssueTcNso')[0].reset();
    }

    currentTcQuestionList = [];
    currentStudentAutoData = null;
    setTodayDate();

    $('#IssueType').val('TC');
    $('#IssueSubStatus').val('Transferred');

    $('#tcDynamicQuestionContainer').html(`
        <div class="text-center py-4">
            <div class="d-inline-flex align-items-center gap-2 px-3 py-2 border rounded-3">
                <span class="spinner-border spinner-border-sm text-primary" role="status"></span>
                <span class="small text-muted">Questions will load based on selected certificate type...</span>
            </div>
        </div>
    `);

    $('#tcQuestionCountBadge').html(`<i class="ti ti-help-circle me-1"></i> 0 Questions`);

    $('#DisplayStudentNameText').text('Student Name');
    $('#DisplayAdmissionNoText').text('-');
    $('#DisplayFatherNameText').text('-');
    $('#DisplayMotherNameText').text('-');
    $('#DisplayDobText').text('-');
    $('#DisplayClassText').text('-');
    $('#DisplayBranchText').text('-');
    $('#DisplaySessionText').text('-');
    $('#DisplayInstituteText').text('-');
    $('#DisplayStudentIdText').text('-');

    $('#DisplayTypeBadge').html(`<i class="ti ti-file me-1"></i> TC`);
    $('#DisplayDuesBadge')
        .removeClass('bg-warning-subtle text-warning bg-success-subtle text-success bg-danger-subtle text-danger')
        .addClass('text-bg-primary')
        .html(`<i class="ti ti-wallet me-1"></i> Dues`);

    $('#DisplayAdmissionNo').val('');
    $('#DisplayStudentName').val('');
    $('#DisplayFatherName').val('');
    $('#DisplayMotherName').val('');
    $('#DisplayClass').val('');
    $('#DisplaySession').val('');
    $('#DisplayInstitute').val('');
    $('#DisplayDues').val('');

    setStudentPhotoSafe('');

    if ($("#formIssueTcNso").data('validator')) {
        $("#formIssueTcNso").validate().resetForm();
        $('#formIssueTcNso').find('.is-invalid, .is-valid').removeClass('is-invalid is-valid');
    }
}

function normalizeBool(val) {
    return val === true || val === "true" || val === 1 || val === "1";
}

function normalizeCompareValue(val) {
    return String(val ?? '').trim().toLowerCase();
}

function getFieldValueForCompare($field) {
    if (!$field || !$field.length) return '';

    const tag = ($field.prop('tagName') || '').toLowerCase();
    const type = ($field.attr('type') || '').toLowerCase();

    if (type === 'checkbox') {
        return $field.is(':checked') ? 'yes' : 'no';
    }

    if (type === 'radio') {
        const name = $field.attr('name');
        const $checked = $(`input[name="${name}"]:checked`);
        return normalizeCompareValue($checked.val() || '');
    }

    if (tag === 'select') {
        return normalizeCompareValue($field.val() || '');
    }

    return normalizeCompareValue($field.val() || '');
}

function parseOptionValues(optionValues) {
    if (!optionValues) return [];

    let text = String(optionValues).trim();
    if (!text) return [];

    let parts = text
        .split(/[\n,|]/g)
        .map(x => x.trim())
        .filter(x => x !== '');

    const unique = [];
    const seen = new Set();

    parts.forEach(item => {
        const key = item.toLowerCase();
        if (!seen.has(key)) {
            seen.add(key);
            unique.push(item);
        }
    });

    return unique;
}

function getCurrentIssueType() {
    const type = ($('#IssueType').val() || 'TC').toUpperCase().trim();
    return type;
}

async function loadTcQuestionsForIssue(meta) {
    const $container = $('#tcDynamicQuestionContainer');
    const currentType = getCurrentIssueType();

    $container.html(`
        <div class="text-center py-4">
            <div class="d-inline-flex align-items-center gap-2 px-3 py-2 border rounded-3">
                <span class="spinner-border spinner-border-sm text-primary" role="status"></span>
                <span class="small text-muted">Loading questions for ${escapeHtml(currentType)}...</span>
            </div>
        </div>
    `);

    $('#tcQuestionCountBadge').html(`<i class="ti ti-help-circle me-1"></i> 0 Questions`);

    try {
        const instituteId = $('#ModalInstitute').val() || $('#SchoolID').val() || meta.institute || '';
        const sessionId = $('#ModalSession').val() || $('#SessionId').val() || meta.session || '';
        const classId = $('#ModalCourse').val() || $('#clsid').val() || meta.course || '';
        const branchId = $('#ModalBranch').val() || $('#SectionID').val() || meta.branch || '';

        const payload = {
            Action: 'GETFORFORM',
            Mode: 'GETFORFORM',
            InstituteID: instituteId,
            SessionID: sessionId,
            ClassID: classId,
            BranchID: branchId,
            ApplicableFor: currentType,
            IsActive: true
        };

        console.log("Loading questions with payload:", payload);

        const res = await new IMSClient().request('/master/TCQuestionMaster', 'POST', payload, true);
        const data = normalizeResultArray(res);

        if (!Array.isArray(data) || data.length === 0) {
            currentTcQuestionList = [];
            $container.html(`
                <div class="text-center py-4">
                    <i class="ti ti-help-circle text-muted fs-3"></i>
                    <div class="small text-muted mt-2">No questions configured for ${escapeHtml(currentType)}.</div>
                </div>
            `);
            return;
        }

        currentTcQuestionList = [...data];
        $('#tcQuestionCountBadge').html(`<i class="ti ti-help-circle me-1"></i> ${data.length} Questions`);
        renderTcDynamicQuestions(data);

    } catch (error) {
        currentTcQuestionList = [];
        console.error(error);
        $container.html(`
            <div class="text-center py-4">
                <i class="ti ti-alert-circle text-danger fs-3"></i>
                <div class="small text-danger mt-2">Unable to load questions.</div>
            </div>
        `);
    }
}

function renderTcDynamicQuestions(questionList) {
    const $container = $('#tcDynamicQuestionContainer');

    if (!Array.isArray(questionList) || !questionList.length) {
        $container.html(`
            <div class="text-center py-3">
                <div class="small text-muted">No questions available.</div>
            </div>
        `);
        $('#tcQuestionCountBadge').html(`<i class="ti ti-help-circle me-1"></i> 0 Questions`);
        return;
    }

    const sortedList = [...questionList].sort((a, b) => {
        const ao = parseInt(getValueByKeyContains(a, ['displayorder'], 9999), 10);
        const bo = parseInt(getValueByKeyContains(b, ['displayorder'], 9999), 10);
        return ao - bo;
    });

    let html = `<div class="row g-2">`;

    sortedList.forEach((item, index) => {
        const id = parseInt(getValueByKeyContains(item, ['tcquestionid', 'questionid'], 0), 10);
        const code = getValueByKeyContains(item, ['questioncode'], '');
        const text = getValueByKeyContains(item, ['questiontext'], '');
        const type = String(getValueByKeyContains(item, ['questiontype'], 'TEXT')).toUpperCase();
        const placeholder = getValueByKeyContains(item, ['placeholdertext', 'placeholder'], '');
        const optionValues = getValueByKeyContains(item, ['optionvalues'], '');
        const isMandatory = normalizeBool(getValueByKeyContains(item, ['ismandatory'], false));
        const validationType = getValueByKeyContains(item, ['validationtype'], '');
        const parentQuestionID = getValueByKeyContains(item, ['parentquestionid'], '');
        const showOnValue = getValueByKeyContains(item, ['showonvalue'], '');

        const fieldName = `TCQ_${id}`;
        const fieldId = `TCQ_${id}`;

        let fieldHtml = '';

        if (type === 'TEXT') {
            fieldHtml = `
                <input type="text"
                       class="form-control form-control-sm tc-dynamic-question"
                       id="${fieldId}"
                       name="${fieldName}"
                       data-questionid="${id}"
                       data-questioncode="${escapeHtml(code)}"
                       data-questiontext="${escapeHtml(text)}"
                       data-questiontype="${escapeHtml(type)}"
                       data-validationtype="${escapeHtml(validationType)}"
                       data-ismandatory="${isMandatory ? '1' : '0'}"
                       placeholder="${escapeHtml(placeholder || 'Enter answer')}" />
            `;
        } else if (type === 'TEXTAREA') {
            fieldHtml = `
                <textarea class="form-control form-control-sm tc-dynamic-question"
                          id="${fieldId}"
                          name="${fieldName}"
                          rows="2"
                          data-questionid="${id}"
                          data-questioncode="${escapeHtml(code)}"
                          data-questiontext="${escapeHtml(text)}"
                          data-questiontype="${escapeHtml(type)}"
                          data-validationtype="${escapeHtml(validationType)}"
                          data-ismandatory="${isMandatory ? '1' : '0'}"
                          placeholder="${escapeHtml(placeholder || 'Enter answer')}"></textarea>
            `;
        } else if (type === 'DATE') {
            fieldHtml = `
                <input type="date"
                       class="form-control form-control-sm tc-dynamic-question"
                       id="${fieldId}"
                       name="${fieldName}"
                       data-questionid="${id}"
                       data-questioncode="${escapeHtml(code)}"
                       data-questiontext="${escapeHtml(text)}"
                       data-questiontype="${escapeHtml(type)}"
                       data-validationtype="${escapeHtml(validationType)}"
                       data-ismandatory="${isMandatory ? '1' : '0'}" />
            `;
        } else if (type === 'NUMBER') {
            fieldHtml = `
                <input type="number"
                       class="form-control form-control-sm tc-dynamic-question"
                       id="${fieldId}"
                       name="${fieldName}"
                       data-questionid="${id}"
                       data-questioncode="${escapeHtml(code)}"
                       data-questiontext="${escapeHtml(text)}"
                       data-questiontype="${escapeHtml(type)}"
                       data-validationtype="${escapeHtml(validationType)}"
                       data-ismandatory="${isMandatory ? '1' : '0'}"
                       placeholder="${escapeHtml(placeholder || 'Enter number')}" />
            `;
        } else if (type === 'YESNO') {
            fieldHtml = `
                <select class="form-select form-select-sm tc-dynamic-question"
                        id="${fieldId}"
                        name="${fieldName}"
                        data-questionid="${id}"
                        data-questioncode="${escapeHtml(code)}"
                        data-questiontext="${escapeHtml(text)}"
                        data-questiontype="${escapeHtml(type)}"
                        data-validationtype="${escapeHtml(validationType)}"
                        data-ismandatory="${isMandatory ? '1' : '0'}">
                    <option value="">--Select--</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            `;
        } else if (type === 'DROPDOWN') {
            const options = parseOptionValues(optionValues);

            let optionHtml = `<option value="">--Select--</option>`;
            options.forEach(opt => {
                optionHtml += `<option value="${escapeHtml(opt)}">${escapeHtml(opt)}</option>`;
            });

            fieldHtml = `
                <select class="form-select form-select-sm tc-dynamic-question"
                        id="${fieldId}"
                        name="${fieldName}"
                        data-questionid="${id}"
                        data-questioncode="${escapeHtml(code)}"
                        data-questiontext="${escapeHtml(text)}"
                        data-questiontype="${escapeHtml(type)}"
                        data-validationtype="${escapeHtml(validationType)}"
                        data-ismandatory="${isMandatory ? '1' : '0'}">
                    ${optionHtml}
                </select>
            `;
        } else {
            fieldHtml = `
                <input type="text"
                       class="form-control form-control-sm tc-dynamic-question"
                       id="${fieldId}"
                       name="${fieldName}"
                       data-questionid="${id}"
                       data-questioncode="${escapeHtml(code)}"
                       data-questiontext="${escapeHtml(text)}"
                       data-questiontype="${escapeHtml(type)}"
                       data-validationtype="${escapeHtml(validationType)}"
                       data-ismandatory="${isMandatory ? '1' : '0'}"
                       placeholder="${escapeHtml(placeholder || 'Enter answer')}" />
            `;
        }

        const hiddenClass = parentQuestionID ? ' d-none' : '';

        html += `
            <div class="col-xl-6 col-lg-6 col-md-12 tc-question-col${hiddenClass}"
                 id="TCQ_WRAP_${id}"
                 data-questionid="${id}"
                 data-parentquestionid="${parentQuestionID || ''}"
                 data-showonvalue="${escapeHtml(showOnValue || '')}">
                <div class="card border shadow-sm rounded-3 h-100">
                    <div class="card-body p-2">
                        <div class="d-flex align-items-start gap-2 mb-2">
                            <span class="badge text-bg-primary border">${index + 1}</span>
                            <label class="form-label small fw-semibold mb-0" for="${fieldId}">
                                ${escapeHtml(text)}
                                ${isMandatory ? `<span class="text-danger">*</span>` : ``}
                            </label>
                        </div>
                        ${fieldHtml}
                    </div>
                </div>
            </div>
        `;
    });

    html += `</div>`;
    $container.html(html);

    applyTcDynamicValidation(sortedList);
    bindDynamicQuestionDependencies();
    evaluateAllQuestionDependencies();
    prefillDynamicQuestionAnswers();
}

function prefillDynamicQuestionAnswers() {
    if (!currentStudentAutoData || !currentTcQuestionList.length) return;

    const data = currentStudentAutoData;

    currentTcQuestionList.forEach(item => {
        const id = parseInt(getValueByKeyContains(item, ['tcquestionid', 'questionid'], 0), 10);
        const code = String(getValueByKeyContains(item, ['questioncode'], '')).trim().toUpperCase();
        if (!id || !code) return;

        let val = '';

        if (code === 'SCHOOLNO') val = getValueByKeyContains(data, ['schoolno'], '');
        else if (code === 'AFFLIATIONNO') val = getValueByKeyContains(data, ['affliationno', 'affiliationno'], '');
        else if (code === 'RENEWEDUP') val = getValueByKeyContains(data, ['renewed', 'renewedup'], '');
        else if (code === 'REGISTRATIONNO' || code === 'REGISTARTIONNO') val = getValueByKeyContains(data, ['registrationno', 'registartionno'], '');
        else if (code === 'SERIALNO' || code === 'SRNO') val = getValueByKeyContains(data, ['serialno', 'srno'], '');
        else if (code === 'CATEGORY') val = getValueByKeyContains(data, ['category_name', 'category'], '');
        else if (code === 'PREVCLASS') val = getValueByKeyContains(data, ['prevclass'], '');
        else if (code === 'PREVRESULT') val = getValueByKeyContains(data, ['prevresult'], '');
        else if (code === 'RESULT') val = getValueByKeyContains(data, ['result'], '');
        else if (code === 'SUBJECT' || code === 'OFFERSUBJECT') val = getValueByKeyContains(data, ['offersubject', 'subject'], '');
        else if (code === 'NCC') val = getValueByKeyContains(data, ['ncc'], '');
        else if (code === 'CUTNAME') val = getValueByKeyContains(data, ['cutname'], '');
        else if (code === 'REASON') val = getValueByKeyContains(data, ['reason'], '');
        else if (code === 'ATTENDANCE') val = getValueByKeyContains(data, ['attendance'], '');
        else if (code === 'EVENTATTENDANCE') val = getValueByKeyContains(data, ['eventattendance'], '');
        else if (code === 'GENCONDUCT') val = getValueByKeyContains(data, ['genconduct'], '');

        if (val !== '') {
            const $field = $('#TCQ_' + id);
            if ($field.length) {
                $field.val(val).trigger('change');
            }
        }
    });
}

function applyTcDynamicValidation(questionList) {
    const validator = $("#formIssueTcNso").data('validator');
    if (!validator) return;

    $('.tc-dynamic-question').each(function () {
        try { $(this).rules('remove'); } catch (e) { }
    });

    (questionList || []).forEach(item => {
        const id = parseInt(getValueByKeyContains(item, ['tcquestionid', 'questionid'], 0), 10);
        const isMandatory = normalizeBool(getValueByKeyContains(item, ['ismandatory'], false));
        const type = String(getValueByKeyContains(item, ['questiontype'], 'TEXT')).toUpperCase();
        const validationType = String(getValueByKeyContains(item, ['validationtype'], '')).toUpperCase();

        const $field = $(`#TCQ_${id}`);
        if (!$field.length) return;

        const rules = {};
        const messages = {};

        if (isMandatory) {
            rules.required = {
                depends: function () {
                    const $wrap = $(`#TCQ_WRAP_${id}`);
                    return $wrap.is(':visible');
                }
            };
            messages.required = 'This field is required';
        }

        if (type === 'NUMBER') {
            rules.number = true;
            messages.number = 'Please enter a valid number';
        }

        if (validationType === 'NUMERIC') {
            rules.number = true;
            messages.number = 'Please enter numeric value only';
        }

        if (validationType === 'EMAIL') {
            rules.email = true;
            messages.email = 'Please enter a valid email';
        }

        if (validationType === 'MOBILE') {
            rules.pattern = /^[0-9]{10}$/;
            messages.pattern = 'Please enter a valid 10 digit mobile number';
        }

        try {
            $field.rules('add', {
                ...rules,
                messages
            });
        } catch (e) { }
    });
}

function bindDynamicQuestionDependencies() {
    $('.tc-dynamic-question').off('change.tcdep input.tcdep').on('change.tcdep input.tcdep', function () {
        const currentId = $(this).data('questionid');
        evaluateDependentQuestions(currentId);
    });
}

function evaluateAllQuestionDependencies() {
    $('.tc-question-col').each(function () {
        const parentQuestionID = $(this).data('parentquestionid');
        if (parentQuestionID) {
            evaluateQuestionVisibility($(this));
        }
    });
}

function evaluateDependentQuestions(parentQuestionID) {
    $(`.tc-question-col[data-parentquestionid="${parentQuestionID}"]`).each(function () {
        evaluateQuestionVisibility($(this));
    });
}

function evaluateQuestionVisibility($wrap) {
    const parentQuestionID = $wrap.data('parentquestionid');
    const showOnValue = normalizeCompareValue($wrap.data('showonvalue'));

    if (!parentQuestionID) return;

    const $parentField = $(`#TCQ_${parentQuestionID}`);
    if (!$parentField.length) {
        $wrap.addClass('d-none');
        clearQuestionField($wrap);
        return;
    }

    const parentValue = getFieldValueForCompare($parentField);

    if (parentValue === showOnValue) {
        $wrap.removeClass('d-none');
    } else {
        $wrap.addClass('d-none');
        clearQuestionField($wrap);
        clearChildQuestionRecursively($wrap.data('questionid'));
    }
}

function clearQuestionField($wrap) {
    const $field = $wrap.find('.tc-dynamic-question').first();
    if (!$field.length) return;

    const tag = ($field.prop('tagName') || '').toLowerCase();
    const type = ($field.attr('type') || '').toLowerCase();

    if (type === 'checkbox' || type === 'radio') {
        $field.prop('checked', false).trigger('change');
        return;
    }

    if (tag === 'select') {
        $field.val('').trigger('change');
        return;
    }

    $field.val('');
}

function clearChildQuestionRecursively(parentQuestionID) {
    $(`.tc-question-col[data-parentquestionid="${parentQuestionID}"]`).each(function () {
        $(this).addClass('d-none');
        clearQuestionField($(this));
        clearChildQuestionRecursively($(this).data('questionid'));
    });
}

function collectDynamicQuestionAnswers() {
    const answers = [];
    let isValid = true;
    let firstInvalidField = null;

    $('.tc-question-col').each(function () {
        const $wrap = $(this);
        if (!$wrap.is(':visible')) return;

        const $field = $wrap.find('.tc-dynamic-question').first();
        if (!$field.length) return;

        const questionId = parseInt($field.data('questionid') || 0, 10);
        const questionCode = $field.data('questioncode') || '';
        const questionText = $field.data('questiontext') || '';
        const questionType = ($field.data('questiontype') || 'TEXT').toUpperCase();
        const isMandatory = String($field.data('ismandatory') || '0') === '1';

        let answerValue = '';
        let answerDisplay = '';

        const tag = ($field.prop('tagName') || '').toLowerCase();
        const type = ($field.attr('type') || '').toLowerCase();

        if (type === 'checkbox') {
            answerValue = $field.is(':checked') ? 'Yes' : 'No';
            answerDisplay = answerValue;
        } else if (type === 'radio') {
            const name = $field.attr('name');
            const $checked = $(`input[name="${name}"]:checked`);
            answerValue = $checked.val() || '';
            answerDisplay = answerValue;
        } else if (tag === 'select') {
            answerValue = $field.val() || '';
            answerDisplay = $field.find('option:selected').text() || answerValue;
            if (!answerValue) answerDisplay = '';
        } else {
            answerValue = $field.val() || '';
            answerDisplay = answerValue;
        }

        answerValue = String(answerValue).trim();
        answerDisplay = String(answerDisplay).trim();

        if (isMandatory && !answerValue) {
            isValid = false;
            $field.addClass('is-invalid');
            if (!firstInvalidField) firstInvalidField = $field;
        } else {
            $field.removeClass('is-invalid');
        }

        if (questionId > 0) {
            answers.push({
                TCQuestionID: questionId,
                QuestionCode: questionCode,
                QuestionText: questionText,
                QuestionType: questionType,
                AnswerValue: answerValue,
                AnswerDisplay: answerDisplay
            });
        }
    });

    if (!isValid) {
        if (firstInvalidField && firstInvalidField.length) {
            firstInvalidField.focus();
        }

        return {
            isValid: false,
            answers: []
        };
    }

    return {
        isValid: true,
        answers
    };
}

function buildLegacyTcPayloadFromDynamic(answers) {
    const data = currentStudentAutoData || {};
    const map = {};

    (answers || []).forEach(item => {
        const code = String(item?.QuestionCode || '').trim().toUpperCase();
        if (!code) return;
        map[code] = item?.AnswerValue ?? '';
    });

    return {
        SchoolNo: map.SCHOOLNO || getValueByKeyContains(data, ['schoolno'], ''),
        AffliationNo: map.AFFLIATIONNO || getValueByKeyContains(data, ['affliationno', 'affiliationno'], ''),
        RenewedUp: map.RENEWEDUP || getValueByKeyContains(data, ['renewed', 'renewedup'], ''),
        RegistrationNo: map.REGISTRATIONNO || map.REGISTARTIONNO || getValueByKeyContains(data, ['registrationno', 'registartionno'], ''),
        SrNo: map.SERIALNO || map.SRNO || getValueByKeyContains(data, ['serialno', 'srno'], ''),
        Category: map.CATEGORY || getValueByKeyContains(data, ['category_name', 'category'], ''),
        Result: map.RESULT || getValueByKeyContains(data, ['result'], ''),
        Subject: map.SUBJECT || map.OFFERSUBJECT || map.OFFER_SUBJECT || getValueByKeyContains(data, ['offersubject', 'subject'], ''),
        PrevClass: map.PREVCLASS || map.PREV_CLASS || getValueByKeyContains(data, ['prevclass'], ''),
        PrevResult: map.PREVRESULT || map.PREV_RESULT || getValueByKeyContains(data, ['prevresult'], ''),
        NCC: map.NCC || getValueByKeyContains(data, ['ncc'], ''),
        CutName: map.CUTNAME || getValueByKeyContains(data, ['cutname'], ''),
        Reason: map.REASON || getValueByKeyContains(data, ['reason'], ''),
        Attendance: map.ATTENDANCE || getValueByKeyContains(data, ['attendance'], ''),
        EventAttendance: map.EVENTATTENDANCE || map.EVENT_ATTENDANCE || getValueByKeyContains(data, ['eventattendance'], ''),
        GenConduct: map.GENCONDUCT || map.GEN_CONDUCT || getValueByKeyContains(data, ['genconduct'], '')
    };
}

function buildIssueConfirmHtml(issueType, questionAnswers) {
    const studentName = $('#DisplayStudentNameText').text() || '-';
    const admissionNo = $('#DisplayAdmissionNoText').text() || '-';
    const fatherName = $('#DisplayFatherNameText').text() || '-';
    const className = $('#DisplayClassText').text() || '-';
    const branchName = $('#DisplayBranchText').text() || '-';
    const date = $('#Date').val() || '-';
    const subStatus = $('#IssueSubStatus').val() || '-';
    const remark = $('#Remark').val() || '-';
    const totalQuestions = (questionAnswers || []).length;

    return `
        <div class="text-start">
            <div class="border rounded-3 p-3 mb-3">
                <div class="row g-2">
                    <div class="col-6"><div class="small text-muted">Type</div><div class="fw-semibold">${escapeHtml(issueType)}</div></div>
                    <div class="col-6"><div class="small text-muted">Date</div><div class="fw-semibold">${escapeHtml(date)}</div></div>
                    <div class="col-6"><div class="small text-muted">Admission No</div><div class="fw-semibold">${escapeHtml(admissionNo)}</div></div>
                    <div class="col-6"><div class="small text-muted">Student</div><div class="fw-semibold">${escapeHtml(studentName)}</div></div>
                    <div class="col-6"><div class="small text-muted">Father</div><div class="fw-semibold">${escapeHtml(fatherName)}</div></div>
                    <div class="col-6"><div class="small text-muted">Class / Section</div><div class="fw-semibold">${escapeHtml(className)} / ${escapeHtml(branchName)}</div></div>
                    <div class="col-6"><div class="small text-muted">Sub Status</div><div class="fw-semibold">${escapeHtml(subStatus)}</div></div>
                    <div class="col-6"><div class="small text-muted">Dynamic Answers</div><div class="fw-semibold">${escapeHtml(String(totalQuestions))}</div></div>
                </div>
            </div>
            <div class="border rounded-3 p-3">
                <div class="small text-muted mb-1">Remark</div>
                <div class="fw-semibold">${escapeHtml(remark)}</div>
            </div>
        </div>
    `;
}

async function saveStudentTcNso() {
    if (isIssueSaving) return;
    if (!$('#formIssueTcNso').valid()) return;

    const issueType = ($('#IssueType').val() || 'TC').toUpperCase().trim();

    if (!issueType) {
        ShowNotification("warning", "Please select Type", "center");
        return;
    }

    const dynamicResult = collectDynamicQuestionAnswers();

    if (!dynamicResult.isValid) {
        ShowNotification("warning", "Please fill all required dynamic questions", "center");
        return;
    }

    const questionAnswers = dynamicResult.answers || [];

    const confirmResult = await Swal.fire({
        title: `Confirm ${issueType} Issue`,
        html: buildIssueConfirmHtml(issueType, questionAnswers),
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: `Yes, Issue ${issueType}`,
        cancelButtonText: 'Cancel',
        focusCancel: true,
        reverseButtons: true,
        width: 700,
        customClass: {
            confirmButton: 'btn btn-primary ms-2',
            cancelButton: 'btn btn-outline-secondary'
        },
        buttonsStyling: false
    });

    if (!confirmResult.isConfirmed) return;

    const legacy = (issueType === 'NSO' || issueType === 'DMC' || issueType === 'Bonafide') ? {
        SchoolNo: '',
        AffliationNo: '',
        RenewedUp: '',
        RegistrationNo: '',
        SrNo: '',
        Category: '',
        Result: '',
        Subject: '',
        PrevClass: '',
        PrevResult: '',
        NCC: '',
        CutName: '',
        Reason: '',
        Attendance: '',
        EventAttendance: '',
        GenConduct: ''
    } : buildLegacyTcPayloadFromDynamic(questionAnswers);

    const btn = $('#btnSaveTcNso');
    const html = btn.html();

    isIssueSaving = true;
    btn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Saving...`);

    Swal.fire({
        title: 'Saving...',
        text: 'Please wait while request is being processed.',
        allowOutsideClick: false,
        allowEscapeKey: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    try {
        const parms = {
            Institute: $('#ModalInstitute').val() || $('#SchoolID').val() || '',
            Session: $('#ModalSession').val() || $('#SessionId').val() || '',
            Course: $('#ModalCourse').val() || $('#clsid').val() || '',
            Branch: $('#ModalBranch').val() || $('#SectionID').val() || '',
            StudentID: $('#ModalStudentID').val() || '',
            Type: issueType,
            SubStatus: $('#IssueSubStatus').val() || (issueType === 'TC' ? 'Transferred' : 'Regular'),
            Date: $('#Date').val() || '',
            ItemTobeChange: 'Status',
            Remark: $('#Remark').val() || '',
            CreatedBy: $('#CreatedBy').val() || $('#hdnUserID').val() || $('#UserID').val() || '',

            SchoolNo: legacy.SchoolNo,
            AffliationNo: legacy.AffliationNo,
            RenewedUp: legacy.RenewedUp,
            RegistrationNo: legacy.RegistrationNo,
            SrNo: legacy.SrNo,
            Category: legacy.Category,
            Result: legacy.Result,
            Subject: legacy.Subject,
            PrevClass: legacy.PrevClass,
            PrevResult: legacy.PrevResult,
            NCC: legacy.NCC,
            CutName: legacy.CutName,
            Reason: legacy.Reason,
            Attendance: legacy.Attendance,
            EventAttendance: legacy.EventAttendance,
            GenConduct: legacy.GenConduct,

            QuestionAnswerJson: JSON.stringify(questionAnswers),
            mode: 'SaveCertificate'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const statusCode = res?.statusCode;
        const message = res?.message || 'Operation completed';

        const success = statusCode === 200;

        Swal.close();

        if (success) {
            await Swal.fire({
                icon: 'success',
                title: `${issueType} Issued Successfully`,
                text: message,
                confirmButtonText: 'OK',
                customClass: {
                    confirmButton: 'btn btn-success'
                },
                buttonsStyling: false
            });

            if (issueTcNsoModalInstance) {
                issueTcNsoModalInstance.hide();
            }

            setTimeout(function () {
                $('#form_isseuTC').trigger('submit');
            }, 300);
        } else {
            await Swal.fire({
                icon: 'warning',
                title: 'Unable to Process',
                text: message,
                confirmButtonText: 'OK',
                customClass: {
                    confirmButton: 'btn btn-warning'
                },
                buttonsStyling: false
            });
        }

    } catch (error) {
        console.error(error);
        Swal.close();

        await Swal.fire({
            icon: 'error',
            title: 'Something Went Wrong',
            text: 'Error while saving certificate request.',
            confirmButtonText: 'OK',
            customClass: {
                confirmButton: 'btn btn-danger'
            },
            buttonsStyling: false
        });
    } finally {
        isIssueSaving = false;
        btn.prop('disabled', false).html(html);
    }
}

function resetSearchArea() {
    $('#form_isseuTC')[0].reset();

    if ($("#form_isseuTC").data('validator')) {
        $("#form_isseuTC").validate().resetForm();
        $('#form_isseuTC').find('.is-invalid, .is-valid').removeClass('is-invalid is-valid');
    }

    initIssueTcEmptyState();

    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 300);
}

function normalizeResultArray(res) {
    if (!res) return [];
    if (Array.isArray(res)) return res;
    if (Array.isArray(res.result)) return res.result;
    if (Array.isArray(res.data)) return res.data;
    if (Array.isArray(res.Data)) return res.Data;
    if (Array.isArray(res.d)) return res.d;

    if (typeof res.d === 'string') {
        try {
            const parsed = JSON.parse(res.d);
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) { }
    }

    return [];
}

function getNoImageUrl() {
    return '/theme/admin/assets/images/avatar/07.png';
}

function normalizeBase64Image(value) {
    if (!value) return '';

    const v = String(value).trim();

    if (!v) return '';

    if (v.startsWith('data:image')) return v;

    if (v.length > 100) {
        return 'data:image/png;base64,' + v;
    }

    return v;
}

function setStudentPhotoSafe(photoValue) {
    const $img = $('#studentProfileImage');
    if (!$img.length) return;

    const noImage = getNoImageUrl();
    const src = normalizeBase64Image(photoValue);

    $img.off('error.tcimg').on('error.tcimg', function () {
        $(this).attr('src', noImage);
    });

    if (!src) {
        $img.attr('src', noImage);
        return;
    }

    $img.attr('src', src);
}

function getValueByKeyContains(obj, keys, defaultValue = '') {
    if (!obj || typeof obj !== 'object') return defaultValue;

    const objKeys = Object.keys(obj);
    if (!objKeys.length) return defaultValue;

    const normalize = (v) => String(v || '').replace(/[\s_\-]/g, '').toLowerCase();

    const normalizedObjKeys = objKeys.map(k => ({
        original: k,
        normalized: normalize(k)
    }));

    const normalizedWanted = (keys || []).map(k => normalize(k));

    for (const wanted of normalizedWanted) {
        const found = normalizedObjKeys.find(x => x.normalized === wanted);
        if (found) {
            const val = obj[found.original];
            if (val !== undefined && val !== null && String(val).trim() !== '') {
                return val;
            }
        }
    }

    for (const wanted of normalizedWanted) {
        const found = normalizedObjKeys.find(x =>
            x.normalized.includes(wanted) || wanted.includes(x.normalized)
        );
        if (found) {
            const val = obj[found.original];
            if (val !== undefined && val !== null && String(val).trim() !== '') {
                return val;
            }
        }
    }

    return defaultValue;
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}