﻿// Global variables
let taskDataTable = null;
let taskFilePond = null;
let taskExcelData = [];
let taskValidData = [];
let taskInvalidData = [];
let editingRowId = null;
let rowDataForDetail = [];

// Field configuration for validation and editing
var FIELD_CONFIG = {
    required: ['firstName', 'lastName', 'dateOfBirth', 'gender', 'studentMobile'],
    fieldLabels: {
        'firstName': 'First Name',
        'lastName': 'Last Name',
        'dateOfBirth': 'Date of Birth',
        'gender': 'Gender',
        'studentMobile': 'Student Mobile',
        'middleName': 'Middle Name',
        'studentEmail': 'Student Email',
        'categoryId': 'Category ID',
        'subCategoryId': 'Sub Category ID',
        'feesCategoryId': 'Fees Category ID',
        'nationalityId': 'Nationality ID',
        'religionId': 'Religion ID',
        'bloodGroupId': 'Blood Group ID',
        'fatherPrefix': 'Father Prefix',
        'fatherName': 'Father Name',
        'fatherMobile': 'Father Mobile',
        'fatherEmail': 'Father Email',
        'fatherProfession': 'Father Profession',
        'fatherQualification': 'Father Qualification',
        'fatherDesignation': 'Father Designation',
        'fatherIncome': 'Father Income',
        'motherPrefix': 'Mother Prefix',
        'motherName': 'Mother Name',
        'motherMobile': 'Mother Mobile',
        'motherEmail': 'Mother Email',
        'motherProfession': 'Mother Profession',
        'motherQualification': 'Mother Qualification',
        'motherDesignation': 'Mother Designation',
        'motherIncome': 'Mother Income',
        'guardianPrefix': 'Guardian Prefix',
        'guardianName': 'Guardian Name',
        'guardianMobile': 'Guardian Mobile',
        'guardianEmail': 'Guardian Email',
        'guardianRelation': 'Guardian Relation',
        'guardianProfession': 'Guardian Profession',
        'guardianQualification': 'Guardian Qualification',
        'guardianDesignation': 'Guardian Designation',
        'permanentAddress': 'Permanent Address',
        'permanentCity': 'Permanent City',
        'permanentDistrict': 'Permanent District',
        'permanentState': 'Permanent State',
        'permanentCountry': 'Permanent Country',
        'permanentPincode': 'Permanent Pincode',
        'permanentPhone': 'Permanent Phone',
        'permanentTaluka': 'Permanent Taluka',
        'correspondenceAddress': 'Correspondence Address',
        'correspondenceCity': 'Correspondence City',
        'correspondenceDistrict': 'Correspondence District',
        'correspondenceState': 'Correspondence State',
        'correspondenceCountry': 'Correspondence Country',
        'correspondencePincode': 'Correspondence Pincode',
        'correspondencePhone': 'Correspondence Phone',
        'correspondenceMobile': 'Correspondence Mobile',
        'correspondenceEmail': 'Correspondence Email',
        'aadharCardNo': 'Aadhar Card No',
        'panCardNo': 'PAN Card No',
        'drivingLicenseNo': 'Driving License No',
        'passportNo': 'Passport No',
        'maritalStatus': 'Marital Status',
        'studyGap': 'Study Gap',
        'alternateMobile': 'Alternate Mobile',
        'physicallyChallenged': 'Physically Challenged',
        'admissionNo': 'Admission No',
        'enrollmentNo': 'Enrollment No',
        'rollNo': 'Roll No',
        'registrationNo': 'Registration No',
        'formNo': 'Form No',
        'lateralEntry': 'Lateral Entry',
        'admissionDate': 'Admission Date',
        'reportingDate': 'Reporting Date',
        'admissionThrough': 'Admission Through',
        'admissionQuota': 'Admission Quota',
        'admissionReferredBy': 'Admission Referred By',
        'employeeRef': 'Employee Reference',
        'semesterId': 'Semester ID',
        'sectionId': 'Section ID',
        'shiftId': 'Shift ID',
        'hostelRequired': 'Hostel Required',
        'transportRequired': 'Transport Required',
        'messRequired': 'Mess Required',
        'bankName': 'Bank Name',
        'ifsc': 'IFSC Code',
        'bankAddress': 'Bank Address',
        'bankAccountNo': 'Bank Account No',
        'siblingName': 'Sibling Name',
        'siblingCourse': 'Sibling Course',
        'siblingAdmissionNo': 'Sibling Admission No',
        'iSSibling': 'Is Sibling',
        'extraActivity': 'Extra Activity',
        'hobbies': 'Hobbies',
        'birthPlace': 'Birth Place',
        'physicaldeformities': 'Physical Deformities',
        'sufferiengChronicDiseases': 'Suffering Chronic Diseases',
        'pmAilment': 'PM Ailment',
        'iAllergicMedicine': 'Allergic Medicine',
        'qualificationData': 'Qualification',
        'schoolCollegeData': 'School/College',
        'boardData': 'Board',
        'yearData': 'Year',
        'perData': 'Percentage',
        'cgpaGradeData': 'CGPA/Grade',
        'perPCMData': 'PCM Percentage',
        'streamData': 'Stream',
        'mediumData': 'Medium',
        'entranceExamName': 'Entrance Exam Name',
        'entranceRollNumber': 'Entrance Roll Number',
        'entranceScore': 'Entrance Score',
        'entranceYear': 'Entrance Year',
        'entranceGenRank': 'Entrance Gen Rank',
        'entranceCategoryRank': 'Entrance Category Rank',
        'entranceMonth': 'Entrance Month',
        'entranceStateRank': 'Entrance State Rank',
        'entranceCategoryExam': 'Entrance Category Exam',
        'tenththdivisionGrade': '10th Division Grade',
        'twelvethDivisionGrade': '12th Division Grade',
        'ltExamQualified': 'LT Exam Qualified',
        'ltRollNo': 'LT Roll No',
        'ltInstitute': 'LT Institute',
        'ltMedium': 'LT Medium',
        'ltMarks': 'LT Marks',
        'talukaCorresponding': 'Taluka Corresponding',
        'talukaPermanent': 'Taluka Permanent',
        'talukaGardian': 'Taluka Gardian',
        'isLateral': 'Is Lateral',
        'mailAddress': 'Mail Address',
        'graIYear': 'Gra I Year',
        'graIIYear': 'Gra II Year',
        'graIIIYear': 'Gra III Year',
        'graIVYear': 'Gra IV Year',
        'postGraIYear': 'Post Gra I Year',
        'postGraIIYear': 'Post Gra II Year',
        'bTechLat10MathPer': 'BTech Lat 10 Math %',
        'bTechLat12MathPer': 'BTech Lat 12 Math %',
        'bTechLatDipPassYear': 'BTech Lat Dip Pass Year',
        'bTechLatDipSchool': 'BTech Lat Dip School',
        'bTechLatDipSubject': 'BTech Lat Dip Subject',
        'bTechLatBscRollNo': 'BTech Lat Bsc Roll No',
        'bTechLatBscPassYear': 'BTech Lat Bsc Pass Year',
        'bTechLatBscSchool': 'BTech Lat Bsc School',
        'bTechLatBscBoard': 'BTech Lat Bsc Board',
        'bTechLatBscSubject': 'BTech Lat Bsc Subject',
        'bTechLatDip1YearPer': 'BTech Lat Dip 1 Year %',
        'bTechLatDip2YearPer': 'BTech Lat Dip 2 Year %',
        'bTechLatDip3YearPer': 'BTech Lat Dip 3 Year %',
        'bTechLatDip4YearPer': 'BTech Lat Dip 4 Year %',
        'bTechLatBsc1YearPer': 'BTech Lat Bsc 1 Year %',
        'bTechLatBsc2YearPer': 'BTech Lat Bsc 2 Year %',
        'bTechLatBsc3YearPer': 'BTech Lat Bsc 3 Year %',
        'bTechLatBsc4YearPer': 'BTech Lat Bsc 4 Year %',
        'qGradRollNo': 'Q Grad Roll No',
        'qpgRollNo': 'Q PG Roll No',
        'qOthRollNo': 'Q Oth Roll No',
        'mcaGradMathPer': 'MCA Grad Math %',
        'mcapgMathPer': 'MCA PG Math %',
        'pgSchool': 'PG School',
        'pgBoard': 'PG Board',
        'pgPassYear': 'PG Pass Year',
        'pgSubject': 'PG Subject',
        'pgMedium': 'PG Medium',
        'pgObtMark': 'PG Obt Mark',
        'pgOutMarks': 'PG Out Marks',
        'pgqPer': 'PG %',
        'pgQualification': 'PG Qualification',
        'remarks': 'Remarks'
    }
};

$(document).ready(function () {
    initTaskManager();
});

function initTaskManager() {
    bindTaskEvents();
    initTaskFilePond();
    initTaskDataTable();
    loadTaskStats();

    $('#btnRefreshTasks').click(function () {
        if (taskDataTable) taskDataTable.ajax.reload();
        loadTaskStats();
    });

    $('#btnApplyFilter').click(function () {
        if (taskDataTable) taskDataTable.ajax.reload();
    });

    $('#btnClearFilter').click(function () {
        $('#taskSearch, #taskFilterStatus, #taskFilterFrom, #taskFilterTo').val('');
        if (taskDataTable) taskDataTable.ajax.reload();
    });

    $('#taskSearch').on('keyup', function (e) {
        if (e.key === 'Enter' && taskDataTable) taskDataTable.ajax.reload();
    });

    $('#taskStats .stat-badge').click(function () {
        var status = $(this).data('status');
        $('#taskFilterStatus').val(status && status !== 'all' ? status : '');
        if (taskDataTable) taskDataTable.ajax.reload();
    });

    $('#btnSaveTask').click(function () {
        createNewTask();
    });

    $('#closeRowDetail').click(function () {
        $('#rowDetailExpandArea').slideUp();
    });

    $('#clearBulkData').click(function () {
        resetExcelData();
    });

    $('#btnValidateExcel').click(function () {
        validateExcelData();
    });

    $('#downloadTemplateBtn, #downloadTemplate').click(function (e) {
        e.preventDefault();
        downloadBulkTemplate();
    });

    $('#deleteSelectedRows').click(function () {
        deleteSelectedRows();
    });
}

function bindTaskEvents() {
    $(document).on('click', '#btnApplyFilter', function () {
        if (taskDataTable) taskDataTable.ajax.reload();
    });

    $(document).on('click', '#btnClearFilter', function () {
        $('#taskSearch, #taskFilterStatus, #taskFilterFrom, #taskFilterTo').val('');
        if (taskDataTable) taskDataTable.ajax.reload();
    });

    $(document).on('click', '#btnRefreshTasks', function () {
        if (taskDataTable) taskDataTable.ajax.reload();
        loadTaskStats();
    });

    $(document).on('click', '#btnCreateTask', function () {
        $('#createTaskCard').slideToggle(300, function () {
            if ($(this).is(':visible')) {
                $(this).css('display', 'block');
                $('#btnCreateTask').html('<i class="ti ti-minus me-1"></i> Close Task');
                if (taskExcelData.length) renderExcelPreview();
            } else {
                $('#btnCreateTask').html('<i class="ti ti-plus me-1"></i> New Task');
            }
        });
    });

    $(document).on('click', '#closeCreateTask, #btnCancelTask', function () {
        $('#createTaskCard').slideUp(300, function () {
            $('#btnCreateTask').html('<i class="ti ti-plus me-1"></i> New Task');
        });
    });

    $(document).on('click', '#taskStats .stat-badge', function () {
        var status = $(this).data('status');
        $('#taskFilterStatus').val(status && status !== 'all' ? status : '');
        if (taskDataTable) taskDataTable.ajax.reload();
    });

    $(document).on('keyup', '#taskSearch', function (e) {
        if (e.key === 'Enter' && taskDataTable) taskDataTable.ajax.reload();
    });

    $(document).on('click', '#closeRowDetail', function () {
        $('#rowDetailExpandArea').slideUp();
    });

    $(document).on('click', '.row-detail-btn', function () {
        var rowId = $(this).data('rowid');
        showRowDetail(rowId);
    });

    $(document).on('click', '#clearBulkData', function () {
        resetExcelData();
    });

    $(document).on('click', '#btnValidateExcel', function () {
        validateExcelData();
    });

    $(document).on('click', '#downloadTemplateBtn, #downloadTemplate', function (e) {
        e.preventDefault();
        downloadBulkTemplate();
    });

    $(document).on('click', '.edit-excel-row', function () {
        var id = $(this).data('id');
        editExcelRow(id);
    });

    $(document).on('click', '#saveExcelEdit', function () {
        saveExcelEdit();
    });

    $(document).on('click', '#deleteSelectedRows', function () {
        deleteSelectedRows();
    });

    $(document).on('change', '#selectAllRows', function () {
        var checked = $(this).prop('checked');
        $('.row-checkbox').prop('checked', checked);
    });
}

function initTaskFilePond() {
    if (!$('#taskExcelFilePond').length) return;
    FilePond.registerPlugin(FilePondPluginFileValidateType, FilePondPluginFileValidateSize);
    taskFilePond = FilePond.create(document.getElementById('taskExcelFilePond'), {
        allowFileTypeValidation: true,
        acceptedFileTypes: ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/csv'],
        maxFileSize: '10MB',
        maxFiles: 1,
        allowMultiple: false,
        instantUpload: false,
        labelIdle: 'Drag & Drop your Excel file or <span class="filepond--label-action">Browse</span>'
    });
    taskFilePond.on('addfile', function (error, file) {
        if (error) {
            Swal.fire('Error', error.toString(), 'error');
            return;
        }
        readTaskExcelFile(file);
    });
    taskFilePond.on('removefile', function () {
        resetExcelData();
    });
}

function readTaskExcelFile(file) {
    var reader = new FileReader();
    reader.onload = function (e) {
        try {
            var workbook = XLSX.read(new Uint8Array(e.target.result), { type: 'array' });
            var sheet = workbook.Sheets[workbook.SheetNames[0]];
            var rawData = XLSX.utils.sheet_to_json(sheet, {
                defval: '',
                raw: false
            });

            if (!rawData.length) {
                Swal.fire('Warning', 'No data found in file', 'warning');
                return;
            }

            // Enhanced column mapping
            var columnMap = {
                'firstname': 'firstName',
                'firstname*': 'firstName',
                'middlename': 'middleName',
                'lastname': 'lastName',
                'lastname*': 'lastName',
                'dateofbirth': 'dateOfBirth',
                'dateofbirth*': 'dateOfBirth',
                'dateofbirthyyyymmdd': 'dateOfBirth',
                'dateofbirthyyyymmdd*': 'dateOfBirth',
                'gender': 'gender',
                'gendermale/female/other': 'gender',
                'gendermale/female/other*': 'gender',
                'studentmobile': 'studentMobile',
                'studentmobile10digits': 'studentMobile',
                'studentmobile10digits*': 'studentMobile',
                'studentemail': 'studentEmail',
                'categoryid': 'categoryId',
                'categoryid*': 'categoryId',
                'subcategoryid': 'subCategoryId',
                'feescategoryid': 'feesCategoryId',
                'nationalityid': 'nationalityId',
                'religionid': 'religionId',
                'bloodgroupid': 'bloodGroupId',
                'fatherprefix': 'fatherPrefix',
                'fathername': 'fatherName',
                'fathermobile': 'fatherMobile',
                'fatheremail': 'fatherEmail',
                'fatherprofession': 'fatherProfession',
                'fatherqualification': 'fatherQualification',
                'fatherdesignation': 'fatherDesignation',
                'fatherincome': 'fatherIncome',
                'motherprefix': 'motherPrefix',
                'mothername': 'motherName',
                'mothermobile': 'motherMobile',
                'motheremail': 'motherEmail',
                'motherprofession': 'motherProfession',
                'motherqualification': 'motherQualification',
                'motherdesignation': 'motherDesignation',
                'motherincome': 'motherIncome',
                'guardianprefix': 'guardianPrefix',
                'guardianname': 'guardianName',
                'guardianmobile': 'guardianMobile',
                'guardianemail': 'guardianEmail',
                'guardianrelation': 'guardianRelation',
                'guardianprofession': 'guardianProfession',
                'guardianqualification': 'guardianQualification',
                'guardiandesignation': 'guardianDesignation',
                'permanentaddress': 'permanentAddress',
                'permanentcity': 'permanentCity',
                'permanentdistrict': 'permanentDistrict',
                'permanentstate': 'permanentState',
                'permanentcountry': 'permanentCountry',
                'permanentpincode': 'permanentPincode',
                'permanentphone': 'permanentPhone',
                'permanenttaluka': 'permanentTaluka',
                'correspondenceaddress': 'correspondenceAddress',
                'correspondencecity': 'correspondenceCity',
                'correspondencedistrict': 'correspondenceDistrict',
                'correspondencestate': 'correspondenceState',
                'correspondencecountry': 'correspondenceCountry',
                'correspondencepincode': 'correspondencePincode',
                'correspondencephone': 'correspondencePhone',
                'correspondencemobile': 'correspondenceMobile',
                'correspondenceemail': 'correspondenceEmail',
                'aadharcardno': 'aadharCardNo',
                'pancardno': 'panCardNo',
                'drivinglicenseno': 'drivingLicenseNo',
                'passportno': 'passportNo',
                'maritalstatus': 'maritalStatus',
                'studygap': 'studyGap',
                'alternatemobile': 'alternateMobile',
                'physicallychallenged': 'physicallyChallenged',
                'admissionno': 'admissionNo',
                'enrollmentno': 'enrollmentNo',
                'rollno': 'rollNo',
                'registrationno': 'registrationNo',
                'formno': 'formNo',
                'lateralentry': 'lateralEntry',
                'admissiondate': 'admissionDate',
                'reportingdate': 'reportingDate',
                'admissionthrough': 'admissionThrough',
                'admissionquota': 'admissionQuota',
                'admissionreferredby': 'admissionReferredBy',
                'employeeref': 'employeeRef',
                'semesterid': 'semesterId',
                'sectionid': 'sectionId',
                'shiftid': 'shiftId',
                'hostelrequired': 'hostelRequired',
                'transportrequired': 'transportRequired',
                'messrequired': 'messRequired',
                'bankname': 'bankName',
                'ifsc': 'ifsc',
                'bankaddress': 'bankAddress',
                'bankaccountno': 'bankAccountNo',
                'siblingname': 'siblingName',
                'siblingcourse': 'siblingCourse',
                'siblingadmissionno': 'siblingAdmissionNo',
                'issibling': 'iSSibling',
                'extraactivity': 'extraActivity',
                'hobbies': 'hobbies',
                'birthplace': 'birthPlace',
                'physicaldeformities': 'physicaldeformities',
                'sufferingchronicdiseases': 'sufferiengChronicDiseases',
                'pmailment': 'pmAilment',
                'iallergicmedicine': 'iAllergicMedicine',
                'qualificationdata': 'qualificationData',
                'schoolcollegedata': 'schoolCollegeData',
                'boarddata': 'boardData',
                'yeardata': 'yearData',
                'perdata': 'perData',
                'cgpagradedata': 'cgpaGradeData',
                'perpcmdata': 'perPCMData',
                'streamdata': 'streamData',
                'mediumdata': 'mediumData',
                'entranceexamname': 'entranceExamName',
                'entrancerollnumber': 'entranceRollNumber',
                'entrancescore': 'entranceScore',
                'entranceyear': 'entranceYear',
                'entrancegenrank': 'entranceGenRank',
                'entrancecategoryrank': 'entranceCategoryRank',
                'entrancemonth': 'entranceMonth',
                'entrancestaterank': 'entranceStateRank',
                'entrancecategoryexam': 'entranceCategoryExam',
                'tenththdivisiongrade': 'tenththdivisionGrade',
                'twelvethdivisiongrade': 'twelvethDivisionGrade',
                'ltexamqualified': 'ltExamQualified',
                'ltrollno': 'ltRollNo',
                'ltinstitute': 'ltInstitute',
                'ltmedium': 'ltMedium',
                'ltmarks': 'ltMarks',
                'talukacorresponding': 'talukaCorresponding',
                'talukapermanent': 'talukaPermanent',
                'talukagardian': 'talukaGardian',
                'islateral': 'isLateral',
                'mailaddress': 'mailAddress',
                'graiyear': 'graIYear',
                'graiiyear': 'graIIYear',
                'graiiiyear': 'graIIIYear',
                'graivyear': 'graIVYear',
                'postgraiyear': 'postGraIYear',
                'postgraiiyear': 'postGraIIYear',
                'btechlat10mathper': 'bTechLat10MathPer',
                'btechlat12mathper': 'bTechLat12MathPer',
                'btechlatdippassyear': 'bTechLatDipPassYear',
                'btechlatdipschool': 'bTechLatDipSchool',
                'btechlatdipsubject': 'bTechLatDipSubject',
                'btechlatbscrollno': 'bTechLatBscRollNo',
                'btechlatbscpassyear': 'bTechLatBscPassYear',
                'btechlatbscschool': 'bTechLatBscSchool',
                'btechlatbscboard': 'bTechLatBscBoard',
                'btechlatbscsubject': 'bTechLatBscSubject',
                'btechlatdip1yearper': 'bTechLatDip1YearPer',
                'btechlatdip2yearper': 'bTechLatDip2YearPer',
                'btechlatdip3yearper': 'bTechLatDip3YearPer',
                'btechlatdip4yearper': 'bTechLatDip4YearPer',
                'btechlatbsc1yearper': 'bTechLatBsc1YearPer',
                'btechlatbsc2yearper': 'bTechLatBsc2YearPer',
                'btechlatbsc3yearper': 'bTechLatBsc3YearPer',
                'btechlatbsc4yearper': 'bTechLatBsc4YearPer',
                'qgradrollno': 'qGradRollNo',
                'qpgrollno': 'qpgRollNo',
                'qothrollno': 'qOthRollNo',
                'mcagradmathper': 'mcaGradMathPer',
                'mcapgmathper': 'mcapgMathPer',
                'pgschool': 'pgSchool',
                'pgboard': 'pgBoard',
                'pgpassyear': 'pgPassYear',
                'pgsubject': 'pgSubject',
                'pgmedium': 'pgMedium',
                'pgobtmark': 'pgObtMark',
                'pgoutmarks': 'pgOutMarks',
                'pgqper': 'pgqPer',
                'pgqualification': 'pgQualification',
                'remarks': 'remarks'
            };

            taskExcelData = rawData.map(function (row, index) {
                var normalized = {};
                Object.keys(row).forEach(function (key) {
                    var cleanKey = key.replace(/ \*$/, '').trim();
                    cleanKey = cleanKey.replace(/[ \-\(\)]/g, '').toLowerCase();

                    // Apply mapping
                    if (columnMap[cleanKey]) {
                        cleanKey = columnMap[cleanKey];
                    }

                    normalized[cleanKey] = row[key];
                });

                normalized.id = index;
                normalized.rowIndex = index;
                normalized.isValid = true;
                normalized.errors = [];
                return normalized;
            });

            validateExcelData();
        } catch (ex) {
            Swal.fire('Error', 'Failed to read Excel file: ' + ex.message, 'error');
        }
    };
    reader.onerror = function () {
        Swal.fire('Error', 'Failed to read file', 'error');
    };
    reader.readAsArrayBuffer(file.file);
}

function validateExcelData() {
    if (!taskExcelData.length) {
        Swal.fire('Warning', 'Please upload an Excel file first', 'warning');
        return;
    }

    taskValidData = [];
    taskInvalidData = [];

    taskExcelData.forEach(function (row, index) {
        row.rowIndex = index;
        var errors = [];
        var isValid = true;

        // Check required fields
        var requiredFields = ['firstName', 'lastName', 'dateOfBirth', 'gender', 'studentMobile'];
        requiredFields.forEach(function (field) {
            var val = row[field];
            if (!val || String(val).trim() === '') {
                var label = FIELD_CONFIG.fieldLabels[field] || field;
                errors.push(label + ' is required');
                isValid = false;
            }
        });

        // Validate Student Mobile
        if (row.studentMobile && String(row.studentMobile).trim() !== '') {
            var cleanMobile = String(row.studentMobile).replace(/\D/g, '');
            if (!/^\d{10}$/.test(cleanMobile)) {
                errors.push('Student Mobile must be 10 digits');
                isValid = false;
            } else {
                row.studentMobile = cleanMobile;
            }
        }

        // Validate Date of Birth format
        if (row.dateOfBirth && String(row.dateOfBirth).trim() !== '') {
            var dobStr = String(row.dateOfBirth).trim();
            var dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!dateRegex.test(dobStr)) {
                errors.push('Date of Birth must be in YYYY-MM-DD format');
                isValid = false;
            } else {
                var dateParts = dobStr.split('-');
                var year = parseInt(dateParts[0]);
                var month = parseInt(dateParts[1]);
                var day = parseInt(dateParts[2]);
                if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) {
                    errors.push('Date of Birth is invalid');
                    isValid = false;
                }
            }
        }

        // Validate Email format
        if (row.studentEmail && String(row.studentEmail).trim() !== '') {
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(String(row.studentEmail).trim())) {
                errors.push('Student Email is invalid');
                isValid = false;
            }
        }

        // Validate Aadhar Card
        if (row.aadharCardNo && String(row.aadharCardNo).trim() !== '') {
            var cleanAadhar = String(row.aadharCardNo).replace(/\D/g, '');
            if (!/^\d{12}$/.test(cleanAadhar)) {
                errors.push('Aadhar Card No must be 12 digits');
                isValid = false;
            } else {
                row.aadharCardNo = cleanAadhar;
            }
        }

        // Validate Pincode
        if (row.permanentPincode && String(row.permanentPincode).trim() !== '') {
            var cleanPincode = String(row.permanentPincode).replace(/\D/g, '');
            if (!/^\d{6}$/.test(cleanPincode)) {
                errors.push('Permanent Pincode must be 6 digits');
                isValid = false;
            } else {
                row.permanentPincode = cleanPincode;
            }
        }

        // Validate Gender
        if (row.gender && String(row.gender).trim() !== '') {
            var genderVal = String(row.gender).trim().toLowerCase();
            if (!['male', 'female', 'other'].includes(genderVal)) {
                errors.push('Gender must be Male, Female, or Other');
                isValid = false;
            } else {
                // Capitalize gender
                row.gender = genderVal.charAt(0).toUpperCase() + genderVal.slice(1);
            }
        }

        // Validate Boolean fields
        var boolFields = ['physicallyChallenged', 'lateralEntry', 'hostelRequired', 'transportRequired', 'messRequired', 'iSSibling', 'isLateral'];
        boolFields.forEach(function (field) {
            if (row[field] && String(row[field]).trim() !== '') {
                var val = String(row[field]).trim().toLowerCase();
                if (val === 'true' || val === '1' || val === 'yes') {
                    row[field] = 'TRUE';
                } else if (val === 'false' || val === '0' || val === 'no') {
                    row[field] = 'FALSE';
                } else if (!['true', 'false', '1', '0', 'yes', 'no'].includes(val)) {
                    errors.push(FIELD_CONFIG.fieldLabels[field] + ' must be TRUE or FALSE');
                    isValid = false;
                }
            }
        });

        row.isValid = isValid;
        row.errors = errors;

        if (isValid) {
            taskValidData.push(row);
        } else {
            taskInvalidData.push(row);
        }
    });

    renderExcelPreview();
    updateExcelStats();

    if (taskInvalidData.length) {
        Swal.fire('Validation Complete', taskValidData.length + ' valid, ' + taskInvalidData.length + ' invalid records found', 'warning');
    } else {
        Swal.fire('Success', 'All ' + taskValidData.length + ' records are valid!', 'success');
    }
}

function renderExcelPreview() {
    var $wrap = $('#excelPreviewWrap');
    $wrap.empty();

    if (!taskExcelData.length) {
        $wrap.html('<div class="text-center text-muted py-3">No data loaded</div>');
        return;
    }

    var allData = [...taskValidData, ...taskInvalidData];
    allData.sort((a, b) => a.rowIndex - b.rowIndex);

    var firstRow = allData[0] || {};
    var allKeys = Object.keys(firstRow).filter(function (key) {
        return key !== 'rowIndex' && key !== 'isValid' && key !== 'errors' && key !== 'id';
    });

    var table = document.createElement('table');
    table.id = 'excelPreviewTable';
    table.className = 'table table-sm table-striped table-bordered';

    var thead = document.createElement('thead');
    var headerRow = document.createElement('tr');

    var fixedHeaders = [
        { key: 'checkbox', label: '<input type="checkbox" id="selectAllRows" />' },
        { key: 'action', label: 'Action' },
        { key: 'sno', label: '#' }
    ];

    fixedHeaders.forEach(function (h) {
        var th = document.createElement('th');
        th.innerHTML = h.label;
        if (h.key === 'checkbox') th.style.width = '30px';
        if (h.key === 'action') th.style.width = '60px';
        if (h.key === 'sno') th.style.width = '30px';
        headerRow.appendChild(th);
    });

    allKeys.forEach(function (key) {
        var th = document.createElement('th');
        var label = FIELD_CONFIG.fieldLabels[key] || key.replace(/([A-Z])/g, ' $1').trim();
        label = label.charAt(0).toUpperCase() + label.slice(1);
        th.textContent = label;
        headerRow.appendChild(th);
    });

    thead.appendChild(headerRow);
    table.appendChild(thead);

    var tbody = document.createElement('tbody');
    tbody.id = 'excelPreviewBody';

    allData.forEach(function (row, idx) {
        var tr = document.createElement('tr');
        if (!row.isValid) {
            tr.className = 'invalid-row';
        }

        var td1 = document.createElement('td');
        td1.innerHTML = '<input type="checkbox" class="row-checkbox" data-id="' + row.id + '" />';
        tr.appendChild(td1);

        var td2 = document.createElement('td');
        td2.innerHTML = '<button class="task-action-icon edit edit-excel-row" data-id="' + row.id + '" title="Edit"><i class="ti ti-edit"></i></button>';
        tr.appendChild(td2);

        var td3 = document.createElement('td');
        td3.textContent = idx + 1;
        tr.appendChild(td3);

        allKeys.forEach(function (key) {
            var td = document.createElement('td');
            var val = row[key] !== undefined && row[key] !== null ? String(row[key]) : '';

            // Check if this is a required field and empty
            var isRequiredAndEmpty = FIELD_CONFIG.required.indexOf(key) !== -1 && !val;

            if (isRequiredAndEmpty || (row.errors && row.errors.length && row.errors.some(e => e.includes(FIELD_CONFIG.fieldLabels[key] || key)))) {
                td.className = 'has-error';
                td.innerHTML = '<span class="text-danger"><i class="ti ti-alert-circle me-1"></i>' + escapeHtml(val || '-') + '</span>';
            } else {
                td.textContent = val || '-';
            }

            tr.appendChild(td);
        });

        tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    $wrap.append(table);

    if ($.fn.DataTable.isDataTable('#excelPreviewTable')) {
        $('#excelPreviewTable').DataTable().destroy();
    }

    $('#excelPreviewTable').DataTable({
        pageLength: 10,
        lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
        scrollX: true,
        scrollY: '400px',
        scrollCollapse: true,
        fixedHeader: true,
        ordering: true,
        columnDefs: [
            { orderable: false, targets: [0, 1] }
        ],
        language: {
            emptyTable: "No data available",
            info: "Showing _START_ to _END_ of _TOTAL_ records",
            infoEmpty: "Showing 0 to 0 of 0 records",
            infoFiltered: "(filtered from _MAX_ total records)",
            lengthMenu: "Show _MENU_ records",
            search: "Search:",
            zeroRecords: "No matching records found"
        },
        drawCallback: function () {
            var api = this.api();
            var data = api.data();
            data.each(function (rowData, index) {
                var rowNode = api.row(index).node();
                if (rowData && rowData.isValid === false) {
                    $(rowNode).addClass('invalid-row');
                }
            });

            $('#selectAllRows').off('change').on('change', function () {
                var checked = $(this).prop('checked');
                $('.row-checkbox').prop('checked', checked);
            });
        }
    });

    $('#selectAllRows').off('change').on('change', function () {
        var checked = $(this).prop('checked');
        $('.row-checkbox').prop('checked', checked);
    });

    if (taskInvalidData && taskInvalidData.length > 0) {
        $('#excelPreviewWrap').addClass('border-danger');
    } else {
        $('#excelPreviewWrap').removeClass('border-danger');
    }
}

function escapeHtml(str) {
    if (!str) return '-';
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function updateExcelStats() {
    $('#excelTotalCount').text(taskExcelData.length);
    $('#excelValidCount').text(taskValidData.length);
    $('#excelInvalidCount').text(taskInvalidData.length);
    $('#excelVerifiedCount').text(taskValidData.length);
    if (taskExcelData.length) {
        $('#excelPreviewSection').show();
        $('#btnValidateExcel, #btnSaveTask').prop('disabled', false);
    } else {
        $('#excelPreviewSection').hide();
        $('#btnValidateExcel, #btnSaveTask').prop('disabled', true);
    }
}

function resetExcelData() {
    taskExcelData = [];
    taskValidData = [];
    taskInvalidData = [];
    if (taskFilePond) taskFilePond.removeFiles();
    $('#excelPreviewBody').empty();
    $('#excelTotalCount, #excelValidCount, #excelInvalidCount, #excelVerifiedCount').text('0');
    $('#excelPreviewSection').hide();
    $('#btnValidateExcel, #btnSaveTask').prop('disabled', true);
    $('#selectAllRows').prop('checked', false);
}

function deleteSelectedRows() {
    var checked = $('.row-checkbox:checked');
    if (!checked.length) {
        Swal.fire('Warning', 'Please select at least one row to delete', 'warning');
        return;
    }

    Swal.fire({
        title: 'Delete Selected Rows?',
        text: 'This action cannot be undone',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Delete',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#dc2626'
    }).then(function (res) {
        if (!res.isConfirmed) return;

        var ids = [];
        checked.each(function () {
            ids.push(parseInt($(this).data('id')));
        });

        // Remove from taskExcelData
        taskExcelData = taskExcelData.filter(function (row) {
            return !ids.includes(row.id);
        });

        // Reset IDs and rowIndex
        taskExcelData.forEach(function (row, index) {
            row.id = index;
            row.rowIndex = index;
        });

        // Clear selections
        $('#selectAllRows').prop('checked', false);

        // Re-validate the remaining data
        validateExcelData();

        Swal.fire('Success', 'Selected rows deleted successfully', 'success');
    });
}

function editExcelRow(id) {
    var row = taskExcelData.find(function (x) { return x.id == id; });
    if (!row) {
        Swal.fire('Error', 'Row not found', 'error');
        return;
    }
    editingRowId = id;
    $('#editFormContainer').empty();
    var keys = Object.keys(row).filter(function (key) {
        return !['id', 'rowIndex', 'isValid', 'errors', 'selected'].includes(key);
    });
    var fieldConfig = {
        firstName: { label: 'First Name', required: true, col: 'col-3' },
        middleName: { label: 'Middle Name', col: 'col-2' },
        lastName: { label: 'Last Name', required: true, col: 'col-3' },
        dateOfBirth: { label: 'DOB', required: true, type: 'date', col: 'col-2' },
        gender: { label: 'Gender', required: true, type: 'select', options: ['Male', 'Female', 'Other'], col: 'col-2' },
        studentMobile: { label: 'Mobile', required: true, type: 'tel', col: 'col-3' },
        studentEmail: { label: 'Email', type: 'email', col: 'col-3' },
        maritalStatus: { label: 'Marital Status', type: 'select', options: ['Unmarried', 'Married', 'Divorced', 'Widowed'], col: 'col-3' },
        categoryId: { label: 'Category', required: true, col: 'col-3' },
        subCategoryId: { label: 'Sub Category', col: 'col-3' },
        feesCategoryId: { label: 'Fees Category', col: 'col-3' },
        nationalityId: { label: 'Nationality', col: 'col-3' },
        religionId: { label: 'Religion', col: 'col-3' },
        bloodGroupId: { label: 'Blood Group', col: 'col-3' },
        fatherPrefix: { label: 'Prefix', col: 'col-2' },
        fatherName: { label: 'Name', col: 'col-4' },
        fatherMobile: { label: 'Mobile', type: 'tel', col: 'col-3' },
        fatherEmail: { label: 'Email', type: 'email', col: 'col-3' },
        fatherProfession: { label: 'Profession', col: 'col-3' },
        fatherQualification: { label: 'Qualification', col: 'col-3' },
        fatherDesignation: { label: 'Designation', col: 'col-3' },
        fatherIncome: { label: 'Income', col: 'col-3' },
        motherPrefix: { label: 'Prefix', col: 'col-2' },
        motherName: { label: 'Name', col: 'col-4' },
        motherMobile: { label: 'Mobile', type: 'tel', col: 'col-3' },
        motherEmail: { label: 'Email', type: 'email', col: 'col-3' },
        motherProfession: { label: 'Profession', col: 'col-3' },
        motherQualification: { label: 'Qualification', col: 'col-3' },
        motherDesignation: { label: 'Designation', col: 'col-3' },
        motherIncome: { label: 'Income', col: 'col-3' },
        guardianPrefix: { label: 'Prefix', col: 'col-2' },
        guardianName: { label: 'Name', col: 'col-4' },
        guardianMobile: { label: 'Mobile', type: 'tel', col: 'col-3' },
        guardianEmail: { label: 'Email', type: 'email', col: 'col-3' },
        guardianRelation: { label: 'Relation', col: 'col-3' },
        guardianProfession: { label: 'Profession', col: 'col-3' },
        guardianQualification: { label: 'Qualification', col: 'col-3' },
        guardianDesignation: { label: 'Designation', col: 'col-3' },
        permanentAddress: { label: 'Address', col: 'col-12' },
        permanentCity: { label: 'City', col: 'col-3' },
        permanentDistrict: { label: 'District', col: 'col-3' },
        permanentState: { label: 'State', col: 'col-2' },
        permanentCountry: { label: 'Country', col: 'col-2' },
        permanentPincode: { label: 'Pincode', col: 'col-2' },
        permanentPhone: { label: 'Phone', col: 'col-3' },
        permanentTaluka: { label: 'Taluka', col: 'col-3' },
        correspondenceAddress: { label: 'Address', col: 'col-12' },
        correspondenceCity: { label: 'City', col: 'col-3' },
        correspondenceDistrict: { label: 'District', col: 'col-3' },
        correspondenceState: { label: 'State', col: 'col-2' },
        correspondenceCountry: { label: 'Country', col: 'col-2' },
        correspondencePincode: { label: 'Pincode', col: 'col-2' },
        correspondencePhone: { label: 'Phone', col: 'col-3' },
        correspondenceMobile: { label: 'Mobile', type: 'tel', col: 'col-3' },
        correspondenceEmail: { label: 'Email', type: 'email', col: 'col-3' },
        aadharCardNo: { label: 'Aadhar No', col: 'col-3' },
        panCardNo: { label: 'PAN No', col: 'col-3' },
        drivingLicenseNo: { label: 'Driving License', col: 'col-3' },
        passportNo: { label: 'Passport No', col: 'col-3' },
        admissionNo: { label: 'Admission No', col: 'col-3' },
        enrollmentNo: { label: 'Enrollment No', col: 'col-3' },
        rollNo: { label: 'Roll No', col: 'col-2' },
        registrationNo: { label: 'Registration No', col: 'col-2' },
        formNo: { label: 'Form No', col: 'col-2' },
        lateralEntry: { label: 'Lateral Entry', type: 'boolean', col: 'col-2' },
        admissionDate: { label: 'Admission Date', type: 'date', col: 'col-3' },
        reportingDate: { label: 'Reporting Date', type: 'date', col: 'col-3' },
        admissionThrough: { label: 'Admission Through', col: 'col-3' },
        admissionQuota: { label: 'Quota', col: 'col-3' },
        admissionReferredBy: { label: 'Referred By', col: 'col-3' },
        employeeRef: { label: 'Employee Ref', col: 'col-3' },
        hostelRequired: { label: 'Hostel', type: 'boolean', col: 'col-2' },
        transportRequired: { label: 'Transport', type: 'boolean', col: 'col-2' },
        messRequired: { label: 'Mess', type: 'boolean', col: 'col-2' },
        bankName: { label: 'Bank Name', col: 'col-4' },
        ifsc: { label: 'IFSC', col: 'col-2' },
        bankAddress: { label: 'Bank Address', col: 'col-4' },
        bankAccountNo: { label: 'Account No', col: 'col-2' },
        siblingName: { label: 'Sibling Name', col: 'col-3' },
        siblingCourse: { label: 'Sibling Course', col: 'col-3' },
        siblingAdmissionNo: { label: 'Sibling Admission No', col: 'col-3' },
        iSSibling: { label: 'Is Sibling', type: 'boolean', col: 'col-3' },
        extraActivity: { label: 'Extra Activity', col: 'col-4' },
        hobbies: { label: 'Hobbies', col: 'col-4' },
        birthPlace: { label: 'Birth Place', col: 'col-4' },
        physicaldeformities: { label: 'Physical Deformities', col: 'col-6' },
        sufferiengChronicDiseases: { label: 'Chronic Diseases', col: 'col-6' },
        pmAilment: { label: 'PM Ailment', col: 'col-4' },
        iAllergicMedicine: { label: 'Allergic Medicine', col: 'col-4' },
        studyGap: { label: 'Study Gap', col: 'col-4' },
        alternateMobile: { label: 'Alternate Mobile', type: 'tel', col: 'col-4' },
        physicallyChallenged: { label: 'Physically Challenged', type: 'boolean', col: 'col-4' },
        qualificationData: { label: 'Qualification', col: 'col-6' },
        schoolCollegeData: { label: 'School/College', col: 'col-6' },
        boardData: { label: 'Board', col: 'col-4' },
        yearData: { label: 'Year', col: 'col-4' },
        perData: { label: 'Percentage', col: 'col-4' },
        cgpaGradeData: { label: 'CGPA/Grade', col: 'col-4' },
        perPCMData: { label: 'PCM %', col: 'col-4' },
        streamData: { label: 'Stream', col: 'col-4' },
        mediumData: { label: 'Medium', col: 'col-4' },
        entranceExamName: { label: 'Exam Name', col: 'col-4' },
        entranceRollNumber: { label: 'Roll No', col: 'col-4' },
        entranceScore: { label: 'Score', col: 'col-2' },
        entranceYear: { label: 'Year', col: 'col-2' },
        entranceGenRank: { label: 'Gen Rank', col: 'col-3' },
        entranceCategoryRank: { label: 'Category Rank', col: 'col-3' },
        entranceMonth: { label: 'Month', col: 'col-3' },
        entranceStateRank: { label: 'State Rank', col: 'col-3' },
        entranceCategoryExam: { label: 'Category Exam', col: 'col-3' },
        tenththdivisionGrade: { label: '10th Division', col: 'col-3' },
        twelvethDivisionGrade: { label: '12th Division', col: 'col-3' },
        ltExamQualified: { label: 'LT Exam Qualified', col: 'col-3' },
        ltRollNo: { label: 'LT Roll No', col: 'col-3' },
        ltInstitute: { label: 'LT Institute', col: 'col-4' },
        ltMedium: { label: 'LT Medium', col: 'col-4' },
        ltMarks: { label: 'LT Marks', col: 'col-4' },
        talukaCorresponding: { label: 'Taluka Corresponding', col: 'col-4' },
        talukaPermanent: { label: 'Taluka Permanent', col: 'col-4' },
        talukaGardian: { label: 'Taluka Gardian', col: 'col-4' },
        isLateral: { label: 'Is Lateral', type: 'boolean', col: 'col-3' },
        mailAddress: { label: 'Mail Address', col: 'col-6' },
        graIYear: { label: 'Gra I Year', col: 'col-2' },
        graIIYear: { label: 'Gra II Year', col: 'col-2' },
        graIIIYear: { label: 'Gra III Year', col: 'col-2' },
        graIVYear: { label: 'Gra IV Year', col: 'col-2' },
        postGraIYear: { label: 'PG I Year', col: 'col-3' },
        postGraIIYear: { label: 'PG II Year', col: 'col-3' },
        bTechLat10MathPer: { label: 'BTech Lat 10 Math %', col: 'col-3' },
        bTechLat12MathPer: { label: 'BTech Lat 12 Math %', col: 'col-3' },
        bTechLatDipPassYear: { label: 'Dip Pass Year', col: 'col-3' },
        bTechLatDipSchool: { label: 'Dip School', col: 'col-3' },
        bTechLatDipSubject: { label: 'Dip Subject', col: 'col-3' },
        bTechLatBscRollNo: { label: 'BSc Roll No', col: 'col-3' },
        bTechLatBscPassYear: { label: 'BSc Pass Year', col: 'col-3' },
        bTechLatBscSchool: { label: 'BSc School', col: 'col-3' },
        bTechLatBscBoard: { label: 'BSc Board', col: 'col-3' },
        bTechLatBscSubject: { label: 'BSc Subject', col: 'col-3' },
        bTechLatDip1YearPer: { label: 'Dip 1 Year %', col: 'col-2' },
        bTechLatDip2YearPer: { label: 'Dip 2 Year %', col: 'col-2' },
        bTechLatDip3YearPer: { label: 'Dip 3 Year %', col: 'col-2' },
        bTechLatDip4YearPer: { label: 'Dip 4 Year %', col: 'col-2' },
        bTechLatBsc1YearPer: { label: 'BSc 1 Year %', col: 'col-2' },
        bTechLatBsc2YearPer: { label: 'BSc 2 Year %', col: 'col-2' },
        bTechLatBsc3YearPer: { label: 'BSc 3 Year %', col: 'col-2' },
        bTechLatBsc4YearPer: { label: 'BSc 4 Year %', col: 'col-2' },
        qGradRollNo: { label: 'Q Grad Roll No', col: 'col-3' },
        qpgRollNo: { label: 'Q PG Roll No', col: 'col-3' },
        qOthRollNo: { label: 'Q Oth Roll No', col: 'col-3' },
        mcaGradMathPer: { label: 'MCA Grad Math %', col: 'col-3' },
        mcapgMathPer: { label: 'MCA PG Math %', col: 'col-3' },
        pgSchool: { label: 'PG School', col: 'col-4' },
        pgBoard: { label: 'PG Board', col: 'col-4' },
        pgPassYear: { label: 'PG Pass Year', col: 'col-4' },
        pgSubject: { label: 'PG Subject', col: 'col-4' },
        pgMedium: { label: 'PG Medium', col: 'col-4' },
        pgObtMark: { label: 'PG Obt Mark', col: 'col-3' },
        pgOutMarks: { label: 'PG Out Marks', col: 'col-3' },
        pgqPer: { label: 'PG %', col: 'col-3' },
        pgQualification: { label: 'PG Qualification', col: 'col-3' },
        remarks: { label: 'Remarks', col: 'col-12' }
    };
    var sections = [
        { id: 'personal', title: 'Personal Information' },
        { id: 'category', title: 'Category & IDs' },
        { id: 'father', title: 'Father Details' },
        { id: 'mother', title: 'Mother Details' },
        { id: 'guardian', title: 'Guardian Details' },
        { id: 'address', title: 'Address' },
        { id: 'documents', title: 'Documents' },
        { id: 'admission', title: 'Admission Details' },
        { id: 'hostel', title: 'Hostel & Transport' },
        { id: 'bank', title: 'Bank Details' },
        { id: 'sibling', title: 'Sibling & Other' },
        { id: 'qualification', title: 'Qualification' },
        { id: 'entrance', title: 'Entrance Exam' },
        { id: 'additional', title: 'Additional Information' }
    ];
    var sectionFields = {
        personal: ['firstName', 'middleName', 'lastName', 'dateOfBirth', 'gender', 'studentMobile', 'studentEmail', 'maritalStatus'],
        category: ['categoryId', 'subCategoryId', 'feesCategoryId', 'nationalityId', 'religionId', 'bloodGroupId'],
        father: ['fatherPrefix', 'fatherName', 'fatherMobile', 'fatherEmail', 'fatherProfession', 'fatherQualification', 'fatherDesignation', 'fatherIncome'],
        mother: ['motherPrefix', 'motherName', 'motherMobile', 'motherEmail', 'motherProfession', 'motherQualification', 'motherDesignation', 'motherIncome'],
        guardian: ['guardianPrefix', 'guardianName', 'guardianMobile', 'guardianEmail', 'guardianRelation', 'guardianProfession', 'guardianQualification', 'guardianDesignation'],
        address: ['permanentAddress', 'permanentCity', 'permanentDistrict', 'permanentState', 'permanentCountry', 'permanentPincode', 'permanentPhone', 'permanentTaluka', 'correspondenceAddress', 'correspondenceCity', 'correspondenceDistrict', 'correspondenceState', 'correspondenceCountry', 'correspondencePincode', 'correspondencePhone', 'correspondenceMobile', 'correspondenceEmail'],
        documents: ['aadharCardNo', 'panCardNo', 'drivingLicenseNo', 'passportNo'],
        admission: ['admissionNo', 'enrollmentNo', 'rollNo', 'registrationNo', 'formNo', 'lateralEntry', 'admissionDate', 'reportingDate', 'admissionThrough', 'admissionQuota', 'admissionReferredBy', 'employeeRef'],
        hostel: ['hostelRequired', 'transportRequired', 'messRequired'],
        bank: ['bankName', 'ifsc', 'bankAddress', 'bankAccountNo'],
        sibling: ['siblingName', 'siblingCourse', 'siblingAdmissionNo', 'iSSibling', 'extraActivity', 'hobbies', 'birthPlace', 'physicaldeformities', 'sufferiengChronicDiseases', 'pmAilment', 'iAllergicMedicine', 'studyGap', 'alternateMobile', 'physicallyChallenged'],
        qualification: ['qualificationData', 'schoolCollegeData', 'boardData', 'yearData', 'perData', 'cgpaGradeData', 'perPCMData', 'streamData', 'mediumData', 'tenththdivisionGrade', 'twelvethDivisionGrade', 'ltExamQualified', 'ltRollNo', 'ltInstitute', 'ltMedium', 'ltMarks', 'graIYear', 'graIIYear', 'graIIIYear', 'graIVYear', 'postGraIYear', 'postGraIIYear', 'bTechLat10MathPer', 'bTechLat12MathPer', 'bTechLatDipPassYear', 'bTechLatDipSchool', 'bTechLatDipSubject', 'bTechLatBscRollNo', 'bTechLatBscPassYear', 'bTechLatBscSchool', 'bTechLatBscBoard', 'bTechLatBscSubject', 'bTechLatDip1YearPer', 'bTechLatDip2YearPer', 'bTechLatDip3YearPer', 'bTechLatDip4YearPer', 'bTechLatBsc1YearPer', 'bTechLatBsc2YearPer', 'bTechLatBsc3YearPer', 'bTechLatBsc4YearPer', 'qGradRollNo', 'qpgRollNo', 'qOthRollNo', 'mcaGradMathPer', 'mcapgMathPer', 'pgSchool', 'pgBoard', 'pgPassYear', 'pgSubject', 'pgMedium', 'pgObtMark', 'pgOutMarks', 'pgqPer', 'pgQualification'],
        entrance: ['entranceExamName', 'entranceRollNumber', 'entranceScore', 'entranceYear', 'entranceGenRank', 'entranceCategoryRank', 'entranceMonth', 'entranceStateRank', 'entranceCategoryExam'],
        additional: ['talukaCorresponding', 'talukaPermanent', 'talukaGardian', 'isLateral', 'mailAddress', 'remarks']
    };
    var container = $('#editFormContainer');
    var formHtml = '';
    sections.forEach(function (section) {
        var fields = sectionFields[section.id] || [];
        var availableFields = fields.filter(function (f) { return keys.includes(f) && fieldConfig[f]; });
        if (availableFields.length === 0) return;
        formHtml += '<div class="section-card mb-2 border rounded">';
        formHtml += '<div class="section-header d-flex align-items-center gap-2 p-1 bg-light border-bottom rounded-top">';
        formHtml += '<span class="fw-semibold small text-primary">' + section.title + '</span>';
        formHtml += '<span class="badge bg-secondary ms-auto">' + availableFields.length + '</span>';
        formHtml += '</div>';
        formHtml += '<div class="section-body p-1">';
        formHtml += '<div class="row g-1">';
        availableFields.forEach(function (key) {
            var cfg = fieldConfig[key];
            var val = row[key] !== undefined && row[key] !== null ? String(row[key]) : '';
            var label = cfg.label || key.replace(/([A-Z])/g, ' $1').trim();
            var isRequired = cfg.required || false;
            var colClass = cfg.col || 'col-3';
            var inputType = cfg.type || 'text';
            formHtml += '<div class="' + colClass + '">';
            formHtml += '<div class="form-group">';
            formHtml += '<label class="form-label small text-muted mb-0">' + escapeHtml(label) + (isRequired ? ' <span class="text-danger">*</span>' : '') + '</label>';
            if (inputType === 'select') {
                formHtml += '<select class="form-select form-select-sm edit-field" data-key="' + key + '">';
                formHtml += '<option value="">Select...</option>';
                (cfg.options || []).forEach(function (opt) {
                    var selected = val === opt ? 'selected' : '';
                    formHtml += '<option value="' + opt + '" ' + selected + '>' + opt + '</option>';
                });
                formHtml += '</select>';
            } else if (inputType === 'boolean') {
                formHtml += '<select class="form-select form-select-sm edit-field" data-key="' + key + '">';
                formHtml += '<option value="">Select...</option>';
                formHtml += '<option value="TRUE" ' + (val === 'TRUE' || val === 'true' ? 'selected' : '') + '>Yes</option>';
                formHtml += '<option value="FALSE" ' + (val === 'FALSE' || val === 'false' ? 'selected' : '') + '>No</option>';
                formHtml += '</select>';
            } else if (inputType === 'date') {
                if (val) {
                    try {
                        var d = new Date(val);
                        if (!isNaN(d.getTime())) {
                            val = d.toISOString().split('T')[0];
                        }
                    } catch (e) { }
                }
                formHtml += '<input class="form-control form-control-sm edit-field" data-key="' + key + '" type="date" value="' + escapeHtml(val) + '" ' + (isRequired ? 'required' : '') + '>';
            } else {
                formHtml += '<input class="form-control form-control-sm edit-field" data-key="' + key + '" type="' + inputType + '" value="' + escapeHtml(val) + '" ' + (isRequired ? 'required' : '') + '>';
            }
            formHtml += '</div>';
            formHtml += '</div>';
        });
        formHtml += '</div>';
        formHtml += '</div>';
        formHtml += '</div>';
    });
    container.html(formHtml);
    $('#editRowIdx').val(id);
    $('#editExcelModal').modal('show');
}
function saveExcelEdit() {
    var id = parseInt($('#editRowIdx').val());
    var row = taskExcelData.find(function (x) { return x.id === id; });
    if (!row) {
        Swal.fire('Error', 'Row not found', 'error');
        return;
    }

    // Collect updated values from dynamic fields
    $('.edit-field').each(function () {
        var key = $(this).data('key');
        var val = $(this).val();

        // Clean up values
        if (val !== undefined && val !== null && String(val).trim() !== '') {
            row[key] = String(val).trim();
        } else {
            row[key] = '';
        }
    });

    $('#editExcelModal').modal('hide');

    // Show loading
    Swal.fire({
        title: 'Validating...',
        text: 'Please wait',
        allowOutsideClick: false,
        didOpen: function () {
            Swal.showLoading();
        }
    });

    // Re-validate the data
    setTimeout(function () {
        validateExcelData();
        Swal.close();
        Swal.fire('Success', 'Row updated successfully', 'success');
    }, 500);
}
function downloadBulkTemplate() {
    var ExcelJS = window.ExcelJS;
    var workbook = new ExcelJS.Workbook();
    workbook.creator = 'IMS System';
    workbook.created = new Date();
    var sheet = workbook.addWorksheet('Bulk Admission', {
        properties: { tabColor: { argb: 'FF4F46E5' } },
        pageSetup: { paperSize: 9, orientation: 'landscape', margins: { left: 0.7, right: 0.7, top: 0.75, bottom: 0.75 } }
    });

    var headers = [
        { key: 'firstName', label: 'First Name', required: true, width: 18 },
        { key: 'middleName', label: 'Middle Name', required: false, width: 15 },
        { key: 'lastName', label: 'Last Name', required: true, width: 18 },
        { key: 'dateOfBirth', label: 'Date of Birth (YYYY-MM-DD)', required: true, width: 22 },
        { key: 'gender', label: 'Gender (Male/Female/Other)', required: true, width: 22 },
        { key: 'studentMobile', label: 'Student Mobile (10 digits)', required: true, width: 22 },
        { key: 'studentEmail', label: 'Student Email', required: false, width: 25 },
        { key: 'categoryId', label: 'Category ID', required: true, width: 18 },
        { key: 'subCategoryId', label: 'Sub Category ID', required: false, width: 18 },
        { key: 'feesCategoryId', label: 'Fees Category ID', required: false, width: 18 },
        { key: 'nationalityId', label: 'Nationality ID', required: false, width: 18 },
        { key: 'religionId', label: 'Religion ID', required: false, width: 18 },
        { key: 'bloodGroupId', label: 'Blood Group ID', required: false, width: 18 },
        { key: 'fatherPrefix', label: 'Father Prefix', required: false, width: 15 },
        { key: 'fatherName', label: 'Father Name', required: false, width: 20 },
        { key: 'fatherMobile', label: 'Father Mobile', required: false, width: 18 },
        { key: 'fatherEmail', label: 'Father Email', required: false, width: 25 },
        { key: 'fatherProfession', label: 'Father Profession', required: false, width: 20 },
        { key: 'fatherQualification', label: 'Father Qualification', required: false, width: 20 },
        { key: 'fatherDesignation', label: 'Father Designation', required: false, width: 20 },
        { key: 'fatherIncome', label: 'Father Income', required: false, width: 18 },
        { key: 'motherPrefix', label: 'Mother Prefix', required: false, width: 15 },
        { key: 'motherName', label: 'Mother Name', required: false, width: 20 },
        { key: 'motherMobile', label: 'Mother Mobile', required: false, width: 18 },
        { key: 'motherEmail', label: 'Mother Email', required: false, width: 25 },
        { key: 'motherProfession', label: 'Mother Profession', required: false, width: 20 },
        { key: 'motherQualification', label: 'Mother Qualification', required: false, width: 20 },
        { key: 'motherDesignation', label: 'Mother Designation', required: false, width: 20 },
        { key: 'motherIncome', label: 'Mother Income', required: false, width: 18 },
        { key: 'guardianPrefix', label: 'Guardian Prefix', required: false, width: 15 },
        { key: 'guardianName', label: 'Guardian Name', required: false, width: 20 },
        { key: 'guardianMobile', label: 'Guardian Mobile', required: false, width: 18 },
        { key: 'guardianEmail', label: 'Guardian Email', required: false, width: 25 },
        { key: 'guardianRelation', label: 'Guardian Relation', required: false, width: 18 },
        { key: 'guardianProfession', label: 'Guardian Profession', required: false, width: 20 },
        { key: 'guardianQualification', label: 'Guardian Qualification', required: false, width: 20 },
        { key: 'guardianDesignation', label: 'Guardian Designation', required: false, width: 20 },
        { key: 'permanentAddress', label: 'Permanent Address', required: false, width: 30 },
        { key: 'permanentCity', label: 'Permanent City', required: false, width: 18 },
        { key: 'permanentDistrict', label: 'Permanent District', required: false, width: 20 },
        { key: 'permanentState', label: 'Permanent State', required: false, width: 18 },
        { key: 'permanentCountry', label: 'Permanent Country', required: false, width: 18 },
        { key: 'permanentPincode', label: 'Permanent Pincode', required: false, width: 18 },
        { key: 'permanentPhone', label: 'Permanent Phone', required: false, width: 18 },
        { key: 'permanentTaluka', label: 'Permanent Taluka', required: false, width: 18 },
        { key: 'correspondenceAddress', label: 'Correspondence Address', required: false, width: 30 },
        { key: 'correspondenceCity', label: 'Correspondence City', required: false, width: 18 },
        { key: 'correspondenceDistrict', label: 'Correspondence District', required: false, width: 20 },
        { key: 'correspondenceState', label: 'Correspondence State', required: false, width: 18 },
        { key: 'correspondenceCountry', label: 'Correspondence Country', required: false, width: 18 },
        { key: 'correspondencePincode', label: 'Correspondence Pincode', required: false, width: 18 },
        { key: 'correspondencePhone', label: 'Correspondence Phone', required: false, width: 18 },
        { key: 'correspondenceMobile', label: 'Correspondence Mobile', required: false, width: 18 },
        { key: 'correspondenceEmail', label: 'Correspondence Email', required: false, width: 25 },
        { key: 'aadharCardNo', label: 'Aadhar Card No (12 digits)', required: false, width: 22 },
        { key: 'panCardNo', label: 'PAN Card No', required: false, width: 18 },
        { key: 'drivingLicenseNo', label: 'Driving License No', required: false, width: 22 },
        { key: 'passportNo', label: 'Passport No', required: false, width: 18 },
        { key: 'maritalStatus', label: 'Marital Status', required: false, width: 18 },
        { key: 'studyGap', label: 'Study Gap (Years)', required: false, width: 18 },
        { key: 'alternateMobile', label: 'Alternate Mobile', required: false, width: 20 },
        { key: 'physicallyChallenged', label: 'Physically Challenged (TRUE/FALSE)', required: false, width: 22 },
        { key: 'admissionNo', label: 'Admission No (For Update)', required: false, width: 20 },
        { key: 'enrollmentNo', label: 'Enrollment No', required: false, width: 18 },
        { key: 'rollNo', label: 'Roll No', required: false, width: 18 },
        { key: 'registrationNo', label: 'Registration No', required: false, width: 18 },
        { key: 'formNo', label: 'Form No', required: false, width: 18 },
        { key: 'lateralEntry', label: 'Lateral Entry (TRUE/FALSE)', required: false, width: 22 },
        { key: 'admissionDate', label: 'Admission Date (YYYY-MM-DD)', required: false, width: 22 },
        { key: 'reportingDate', label: 'Reporting Date (YYYY-MM-DD)', required: false, width: 22 },
        { key: 'admissionThrough', label: 'Admission Through', required: false, width: 20 },
        { key: 'admissionQuota', label: 'Admission Quota', required: false, width: 18 },
        { key: 'admissionReferredBy', label: 'Admission Referred By', required: false, width: 20 },
        { key: 'employeeRef', label: 'Employee Reference', required: false, width: 18 },
        { key: 'semesterId', label: 'Semester ID', required: false, width: 18 },
        { key: 'sectionId', label: 'Section ID', required: false, width: 18 },
        { key: 'shiftId', label: 'Shift ID', required: false, width: 18 },
        { key: 'hostelRequired', label: 'Hostel Required (TRUE/FALSE)', required: false, width: 22 },
        { key: 'transportRequired', label: 'Transport Required (TRUE/FALSE)', required: false, width: 22 },
        { key: 'messRequired', label: 'Mess Required (TRUE/FALSE)', required: false, width: 22 },
        { key: 'bankName', label: 'Bank Name', required: false, width: 20 },
        { key: 'ifsc', label: 'IFSC Code', required: false, width: 18 },
        { key: 'bankAddress', label: 'Bank Address', required: false, width: 30 },
        { key: 'bankAccountNo', label: 'Bank Account No', required: false, width: 22 },
        { key: 'siblingName', label: 'Sibling Name', required: false, width: 20 },
        { key: 'siblingCourse', label: 'Sibling Course', required: false, width: 18 },
        { key: 'siblingAdmissionNo', label: 'Sibling Admission No', required: false, width: 20 },
        { key: 'iSSibling', label: 'Is Sibling (TRUE/FALSE)', required: false, width: 20 },
        { key: 'extraActivity', label: 'Extra Activity', required: false, width: 25 },
        { key: 'hobbies', label: 'Hobbies', required: false, width: 20 },
        { key: 'birthPlace', label: 'Birth Place', required: false, width: 20 },
        { key: 'physicaldeformities', label: 'Physical Deformities', required: false, width: 25 },
        { key: 'sufferiengChronicDiseases', label: 'Suffering Chronic Diseases', required: false, width: 25 },
        { key: 'pmAilment', label: 'PM Ailment', required: false, width: 20 },
        { key: 'iAllergicMedicine', label: 'Allergic Medicine', required: false, width: 20 },
        { key: 'qualificationData', label: 'Qualification (| separated)', required: false, width: 30 },
        { key: 'schoolCollegeData', label: 'School/College (| separated)', required: false, width: 30 },
        { key: 'boardData', label: 'Board (| separated)', required: false, width: 25 },
        { key: 'yearData', label: 'Year (| separated)', required: false, width: 20 },
        { key: 'perData', label: 'Percentage (| separated)', required: false, width: 22 },
        { key: 'cgpaGradeData', label: 'CGPA/Grade (| separated)', required: false, width: 25 },
        { key: 'perPCMData', label: 'PCM Percentage (| separated)', required: false, width: 25 },
        { key: 'streamData', label: 'Stream (| separated)', required: false, width: 20 },
        { key: 'mediumData', label: 'Medium (| separated)', required: false, width: 20 },
        { key: 'entranceExamName', label: 'Entrance Exam Name', required: false, width: 22 },
        { key: 'entranceRollNumber', label: 'Entrance Roll Number', required: false, width: 20 },
        { key: 'entranceScore', label: 'Entrance Score', required: false, width: 18 },
        { key: 'entranceYear', label: 'Entrance Year', required: false, width: 18 },
        { key: 'entranceGenRank', label: 'Entrance Gen Rank', required: false, width: 18 },
        { key: 'entranceCategoryRank', label: 'Entrance Category Rank', required: false, width: 22 },
        { key: 'entranceMonth', label: 'Entrance Month', required: false, width: 18 },
        { key: 'entranceStateRank', label: 'Entrance State Rank', required: false, width: 20 },
        { key: 'entranceCategoryExam', label: 'Entrance Category Exam', required: false, width: 22 },
        { key: 'tenththdivisionGrade', label: '10th Division Grade', required: false, width: 18 },
        { key: 'twelvethDivisionGrade', label: '12th Division Grade', required: false, width: 18 },
        { key: 'ltExamQualified', label: 'LT Exam Qualified', required: false, width: 20 },
        { key: 'ltRollNo', label: 'LT Roll No', required: false, width: 18 },
        { key: 'ltInstitute', label: 'LT Institute', required: false, width: 25 },
        { key: 'ltMedium', label: 'LT Medium', required: false, width: 18 },
        { key: 'ltMarks', label: 'LT Marks', required: false, width: 18 },
        { key: 'talukaCorresponding', label: 'Taluka Corresponding', required: false, width: 20 },
        { key: 'talukaPermanent', label: 'Taluka Permanent', required: false, width: 20 },
        { key: 'talukaGardian', label: 'Taluka Gardian', required: false, width: 20 },
        { key: 'isLateral', label: 'Is Lateral (TRUE/FALSE)', required: false, width: 20 },
        { key: 'mailAddress', label: 'Mail Address', required: false, width: 30 },
        { key: 'graIYear', label: 'Gra I Year', required: false, width: 18 },
        { key: 'graIIYear', label: 'Gra II Year', required: false, width: 18 },
        { key: 'graIIIYear', label: 'Gra III Year', required: false, width: 18 },
        { key: 'graIVYear', label: 'Gra IV Year', required: false, width: 18 },
        { key: 'postGraIYear', label: 'Post Gra I Year', required: false, width: 18 },
        { key: 'postGraIIYear', label: 'Post Gra II Year', required: false, width: 18 },
        { key: 'bTechLat10MathPer', label: 'BTech Lat 10 Math %', required: false, width: 20 },
        { key: 'bTechLat12MathPer', label: 'BTech Lat 12 Math %', required: false, width: 20 },
        { key: 'bTechLatDipPassYear', label: 'BTech Lat Dip Pass Year', required: false, width: 22 },
        { key: 'bTechLatDipSchool', label: 'BTech Lat Dip School', required: false, width: 25 },
        { key: 'bTechLatDipSubject', label: 'BTech Lat Dip Subject', required: false, width: 22 },
        { key: 'bTechLatBscRollNo', label: 'BTech Lat Bsc Roll No', required: false, width: 20 },
        { key: 'bTechLatBscPassYear', label: 'BTech Lat Bsc Pass Year', required: false, width: 22 },
        { key: 'bTechLatBscSchool', label: 'BTech Lat Bsc School', required: false, width: 25 },
        { key: 'bTechLatBscBoard', label: 'BTech Lat Bsc Board', required: false, width: 22 },
        { key: 'bTechLatBscSubject', label: 'BTech Lat Bsc Subject', required: false, width: 22 },
        { key: 'bTechLatDip1YearPer', label: 'BTech Lat Dip 1 Year %', required: false, width: 22 },
        { key: 'bTechLatDip2YearPer', label: 'BTech Lat Dip 2 Year %', required: false, width: 22 },
        { key: 'bTechLatDip3YearPer', label: 'BTech Lat Dip 3 Year %', required: false, width: 22 },
        { key: 'bTechLatDip4YearPer', label: 'BTech Lat Dip 4 Year %', required: false, width: 22 },
        { key: 'bTechLatBsc1YearPer', label: 'BTech Lat Bsc 1 Year %', required: false, width: 22 },
        { key: 'bTechLatBsc2YearPer', label: 'BTech Lat Bsc 2 Year %', required: false, width: 22 },
        { key: 'bTechLatBsc3YearPer', label: 'BTech Lat Bsc 3 Year %', required: false, width: 22 },
        { key: 'bTechLatBsc4YearPer', label: 'BTech Lat Bsc 4 Year %', required: false, width: 22 },
        { key: 'qGradRollNo', label: 'Q Grad Roll No', required: false, width: 18 },
        { key: 'qpgRollNo', label: 'Q PG Roll No', required: false, width: 18 },
        { key: 'qOthRollNo', label: 'Q Oth Roll No', required: false, width: 18 },
        { key: 'mcaGradMathPer', label: 'MCA Grad Math %', required: false, width: 20 },
        { key: 'mcapgMathPer', label: 'MCA PG Math %', required: false, width: 20 },
        { key: 'pgSchool', label: 'PG School', required: false, width: 25 },
        { key: 'pgBoard', label: 'PG Board', required: false, width: 22 },
        { key: 'pgPassYear', label: 'PG Pass Year', required: false, width: 18 },
        { key: 'pgSubject', label: 'PG Subject', required: false, width: 22 },
        { key: 'pgMedium', label: 'PG Medium', required: false, width: 18 },
        { key: 'pgObtMark', label: 'PG Obt Mark', required: false, width: 18 },
        { key: 'pgOutMarks', label: 'PG Out Marks', required: false, width: 18 },
        { key: 'pgqPer', label: 'PG %', required: false, width: 18 },
        { key: 'pgQualification', label: 'PG Qualification', required: false, width: 22 },
        { key: 'remarks', label: 'Remarks', required: false, width: 30 }
    ];

    var headerRow = sheet.addRow(headers.map(function (h) { return h.label + (h.required ? ' *' : ''); }));
    headerRow.height = 35;
    headerRow.font = { bold: true, size: 10, name: 'Calibri', color: { argb: 'FF000000' } };
    headerRow.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };

    headers.forEach(function (h, idx) {
        var cell = headerRow.getCell(idx + 1);
        cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: h.required ? 'FFFFEBEE' : 'FFFFFDE7' }
        };
        cell.font = { bold: true, size: 10, name: 'Calibri', color: { argb: 'FF000000' } };
        cell.border = {
            top: { style: 'thin', color: { argb: 'FFCCCCCC' } },
            left: { style: 'thin', color: { argb: 'FFCCCCCC' } },
            bottom: { style: 'thin', color: { argb: 'FFCCCCCC' } },
            right: { style: 'thin', color: { argb: 'FFCCCCCC' } }
        };
    });

    headers.forEach(function (h, idx) {
        sheet.getColumn(idx + 1).width = h.width || 15;
    });
    sheet.views = [{ state: 'frozen', ySplit: 1 }];
    sheet.autoFilter = {
        from: { row: 1, column: 1 },
        to: { row: 1, column: headers.length }
    };

    var ws2 = workbook.addWorksheet('Instructions', {
        properties: { tabColor: { argb: 'FF4CAF50' } }
    });
    var instructions = [
        ['📋 BULK ADMISSION TEMPLATE - INSTRUCTIONS'],
        [''],
        ['🟥 RED HEADERS = REQUIRED FIELDS (Must be filled)'],
        ['🟨 YELLOW HEADERS = OPTIONAL FIELDS (Can be left blank)'],
        [''],
        ['📌 IMPORTANT GUIDELINES:'],
        ['1. Do not change the column names or order'],
        ['2. All dates must be in YYYY-MM-DD format'],
        ['3. Mobile numbers must be exactly 10 digits'],
        ['4. Aadhar number must be exactly 12 digits'],
        ['5. Pincode must be exactly 6 digits'],
        ['6. Use TRUE/FALSE for boolean fields'],
        ['7. Gender values: Male, Female, Other'],
        ['8. Remove sample row before uploading'],
        ['9. File size should not exceed 10MB'],
        ['10. For multiple qualifications, use | (pipe) separator'],
        ['11. Course, Branch, Batch are taken from UI filters'],
        ['12. Admission No is required for UPDATE mode only'],
        [''],
        ['📊 REQUIRED FIELDS (RED):'],
        ['   First Name          - Student first name'],
        ['   Last Name           - Student last name'],
        ['   Date of Birth       - Student date of birth (YYYY-MM-DD)'],
        ['   Gender              - Male / Female / Other'],
        ['   Student Mobile      - 10 digit mobile number'],
        ['   Category ID         - Valid category code from system'],
        [''],
        ['📊 OPTIONAL FIELDS (YELLOW):'],
        ['   All other fields are optional and can be left blank'],
        ['   Admission No        - For UPDATE mode (system will update existing record)'],
        ['   Qualification Data  - Use | separated values: 10th|12th|Graduation'],
        ['   Entrance Exam       - Entrance exam details if applicable'],
        [''],
        ['⚠️ NOTE:'],
        ['- Sample rows are provided for reference - DELETE them before upload'],
        ['- Upload only valid records after verification'],
        ['- All records will be validated before processing'],
        ['- Course, Branch, Batch are taken from the UI filters']
    ];

    instructions.forEach(function (row, idx) {
        var wsRow = ws2.addRow(row);
        wsRow.height = row[0].startsWith('📋') ? 40 : row[0].trim() === '' ? 5 : 22;
        wsRow.getCell(1).font = {
            bold: row[0].startsWith('📋') || row[0].startsWith('📌') || row[0].startsWith('📊') || row[0].startsWith('⚠️'),
            size: row[0].startsWith('📋') ? 16 : row[0].startsWith('🟥') || row[0].startsWith('🟨') || row[0].startsWith('📌') || row[0].startsWith('📊') || row[0].startsWith('⚠️') ? 12 : 10,
            name: 'Calibri',
            color: { argb: row[0].startsWith('🟥') ? 'FFD32F2F' : row[0].startsWith('🟨') ? 'FFF9A825' : row[0].startsWith('📋') ? 'FF1A237E' : row[0].startsWith('📌') ? 'FF1A237E' : row[0].startsWith('📊') ? 'FF1A237E' : row[0].startsWith('⚠️') ? 'FFE65100' : 'FF333333' }
        };
        wsRow.alignment = { horizontal: row[0].startsWith('📋') ? 'center' : 'left', vertical: 'middle', wrapText: true };
        if (row[0].includes('REQUIRED FIELDS')) {
            wsRow.getCell(1).font = { bold: true, size: 11, name: 'Calibri', color: { argb: 'FFD32F2F' } };
        }
        if (row[0].includes('OPTIONAL FIELDS')) {
            wsRow.getCell(1).font = { bold: true, size: 11, name: 'Calibri', color: { argb: 'FFF9A825' } };
        }
    });
    ws2.getColumn(1).width = 80;

    workbook.xlsx.writeBuffer().then(function (buffer) {
        var blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        var link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'Bulk_Admission_Template.xlsx';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
        Swal.fire('Success', 'Template downloaded successfully!', 'success');
    }).catch(function (error) {
        console.error('Error generating template:', error);
        Swal.fire('Error', 'Failed to generate template. Please try again.', 'error');
    });
}

function initTaskDataTable() {
    if ($.fn.DataTable.isDataTable('#taskDataTable')) {
        $('#taskDataTable').DataTable().destroy();
    }

    taskDataTable = $('#taskDataTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: function (data, callback, settings) {
            var client = new IMSClient();
            var request = {
                Mode: 'LIST',
                Institute_ID: $('#taskFilterInstitute').val() || '',
                TaskStatus: $('#taskFilterStatus').val() || '',
                FromDate: formatSqlDate($('#taskFilterFrom').val()) || '',
                ToDate: formatSqlDate($('#taskFilterTo').val()) || '',
                SortBy: 'CreatedDate',
                SortOrder: 'DESC'
            };

            client.request('/Student/BulkTaskManager', 'POST', request, true)
                .then(function (response) {
                    console.log('LIST Response:', response);

                    var result = typeof response === 'string' ? JSON.parse(response) : response;

                    // Check if response is valid
                    if (result && result.statusCode === 200) {
                        var dataList = result.result || [];

                        // Ensure dataList is an array
                        if (!Array.isArray(dataList)) {
                            dataList = [dataList];
                        }

                        // Apply search filter
                        var searchVal = $('#taskSearch').val() || '';
                        if (searchVal) {
                            dataList = dataList.filter(function (item) {
                                return (item.taskCode || '').toLowerCase().includes(searchVal.toLowerCase()) ||
                                    (item.taskName || '').toLowerCase().includes(searchVal.toLowerCase()) ||
                                    (item.createdBy || '').toLowerCase().includes(searchVal.toLowerCase());
                            });
                        }

                        // Return data in DataTable format
                        callback({
                            draw: data.draw || 1,
                            recordsTotal: dataList.length,
                            recordsFiltered: dataList.length,
                            data: dataList
                        });
                    } else {
                        callback({
                            draw: data.draw || 1,
                            recordsTotal: 0,
                            recordsFiltered: 0,
                            data: []
                        });
                    }
                })
                .catch(function (err) {
                    console.error('DataTable error:', err);
                    callback({
                        draw: data.draw || 1,
                        recordsTotal: 0,
                        recordsFiltered: 0,
                        data: []
                    });
                });
        },
        columns: [
            {
                data: 'taskCode',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display') {
                        return '<span class="fw-semibold text-primary">' + (data || '-') + '</span>';
                    }
                    return data;
                }
            },
            {
                data: 'taskName',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display' && data && data.length > 30) {
                        return '<span title="' + data + '">' + data.substring(0, 30) + '...</span>';
                    }
                    return data || '-';
                }
            },
            {
                data: 'taskType',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display') {
                        return '<span class="badge bg-info">' + (data || 'INSERT') + '</span>';
                    }
                    return data;
                }
            },
            {
                data: 'instituteName',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display' && data && data.length > 20) {
                        return '<span title="' + data + '">' + data.substring(0, 20) + '...</span>';
                    }
                    return data || '-';
                }
            },
            {
                data: 'course_Name',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display') {
                        return data || '-';
                    }
                    return data;
                }
            },
            {
                data: 'branch_Name',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display') {
                        return data || '-';
                    }
                    return data;
                }
            },
            {
                data: 'totalRecords',
                defaultContent: 0,
                render: function (data, type, row) {
                    if (type === 'display') {
                        var total = row.totalRecords || 0;
                        var success = row.successCount || 0;
                        var failed = row.failedCount || 0;
                        var pending = row.pendingCount || 0;
                        return '<span class="fw-semibold">' + total + '</span>' +
                            ' <span class="text-success">(' + success + ' S)</span>' +
                            ' <span class="text-danger">(' + failed + ' F)</span>' +
                            ' <span class="text-warning">(' + pending + ' P)</span>';
                    }
                    return data;
                }
            },
            {
                data: 'totalRecords',
                defaultContent: 0,
                render: function (data, type, row) {
                    if (type === 'display') {
                        var total = row.totalRecords || 0;
                        var success = row.successCount || 0;
                        var failed = row.failedCount || 0;
                        var processed = success + failed;
                        var percent = total > 0 ? Math.round((processed / total) * 100) : 0;
                        var barClass = 'info';
                        if (percent >= 100) barClass = 'success';
                        else if (percent >= 75) barClass = 'info';
                        else if (percent >= 50) barClass = 'warning';
                        else if (percent > 0) barClass = 'danger';

                        return '<div class="task-progress">' +
                            '<div class="progress-track"><div class="bar ' + barClass + '" style="width:' + percent + '%"></div></div>' +
                            '<span class="progress-text">' + percent + '%</span>' +
                            '</div>';
                    }
                    return data;
                }
            },
            {
                data: 'taskStatus',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display') {
                        var status = data || 'Draft';
                        var cls = status.toLowerCase();
                        if (cls === 'inprogress') cls = 'inprogress';
                        if (cls === 'complete') cls = 'success';
                        if (cls === 'rejected') cls = 'danger';
                        if (cls === 'approved') cls = 'info';
                        return '<span class="task-status-badge ' + cls + '">' + status + '</span>';
                    }
                    return data;
                }
            },
            {
                data: 'createdDate',
                defaultContent: '-',
                render: function (data, type, row) {
                    if (type === 'display' && data) {
                        var d = new Date(data);
                        if (!isNaN(d.getTime())) {
                            return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) +
                                ' ' + d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
                        }
                        return data;
                    }
                    return data || '-';
                }
            },
            {
                data: null,
                orderable: false,
                defaultContent: '',
                render: function (data, type, row) {
                    if (type === 'display') {
                        var taskId = row.taskID || 0;
                        var status = row.taskStatus || 'Draft';
                        var html = '';

                        // View button
                        html += '<button class="task-action-icon view" onclick="viewTaskDetail(' + taskId + ')" title="View"><i class="ti ti-eye"></i></button>';

                        // Submit button (Draft only)
                        if (status === 'Draft') {
                            html += '<button class="task-action-icon submit" onclick="submitTask(' + taskId + ')" title="Submit"><i class="ti ti-upload"></i></button>';
                        }

                        // Approve/Reject buttons (Pending only)
                        if (status === 'Pending') {
                            html += '<button class="task-action-icon approve" onclick="approveTask(' + taskId + ')" title="Approve"><i class="ti ti-check"></i></button>';
                            html += '<button class="task-action-icon reject" onclick="rejectTask(' + taskId + ')" title="Reject"><i class="ti ti-x"></i></button>';
                        }

                        // Execute button (Approved only)
                        if (status === 'Approved') {
                            html += '<button class="task-action-icon execute" onclick="executeTask(' + taskId + ')" title="Execute"><i class="ti ti-player-play"></i></button>';
                        }

                        // Delete button (Draft, Rejected, Error only)
                        if (status === 'Draft' || status === 'Rejected' || status === 'Error') {
                            html += '<button class="task-action-icon delete" onclick="deleteTask(' + taskId + ')" title="Delete"><i class="ti ti-trash"></i></button>';
                        }

                        // Export button (Complete or Error)
                        // if (status === 'Complete' || status === 'Error') {
                        //     html += '<button class="task-action-icon export" onclick="exportTaskResult(' + taskId + ')" title="Export"><i class="ti ti-file-spreadsheet"></i></button>';
                        // }

                        return html;
                    }
                    return data;
                }
            }
        ],
        columnDefs: [
            { targets: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], className: 'align-middle' },
            { targets: 10, className: 'text-center' },
            { targets: 6, className: 'text-center' },
            { targets: 7, className: 'text-center' },
            { targets: 8, className: 'text-center' }
        ],
        order: [[9, 'desc']],
        pageLength: 10,
        lengthMenu: [[5, 10, 25, 50, 100, -1], [5, 10, 25, 50, 100, "All"]],
        language: {
            emptyTable: "No tasks found",
            info: "Showing _START_ to _END_ of _TOTAL_ tasks",
            infoEmpty: "Showing 0 to 0 of 0 tasks",
            infoFiltered: "(filtered from _MAX_ total tasks)",
            lengthMenu: "Show _MENU_ tasks",
            search: "Search:",
            zeroRecords: "No matching tasks found"
        },
        drawCallback: function () {
            var info = this.api().page.info();
            $('#taskTableInfo').text('Showing ' + (info.start + 1) + ' to ' + info.end + ' of ' + info.recordsTotal + ' tasks');

            // Update pagination
            var pagination = $('#taskTablePagination');
            pagination.html('');
            if (info.pages > 1) {
                var ul = $('<ul class="pagination pagination-sm mb-0"></ul>');
                if (info.page > 0) {
                    ul.append('<li class="page-item"><button class="page-link" data-page="' + (info.page - 1) + '">«</button></li>');
                }
                var startPage = Math.max(0, info.page - 2);
                var endPage = Math.min(info.pages - 1, info.page + 2);
                for (var i = startPage; i <= endPage; i++) {
                    ul.append('<li class="page-item ' + (i === info.page ? 'active' : '') + '"><button class="page-link" data-page="' + i + '">' + (i + 1) + '</button></li>');
                }
                if (info.page < info.pages - 1) {
                    ul.append('<li class="page-item"><button class="page-link" data-page="' + (info.page + 1) + '">»</button></li>');
                }
                pagination.append(ul);
                pagination.find('.page-link').on('click', function () {
                    var page = parseInt($(this).data('page'));
                    taskDataTable.page(page).draw('page');
                });
            }
        }
    });
}



function loadTaskStats() {
    var client = new IMSClient();
    var request = {
        Mode: 'STATS'
    };
    client.request('/Student/BulkTaskManager', 'POST', request, true)
        .then(function (response) {
            var result = typeof response === 'string' ? JSON.parse(response) : response;
            if (result && result.statusCode === 200 && result.result) {
                var stats = result.result;
                if (Array.isArray(stats) && stats.length > 0) {
                    stats = stats[0];
                }
                $('#totalTasks').text(stats.total || 0);
                $('#draftTasks').text(stats.draft || 0);
                $('#pendingTasks').text(stats.pending || 0);
                $('#approvedTasks').text(stats.approved || 0);
                $('#inprogressTasks').text(stats.inProgress || 0);
                $('#completedTasks').text(stats.complete || 0);
                $('#errorTasks').text(stats.error || 0);
                $('#rejectedTasks').text(stats.rejected || 0);
            }
        })
        .catch(function (err) {
            console.error('Stats error:', err);
        });
}

function createNewTask() {
    var instituteId = $('#TaskInstituteId').val();
    var sessionId = $('#TaskSession').val();
    var programId = $('#TaskProgram').val();
    var branchId = $('#TaskBranch').val();
    var semesterId = $('#TaskSemester').val();
    var taskName = $('#TaskName').val() || 'Bulk Admission Task';
    var taskType = $('#TaskType').val();
    var createDues = $('#TaskCreateDues').val();
    var remarks = $('#TaskRemarks').val();

    if (!instituteId || !sessionId || !programId || !branchId) {
        Swal.fire('Warning', 'Please select Institute, Session, Program and Branch', 'warning');
        return;
    }

    if (!taskValidData.length) {
        Swal.fire('Warning', 'Please upload and validate Excel data first', 'warning');
        return;
    }

    // Helper functions
    function toBoolean(value) {
        if (value === undefined || value === null || value === '' || value === 'null' || value === 'undefined') {
            return false;
        }
        if (typeof value === 'boolean') return value;
        if (typeof value === 'string') {
            var lower = value.toLowerCase().trim();
            return lower === 'true' || lower === '1' || lower === 'yes' || lower === 'y' || lower === 't';
        }
        if (typeof value === 'number') return value === 1;
        return false;
    }

    function toNumberString(value) {
        if (value === undefined || value === null || value === '' || value === 'null' || value === 'undefined') {
            return null;
        }
        var clean = String(value).replace(/,/g, '').trim();
        if (clean === '') return null;
        return clean;
    }

    // Map data
    var bulkData = taskValidData.map(function (row) {
        return {
            FirstName: row.firstName || '',
            LastName: row.lastName || '',
            DOB: row.dateOfBirth || '',
            Gender: row.gender || '',
            StudentMobile: row.studentMobile || '',
            CourseID: programId,
            BranchID: branchId,
            BatchID: sessionId,
            Category: row.categoryId || 'GEN',
            AdmissionNo: row.admissionNo || '',
            MiddleName: row.middleName || '',
            StudentEmail: row.studentEmail || '',
            AAdharCardNo: row.aadharCardNo || '',
            AadharEnrollMentNo: row.aadharEnrollMentNo || '',
            PanCardNo: row.panCardNo || '',
            DrivingLisenceNo: row.drivingLicenseNo || '',
            PassportNo: row.passportNo || '',
            GapInAcadmic: row.gapInAcadmic || '',
            Physicaldeformities: row.physicaldeformities || '',
            SufferiengChronicDiseases: row.sufferiengChronicDiseases || '',
            PMAilment: row.pmAilment || '',
            IAllergicMedicine: row.iAllergicMedicine || '',
            iSSibling: toBoolean(row.iSSibling),
            ExtraActivity: row.extraActivity || '',
            Hobbies: row.hobbies || '',
            BirthPlace: row.birthPlace || '',
            SemesterID: semesterId || '',
            SectionID: row.sectionId || '',
            ShiftID: row.shiftId || '',
            EnrollmentNo: row.enrollmentNo || '',
            RollNo: row.rollNo || '',
            RegistrationNo: row.registrationNo || '',
            FormNo: row.formNo || '',
            LateralEntry: toBoolean(row.lateralEntry),
            AdmissionDate: row.admissionDate || '',
            ReportingDate: row.reportingDate || '',
            AdmissionThrough: row.admissionThrough || '',
            AdmissionQuota: row.admissionQuota || '',
            AdmissionReferredBy: row.admissionReferredBy || '',
            EmployeeRef: row.employeeRef || '',
            SubCategory: row.subCategoryId || '',
            FeesCategory: row.feesCategoryId || 'Regular',
            Remarks: row.remarks || '',
            Exam: row.exam || '',
            School: row.school || '',
            AdmissionTypeId: parseInt(row.admissionTypeId) || 0,
            PreF: row.fatherPrefix || '',
            NameF: row.fatherName || '',
            ProfessionF: row.fatherProfession || '',
            QualificationF: row.fatherQualification || '',
            DesignationF: row.fatherDesignation || '',
            IncomeF: toNumberString(row.fatherIncome),
            MobileF: row.fatherMobile || '',
            DOBF: row.dobf || '',
            OffphoneF: row.offphoneF || '',
            FaxF: row.faxF || '',
            EmailF: row.fatherEmail || '',
            OffAddressF: row.offAddressF || '',
            CompanyF: row.companyF || '',
            AnniversaryDate: row.anniversaryDate || '',
            PreM: row.motherPrefix || '',
            NameM: row.motherName || '',
            ProfessionM: row.motherProfession || '',
            QualificationM: row.motherQualification || '',
            DesignationM: row.motherDesignation || '',
            IncomeM: toNumberString(row.motherIncome),
            MobileM: row.motherMobile || '',
            DOBM: row.dobm || '',
            OffPhoneM: row.offPhoneM || '',
            FaxM: row.faxM || '',
            EmailM: row.motherEmail || '',
            OffAddressM: row.offAddressM || '',
            CompanyM: row.companyM || '',
            PreG: row.guardianPrefix || '',
            NameG: row.guardianName || '',
            ProfessionG: row.guardianProfession || '',
            QualificationG: row.guardianQualification || '',
            DesignationG: row.guardianDesignation || '',
            PhoneG: row.phoneG || '',
            MobileG: row.guardianMobile || '',
            EmailG: row.guardianEmail || '',
            RelationG: row.guardianRelation || '',
            OffAddressG: row.offAddressG || '',
            CompanyG: row.companyG || '',
            OffPhoneG: row.offPhoneG || '',
            GAddress: row.gAddress || '',
            GArea: row.gArea || '',
            GCity: row.gCity || '',
            GDistrict: row.gDistrict || '',
            GTaluka: row.gTaluka || '',
            GState: row.gState || '',
            GCountry: row.gCountry || '',
            GPincode: row.gPincode || '',
            PerAddress: row.permanentAddress || '',
            PerAarea: row.perAarea || '',
            PerCity: row.permanentCity || '',
            PerDistrict: row.permanentDistrict || '',
            PerTaluka: row.perTaluka || '',
            PerState: row.permanentState || '',
            PerCountry: row.permanentCountry || '',
            PerPincode: row.permanentPincode || '',
            PerPhoneNo: row.perPhoneNo || '',
            PerFaxNo: row.perFaxNo || '',
            CorrAddress: row.correspondenceAddress || '',
            CorrArea: row.corrArea || '',
            CorrCity: row.correspondenceCity || '',
            CorrDistrict: row.correspondenceDistrict || '',
            CorrTaluka: row.corrTaluka || '',
            CorrState: row.correspondenceState || '',
            CorrCountry: row.correspondenceCountry || '',
            CorrPincode: row.correspondencePincode || '',
            CorrPhone: row.corrPhone || '',
            CorrMobile: row.correspondenceMobile || '',
            CorrEmail: row.correspondenceEmail || '',
            HostelRequired: toBoolean(row.hostelRequired),
            TransportRequired: toBoolean(row.transportRequired),
            MessRequired: toBoolean(row.messRequired),
            BankName: row.bankName || '',
            IFSC: row.ifsc || '',
            BankAddress: row.bankAddress || '',
            BankAccountNo: row.bankAccountNo || '',
            SiblingName: row.siblingName || '',
            SiblingCourse: row.siblingCourse || '',
            SiblingAdmissionNo: row.siblingAdmissionNo || '',
            QualificationData: row.qualificationData || '',
            SchoolCollegeData: row.schoolCollegeData || '',
            BoardData: row.boardData || '',
            YearData: row.yearData || '',
            ObtainData: row.obtainData || '',
            OutoffData: row.outoffData || '',
            PerData: row.perData || '',
            CGPAGradeData: row.cgpaGradeData || '',
            PerPCMData: row.perPCMData || '',
            StreamData: row.streamData || '',
            MediumData: row.mediumData || '',
            EntranceRollNumber: row.entranceRollNumber || '',
            EntranceGenRank: row.entranceGenRank || '',
            EntranceCategoryRank: row.entranceCategoryRank || '',
            EntranceMonth: row.entranceMonth || '',
            EntranceScore: toNumberString(row.entranceScore),
            EntranceYear: row.entranceYear || '',
            EntranceExamName: row.entranceExamName || '',
            EntranceStateRank: row.entranceStateRank || '',
            EntranceCategoryExam: row.entranceCategoryExam || '',
            Nationality: row.nationalityId || '',
            Religion: row.religionId || '',
            BloodGroup: row.bloodGroupId || '',
            MaritalStatus: row.maritalStatus || '',
            PhysicallyChallenged: toBoolean(row.physicallyChallenged),
            StudyGap: row.studyGap || '',
            AlternateMobile: row.alternateMobile || '',
            tenththdivisionGrade: row.tenththdivisionGrade || '',
            twelvethDivisionGrade: row.twelvethDivisionGrade || '',
            LTExamQualified: row.ltExamQualified || '',
            LTrollNo: row.ltRollNo || '',
            LTInstitute: row.ltInstitute || '',
            LTMedium: row.ltMedium || '',
            LTMarks: toNumberString(row.ltMarks),
            TalukaCorresponding: row.talukaCorresponding || '',
            TalukaPermanent: row.talukaPermanent || '',
            TalukaGardian: row.talukaGardian || '',
            IsLateral: toBoolean(row.isLateral),
            MailAddress: row.mailAddress || '',
            GraIYear: row.graIYear || '',
            GraIIYear: row.graIIYear || '',
            GraIIIYear: row.graIIIYear || '',
            GraIVYear: row.graIVYear || '',
            PostGraIYear: row.postGraIYear || '',
            PostGraIIYear: row.postGraIIYear || '',
            BTechLat10MathPer: toNumberString(row.bTechLat10MathPer),
            BTechLat12MathPer: toNumberString(row.bTechLat12MathPer),
            BTechLatDipPassYear: row.bTechLatDipPassYear || '',
            BTechLatDipSchool: row.bTechLatDipSchool || '',
            BTechLatDipSubject: row.bTechLatDipSubject || '',
            BTechLatBscRollNo: row.bTechLatBscRollNo || '',
            BTechLatBscPassYear: row.bTechLatBscPassYear || '',
            BTechLatBscSchool: row.bTechLatBscSchool || '',
            BTechLatBscBoard: row.bTechLatBscBoard || '',
            BTechLatBscSubject: row.bTechLatBscSubject || '',
            BTechLatDip1YearPer: toNumberString(row.bTechLatDip1YearPer),
            BTechLatDip2YearPer: toNumberString(row.bTechLatDip2YearPer),
            BTechLatDip3YearPer: toNumberString(row.bTechLatDip3YearPer),
            BTechLatDip4YearPer: toNumberString(row.bTechLatDip4YearPer),
            BTechLatBsc1YearPer: toNumberString(row.bTechLatBsc1YearPer),
            BTechLatBsc2YearPer: toNumberString(row.bTechLatBsc2YearPer),
            BTechLatBsc3YearPer: toNumberString(row.bTechLatBsc3YearPer),
            BTechLatBsc4YearPer: toNumberString(row.bTechLatBsc4YearPer),
            QGradRollNo: row.qGradRollNo || '',
            QPGRollNo: row.qpgRollNo || '',
            QOthRollNo: row.qOthRollNo || '',
            MCAGradMathPer: toNumberString(row.mcaGradMathPer),
            MCAPGMathPer: toNumberString(row.mcapgMathPer),
            PGSchool: row.pgSchool || '',
            PGBoard: row.pgBoard || '',
            PGPassYear: row.pgPassYear || '',
            PGSubject: row.pgSubject || '',
            PGMedium: row.pgMedium || '',
            PGObtMark: toNumberString(row.pgObtMark),
            PGOutMarks: toNumberString(row.pgOutMarks),
            PGQPer: toNumberString(row.pgqPer),
            PGQualification: row.pgQualification || ''
        };
    });

    // ====== CONVERT TO JSON ======
    var bulkDataJSON = JSON.stringify(bulkData);

    var request = {
        Mode: 'CREATE',
        Institute_ID: instituteId,
        Batch_ID: sessionId,
        Course_ID: programId,
        Branch_ID: branchId,
        Semester_ID: semesterId || '',
        TaskName: taskName,
        TaskType: taskType,
        CreateDuesOnSave: createDues === '1',
        Remarks: remarks,
        BulkDataJSON: bulkDataJSON  // <-- Send JSON instead of BulkData
    };

    console.log('Request Data:', JSON.stringify(request, null, 2));

    Swal.fire({
        title: 'Creating Task...',
        text: 'Please wait',
        allowOutsideClick: false,
        didOpen: function () {
            Swal.showLoading();
        }
    });

    var client = new IMSClient();
    client.request('/Student/BulkTaskManager', 'POST', request, true)
        .then(function (response) {
            Swal.close();
            var result = typeof response === 'string' ? JSON.parse(response) : response;
            if (result && result.statusCode === 200) {
                Swal.fire('Success', result.message || 'Task created successfully!', 'success');
                if (taskDataTable) taskDataTable.ajax.reload();
                loadTaskStats();
                $('#createTaskCard').slideUp(300, function () {
                    $('#btnCreateTask').html('<i class="ti ti-plus me-1"></i> New Task');
                });
                if (taskFilePond) taskFilePond.removeFiles();
                resetExcelData();
            } else {
                Swal.fire('Error', result.message || 'Failed to create task', 'error');
            }
        })
        .catch(function (err) {
            Swal.close();
            console.error('Error:', err);
            Swal.fire('Error', err.message || 'Failed to create task', 'error');
        });
}
function viewTaskDetail(taskId) {
    $('#taskDetailId').val(taskId);
    $('#taskDetailModal').modal('show');
    var client = new IMSClient();
    var request = {
        Mode: 'DETAIL',
        TaskID: taskId
    };
    client.request('/Student/BulkTaskManager', 'POST', request, true)
        .then(function (response) {
            var result = typeof response === 'string' ? JSON.parse(response) : response;
            if (result && result.statusCode === 200 && result.result) {
                var data = result.result;
                var task = data.task || {};
                $('#detailTaskCode').text(task.taskCode || '-');
                $('#detailTaskName').text(task.taskName || '-');
                $('#detailTaskType').text(task.taskType || '-');
                $('#detailInstitute').text(task.instituteName || '-');
                $('#detailProgram').text(task.course_Name || '-');
                $('#detailBranch').text(task.branch_Name || '-');
                $('#detailBatch').text(task.batch_Name || '-');
                $('#detailSemester').text(task.semester_Name || '-');
                $('#detailDues').text(task.createDuesOnSave ? 'Yes' : 'No');
                $('#detailCreatedBy').text(task.createdBy || '-');
                $('#detailCreatedDate').text(task.createdDate || '-');
                $('#detailApprovedBy').text(task.approvedBy || '-');
                $('#detailApprovedDate').text(task.approvedDate || '-');
                $('#detailExecutedBy').text(task.executedBy || '-');
                $('#detailExecutedDate').text(task.executedDate || '-');
                $('#detailCompletedDate').text(task.completedDate || '-');
                $('#detailRemarks').text(task.remarks || '-');
                var status = task.taskStatus || 'Pending';
                var cls = status.toLowerCase();
                if (cls === 'inprogress') cls = 'inprogress';
                $('#taskDetailStatus').attr('class', 'task-status-badge ' + cls).text(status);
                var stats = data.stats || {};
                $('#detailTotalRecords').text(stats.total || 0);
                $('#detailSuccessRecords').text(stats.success || 0);
                $('#detailErrorRecords').text(stats.error || 0);
                $('#detailPendingRecords').text(stats.pending || 0);
                if (task.errorMessage) {
                    $('#taskDetailError').show();
                    $('#detailErrorMessage').text(task.errorMessage);
                } else {
                    $('#taskDetailError').hide();
                }
                var actionsHtml = '';
                if (status === 'Pending') {
                    actionsHtml += '<button class="btn-custom btn-custom-success btn-custom-sm" onclick="approveTask(' + taskId + ')"><i class="ti ti-check"></i> Approve</button>';
                    actionsHtml += '<button class="btn-custom btn-custom-danger btn-custom-sm" onclick="rejectTask(' + taskId + ')"><i class="ti ti-x"></i> Reject</button>';
                }
                if (status === 'Approved') {
                    actionsHtml += '<button class="btn-custom btn-custom-info btn-custom-sm" onclick="executeTask(' + taskId + ')"><i class="ti ti-play"></i> Execute</button>';
                }
                if (status === 'Draft') {
                    actionsHtml += '<button class="btn-custom btn-custom-warning btn-custom-sm" onclick="submitTask(' + taskId + ')"><i class="ti ti-upload"></i> Submit</button>';
                }
                if (status === 'Draft' || status === 'Rejected' || status === 'Error') {
                    actionsHtml += '<button class="btn-custom btn-custom-danger btn-custom-sm" onclick="deleteTask(' + taskId + ')"><i class="ti ti-trash"></i> Delete</button>';
                }
                if (status === 'Complete' || status === 'Error') {
                    actionsHtml += '<button class="btn-custom btn-custom-primary btn-custom-sm" onclick="exportTaskResult(' + taskId + ')"><i class="ti ti-file-spreadsheet"></i> Export</button>';
                }
                $('#taskDetailActions').html(actionsHtml || '<span class="text-muted small">No actions available</span>');
                var rows = data.rows || [];
                renderTaskRows(rows);
            } else {
                Swal.fire('Error', 'Failed to load task details', 'error');
            }
        })
        .catch(function (err) {
            Swal.fire('Error', err.message || 'Failed to load task details', 'error');
        });
}

function renderTaskRows(rows) {
    var html = '';
    var successCount = 0, errorCount = 0, pendingCount = 0;
    rowDataForDetail = rows || [];
    if (rows && rows.length > 0) {
        $.each(rows, function (i, row) {
            var status = row.rowStatus || 'Pending';
            var statusBadge = 'warning';
            if (status === 'Success') { statusBadge = 'success'; successCount++; }
            else if (status === 'Error') { statusBadge = 'danger'; errorCount++; }
            else { pendingCount++; }
            var studentName = (row.firstName || '') + ' ' + (row.lastName || '');
            var address = (row.perAddress || '') + ', ' + (row.perCity || '') + ', ' + (row.perState || '');
            html += '<tr>';
            html += '<td>' + (i + 1) + '</td>';
            html += '<td>' + (row.rowNumber || '-') + '</td>';
            html += '<td><span class="badge bg-' + statusBadge + '">' + status + '</span></td>';
            html += '<td><span class="badge bg-primary">' + (row.rowAdmissionNo || '-') + '</span></td>';
            html += '<td>' + escapeHtml(studentName || '-') + '</td>';
            html += '<td>' + (row.studentMobile || '-') + '</td>';
            html += '<td>' + (row.nameF || '-') + ' (' + (row.mobileF || '-') + ')</td>';
            html += '<td>' + (row.nameM || '-') + ' (' + (row.mobileM || '-') + ')</td>';
            html += '<td style="max-width:150px;word-break:break-word;">' + escapeHtml(address || '-') + '</td>';
            html += '<td class="text-center">';
            html += '<button class="task-action-icon view row-detail-btn" data-rowid="' + i + '" title="View Full Details"><i class="ti ti-file-text"></i></button>';
            html += '</td>';
            html += '</tr>';
        });
    } else {
        html = '<tr><td colspan="10" class="text-center text-muted py-3">No rows found</td></tr>';
    }
    $('#detailRowBody').html(html);
    $('#detailRowSuccess').text(successCount + ' Success');
    $('#detailRowError').text(errorCount + ' Error');
    $('#detailRowPending').text(pendingCount + ' Pending');
}

function showRowDetail(index) {
    var rows = rowDataForDetail || [];
    if (!rows.length || !rows[index]) {
        Swal.fire('Error', 'Row data not found', 'error');
        return;
    }
    var row = rows[index];
    $('#rowDetailNumber').text(row.rowNumber || '0');
    $('#rowDetailExpandArea').slideDown();
    var html = '';
    var fields = [
        { label: 'Row Number', value: row.rowNumber },
        { label: 'Row Status', value: row.rowStatus },
        { label: 'Admission No', value: row.rowAdmissionNo },
        { label: 'Processed Date', value: row.processedDate ? new Date(row.processedDate).toLocaleString() : '-' },
        { label: 'Error Message', value: row.rowErrorMessage || '-' },
        { label: 'First Name', value: row.firstName },
        { label: 'Middle Name', value: row.middleName },
        { label: 'Last Name', value: row.lastName },
        { label: 'Date of Birth', value: row.dob ? new Date(row.dob).toLocaleDateString() : '-' },
        { label: 'Gender', value: row.gender },
        { label: 'Student Mobile', value: row.studentMobile },
        { label: 'Student Email', value: row.studentEmail },
        { label: 'Category', value: row.category },
        { label: 'Sub Category', value: row.subCategory },
        { label: 'Fees Category', value: row.feesCategory },
        { label: 'Father Name', value: row.nameF },
        { label: 'Father Mobile', value: row.mobileF },
        { label: 'Father Email', value: row.emailF },
        { label: 'Mother Name', value: row.nameM },
        { label: 'Mother Mobile', value: row.mobileM },
        { label: 'Mother Email', value: row.emailM },
        { label: 'Permanent Address', value: row.perAddress },
        { label: 'Permanent City', value: row.perCity },
        { label: 'Permanent District', value: row.perDistrict },
        { label: 'Permanent State', value: row.perState },
        { label: 'Permanent Country', value: row.perCountry },
        { label: 'Permanent Pincode', value: row.perPincode },
        { label: 'Hostel Required', value: row.hostelRequired },
        { label: 'Transport Required', value: row.transportRequired },
        { label: 'Mess Required', value: row.messRequired },
        { label: 'Bank Name', value: row.bankName },
        { label: 'IFSC', value: row.ifsc },
        { label: 'Bank Account No', value: row.bankAccountNo },
        { label: 'Admission Through', value: row.admissionThrough },
        { label: 'Admission Quota', value: row.admissionQuota },
        { label: 'Admission Referred By', value: row.admissionReferredBy },
        { label: 'Employee Reference', value: row.employeeRef },
        { label: 'Nationality', value: row.nationality },
        { label: 'Religion', value: row.religion },
        { label: 'Blood Group', value: row.bloodGroup },
        { label: 'Marital Status', value: row.maritalStatus },
        { label: 'Study Gap', value: row.studyGap },
        { label: 'Aadhar Card No', value: row.aAdharCardNo },
        { label: 'Pan Card No', value: row.panCardNo },
        { label: 'Passport No', value: row.passportNo },
        { label: 'Registration No', value: row.registrationNo },
        { label: 'Enrollment No', value: row.enrollmentNo },
        { label: 'Roll No', value: row.rollNo },
        { label: 'Form No', value: row.formNo },
        { label: 'Exam', value: row.exam },
        { label: 'School', value: row.school },
        { label: 'Remarks', value: row.remarks },
        { label: 'Qualification', value: row.qualificationData },
        { label: 'Entrance Exam', value: row.entranceExamName },
        { label: 'Entrance Roll No', value: row.entranceRollNumber },
        { label: 'Entrance Score', value: row.entranceScore }
    ];
    fields.forEach(function (f) {
        if (f.value !== null && f.value !== undefined && f.value !== '') {
            html += '<div class="col-md-3 col-sm-4 col-6">';
            html += '<div class="row-label">' + f.label + '</div>';
            html += '<div class="row-value">' + escapeHtml(String(f.value)) + '</div>';
            html += '</div>';
        }
    });
    if (!html) {
        html = '<div class="col-12 text-muted text-center">No additional details available</div>';
    }
    $('#rowDetailContent').html(html);
}

function approveTask(taskId) {
    Swal.fire({
        title: 'Approve Task?',
        text: 'This will mark the task as Approved',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Approve',
        cancelButtonText: 'Cancel'
    }).then(function (res) {
        if (!res.isConfirmed) return;
        var client = new IMSClient();
        var request = {
            Mode: 'APPROVE',
            TaskID: taskId
        };
        client.request('/Student/BulkTaskManager', 'POST', request, true)
            .then(function (response) {
                var result = typeof response === 'string' ? JSON.parse(response) : response;
                if (result && result.statusCode === 200) {
                    Swal.fire('Success', result.message || 'Task approved successfully', 'success');
                    $('#taskDetailModal').modal('hide');
                    if (taskDataTable) taskDataTable.ajax.reload();
                    loadTaskStats();
                } else {
                    Swal.fire('Error', result.message || 'Failed to approve task', 'error');
                }
            })
            .catch(function (err) {
                Swal.fire('Error', err.message || 'Failed to approve task', 'error');
            });
    });
}

function rejectTask(taskId) {
    Swal.fire({
        title: 'Reject Task?',
        input: 'text',
        inputPlaceholder: 'Enter rejection reason...',
        inputAttributes: { 'aria-label': 'Rejection reason' },
        showCancelButton: true,
        confirmButtonText: 'Yes, Reject',
        cancelButtonText: 'Cancel',
        preConfirm: function (value) {
            if (!value) {
                Swal.showValidationMessage('Please enter a reason');
                return false;
            }
            return value;
        }
    }).then(function (res) {
        if (!res.isConfirmed || !res.value) return;
        var client = new IMSClient();
        var request = {
            Mode: 'REJECT',
            TaskID: taskId,
            Remarks: res.value
        };
        client.request('/Student/BulkTaskManager', 'POST', request, true)
            .then(function (response) {
                var result = typeof response === 'string' ? JSON.parse(response) : response;
                if (result && result.statusCode === 200) {
                    Swal.fire('Success', result.message || 'Task rejected successfully', 'success');
                    $('#taskDetailModal').modal('hide');
                    if (taskDataTable) taskDataTable.ajax.reload();
                    loadTaskStats();
                } else {
                    Swal.fire('Error', result.message || 'Failed to reject task', 'error');
                }
            })
            .catch(function (err) {
                Swal.fire('Error', err.message || 'Failed to reject task', 'error');
            });
    });
}

function executeTask(taskId) {
    Swal.fire({
        title: 'Execute Task?',
        text: 'This will process all pending records. This action cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Execute',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#dc2626'
    }).then(function (res) {
        if (!res.isConfirmed) return;
        Swal.fire({
            title: 'Executing Task...',
            text: 'Please wait',
            allowOutsideClick: false,
            didOpen: function () {
                Swal.showLoading();
            }
        });
        var client = new IMSClient();
        var request = {
            Mode: 'EXECUTE',
            TaskID: taskId
        };
        client.request('/Student/BulkTaskManager', 'POST', request, true)
            .then(function (response) {
                Swal.close();
                var result = typeof response === 'string' ? JSON.parse(response) : response;
                if (result && result.statusCode === 200) {
                    Swal.fire('Success', result.message || 'Task executed successfully!', 'success');
                    $('#taskDetailModal').modal('hide');
                    if (taskDataTable) taskDataTable.ajax.reload();
                    loadTaskStats();
                } else {
                    Swal.fire('Error', result.message || 'Failed to execute task', 'error');
                }
            })
            .catch(function (err) {
                Swal.close();
                Swal.fire('Error', err.message || 'Failed to execute task', 'error');
            });
    });
}

function submitTask(taskId) {
    Swal.fire({
        title: 'Submit Task?',
        text: 'This will submit the task for approval',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Submit',
        cancelButtonText: 'Cancel'
    }).then(function (res) {
        if (!res.isConfirmed) return;
        var client = new IMSClient();
        var request = {
            Mode: 'SUBMIT',
            TaskID: taskId
        };
        client.request('/Student/BulkTaskManager', 'POST', request, true)
            .then(function (response) {
                var result = typeof response === 'string' ? JSON.parse(response) : response;
                if (result && result.statusCode === 200) {
                    Swal.fire('Success', result.message || 'Task submitted for approval', 'success');
                    $('#taskDetailModal').modal('hide');
                    if (taskDataTable) taskDataTable.ajax.reload();
                    loadTaskStats();
                } else {
                    Swal.fire('Error', result.message || 'Failed to submit task', 'error');
                }
            })
            .catch(function (err) {
                Swal.fire('Error', err.message || 'Failed to submit task', 'error');
            });
    });
}

function deleteTask(taskId) {
    Swal.fire({
        title: 'Delete Task?',
        text: 'This action cannot be undone',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Delete',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#dc2626'
    }).then(function (res) {
        if (!res.isConfirmed) return;
        var client = new IMSClient();
        var request = {
            Mode: 'DELETE',
            TaskID: taskId,
            ForceDelete: false
        };
        client.request('/Student/BulkTaskManager', 'POST', request, true)
            .then(function (response) {
                var result = typeof response === 'string' ? JSON.parse(response) : response;
                if (result && result.statusCode === 200) {
                    Swal.fire('Success', result.message || 'Task deleted successfully', 'success');
                    $('#taskDetailModal').modal('hide');
                    if (taskDataTable) taskDataTable.ajax.reload();
                    loadTaskStats();
                } else {
                    Swal.fire('Error', result.message || 'Failed to delete task', 'error');
                }
            })
            .catch(function (err) {
                Swal.fire('Error', err.message || 'Failed to delete task', 'error');
            });
    });
}

