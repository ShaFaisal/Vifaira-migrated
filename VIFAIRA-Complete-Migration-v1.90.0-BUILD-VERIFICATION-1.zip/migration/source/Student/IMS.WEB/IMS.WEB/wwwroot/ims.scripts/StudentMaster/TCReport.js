﻿$(function () {
    $('.ims-institute').on('change', function () {
        handleInstituteType($(this).val());
    });

    const initialInstitute = $('.ims-institute').val();
    if (initialInstitute) {
        handleInstituteType(initialInstitute);
    }

    if (typeof humanFriendlyDates === 'function') {
        humanFriendlyDates();
    }

    $("#form_TCReport").validate({
        rules: {
            Institute: { required: true },
            Session: { required: true },
        },
        messages: {
            Institute: "Select Institute",
            Session: "Select Academic Session",
        },
        errorElement: "div",
        errorClass: "invalid-feedback",
        highlight: function (el) {
            $(el).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (el) {
            $(el).removeClass("is-invalid").addClass("is-valid");
        },
        errorPlacement: function (err, el) {
            err.insertAfter(el);
        },
        submitHandler: function (form, event) {
            event.preventDefault();
            loadTbl(form);
            return false;
        }
    });
});

async function loadTbl(form) {
    try {
        if (!$("#form_TCReport").valid()) return;

        showLoading(true);
        showNoStudents("Loading TC / NSO data...");

        let formData = new FormData(form);

        const fromDateVal = $('#FromDate').val();
        const toDateVal = $('#ToDate').val();

        if (fromDateVal) {
            formData.append('FromDate', SlashDDMMYY(fromDateVal));
        }
        if (toDateVal) {
            formData.append('ToDate', SlashDDMMYY(toDateVal));
        }

        formData.append('mode', "GetNOcTcApplyDataReport");

        const response = await new IMSClient().request(
            "/student/IssueTcNso",
            "POST",
            formData,
            true
        );

        console.log("Response:", response);

        if (response?.statusCode === 200 && Array.isArray(response.result)) {
            if (response.result.length > 0) {
                bindTbl(response.result);
                updateTotalCount(response.result.length);
            } else {
                showNoStudents("No records found for selected period");
                updateTotalCount(0);
            }
        } else {
            showNoStudents(response?.message || "No data available");
            updateTotalCount(0);
        }

        $('#lastUpdated').text(new Date().toLocaleTimeString());

    } catch (error) {
        console.error("loadTbl error:", error);
        showNoStudents("Server error while loading data", true);
        updateTotalCount(0);
    } finally {
        showLoading(false);
    }
}

function bindTbl(data) {
    let html = `
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm table-hover align-middle mb-0">
                    <thead class="border-bottom ">
                        <tr>
                            <th class="py-2 ps-3 text-dark small"><i class="fas fa-hashtag me-1"></i>SR NO</th>
                            <th class="py-2 text-dark small"><i class="fas fa-id-card me-1"></i>STUDENT ID</th>
                            <th class="py-2 text-dark small"><i class="fas fa-user-graduate me-1"></i>STUDENT NAME</th>
                            <th class="py-2 text-dark small"><i class="fas fa-user-friends me-1"></i>FATHER NAME</th>
                            <th class="py-2 text-dark small"><i class="fas fa-building me-1"></i>INSTITUTE</th>
                            <th class="py-2 text-dark small"><i class="fas fa-book me-1"></i>COURSE</th>
                            <th class="py-2 text-dark small"><i class="fas fa-code-branch me-1"></i>BRANCH</th>
                            <th class="py-2 text-dark small"><i class="fas fa-calendar-alt me-1"></i>SESSION</th>
                            <th class="py-2 text-dark small"><i class="fas fa-tag me-1"></i>STATUS</th>
                            <th class="py-2 text-dark small"><i class="fas fa-file-alt me-1"></i>TYPE</th>
         
                        </tr>
                    </thead>
                    <tbody>`;

    data.forEach((item, index) => {
        let statusIcon = item.admissionStatus === 'TC' ? 'fa-times-circle' : 'fa-exclamation-triangle';
        let statusColor = item.admissionStatus === 'TC' ? 'danger' : 'warning';
        let typeIcon = item.nsoTcType === 'TC' ? 'fa-file-contract' : 'fa-file-signature';

        html += `
        <tr>
            <td class="py-2 ps-3">
                <span class="badge bg-secondary-subtle text-dark rounded-pill">${index + 1}</span>
            </td>
            <td class="py-2">
                <i class="fas fa-qrcode text-primary me-1"></i>
                <span class="fw-medium">${escapeHtml(item.studentID || '-')}</span>
             </td>
            <td class="py-2 fw-semibold">
                <i class="fas fa-user-circle text-success me-1"></i>
                ${escapeHtml(item.studentName || '-')}
             </td>
            <td class="py-2">
                <i class="fas fa-user text-info me-1"></i>
                ${escapeHtml(item.fatherName || '-')}
             </td>
            <td class="py-2">
                <i class="fas fa-school text-warning me-1"></i>
                ${escapeHtml(item.instituteName || '-')}
             </td>
            <td class="py-2">
                <i class="fas fa-graduation-cap text-primary me-1"></i>
                ${escapeHtml(item.course_Name || '-')}
             </td>
            <td class="py-2">
                <i class="fas fa-layer-group text-secondary me-1"></i>
                ${escapeHtml(item.branch_Name || '-')}
             </td>
            <td class="py-2">
                <i class="fas fa-calendar-week text-info me-1"></i>
                ${escapeHtml(item.session_Name || '-')}
             </td>
            <td class="py-2">
                <span class="badge bg-${statusColor}-subtle text-${statusColor}-emphasis">
                    <i class="fas ${statusIcon} me-1"></i>
                    ${escapeHtml(item.admissionStatus || '-')}
                </span>
             </td>
            <td class="py-2">
                <span class="badge bg-dark-subtle text-dark">
                    <i class="fas ${typeIcon} me-1"></i>
                    ${escapeHtml(item.nsoTcType || '-')}
                </span>
             </td>
          
        </tr>`;
    });

    html += `</tbody>
                </table>
            </div>
        </div>
    </div>`;

    $('#table_layout').html(html);
}

function showLoading(show) {
    if (show) {
        $('#loadingSpinner').removeClass("d-none");
        $('#BtnSave').prop('disabled', true);
    } else {
        $('#loadingSpinner').addClass("d-none");
        $('#BtnSave').prop('disabled', false);
    }
}

function showNoStudents(message, isError = false) {
    let icon = isError ? 'fa-exclamation-triangle' : 'fa-file-invoice-dollar';
    let color = isError ? 'text-danger' : 'text-dark';
    $('#table_layout').html(`
        <div class="text-center py-5 ${color}">
            <i class="fas ${icon} fa-3x mb-3 opacity-25"></i>
            <div>${escapeHtml(message)}</div>
            <div class="mt-2 small text-muted">
                <i class="fas fa-info-circle me-1"></i>
                Try changing search filters
            </div>
        </div>
    `);
}

function updateTotalCount(count) {
    $('#totalSubjects').html(`<i class="fas fa-database me-1"></i>${count}`);
}

function showToast(type, message) {
    alert(message);
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

$('#refreshsubjectTable').on('click', function () {
    loadTbl($("#form_TCReport")[0]);
});