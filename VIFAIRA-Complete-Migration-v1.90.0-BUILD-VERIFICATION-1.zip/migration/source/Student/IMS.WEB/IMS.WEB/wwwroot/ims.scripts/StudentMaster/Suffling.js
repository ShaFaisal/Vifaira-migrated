﻿$(function () {
    let submitButtonId = "";
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 500); 
    $('.ims-institute').on('change', function () {
        handleInstituteTypeOnFilterChange($(this).val());
    });
    $('.ims-sufflingItems').on('change', function () {
        handleSuffleItemChange($(this));
    });

    $(document).on("change", "#checkAll", function () {
        $('.student-check').prop('checked', this.checked);
    });

    $('[data-bs-toggle="tooltip"]').tooltip();

    $(document).on("click", "button[type=submit]", function () {
        submitButtonId = this.id;
    });

    updateLabelsBasedOnInstituteType($('.ims-institute').val());

    $("#form_studSufflen").validate({
        ignore: [],
        rules: {
            Institute: { required: true },
            Session: { required: true },
            Course: { required: true },
            Branch: { required: true },
            semester: {
                required: function () {
                    // Only require semester if sem section is visible AND we're not just searching with txtSearch
                    return $("#sem").is(":visible") && !isOnlyTextSearch();
                }
            },
            ItemTobeChange: {
                required: function () {
                    return submitButtonId === "btnSuffle";
                }
            },
            promotSem: {
                required: function () {
                    return submitButtonId === "btnSuffle" && $("#layoutItemTobeChange").is(":visible");
                }
            },
            txtSearch: {
                required: false // Explicitly set to not required
            }
        },

        messages: {
            Institute: "Please select Institute",
            Session: "Please select Session",
            Course: " Please select Course",
            Branch: "Please select Branch",
            semester: "Please select Semester",
            ItemTobeChange: "Please select Action To Be Performed",
            promotSem: "Please select Promote Semester"
        },

        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",

        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback").insertAfter(element);
        },

        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },

        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        },

        submitHandler: function (form, event) {
            event.preventDefault();

            // Clear any existing validation errors for txtSearch
            $('#txtSearch').removeClass('is-invalid').next('.invalid-feedback').remove();

            if (submitButtonId === "searchBtn") {
                fetchSuffleData(form);
            } else if (submitButtonId === "btnSuffle") {
                showSuffleConfirmation(form);
            } else {
                ShowNotification("error", "No Event Found");
            }

            setTimeout(() => { submitButtonId = ""; }, 200);
        }
    });
});

// Helper function to check if only text search is being used
function isOnlyTextSearch() {
    const txtSearch = $('#txtSearch').val().trim();
    const institute = $('#Institute').val();
    const session = $('#Session').val();
    const course = $('#Course').val();
    const branch = $('#Branch').val();
    const semester = $('#semester').val();

    // Return true if txtSearch has value AND all other filters are empty
    return txtSearch !== '' &&
        (!institute || institute === '') &&
        (!session || session === '') &&
        (!course || course === '') &&
        (!branch || branch === '') &&
        (!semester || semester === '');
}

// Override the default validation to handle txtSearch specially
$.validator.addMethod("conditionalRequired", function (value, element, params) {
    const field = $(element);
    const fieldName = field.attr('name');

    // Special handling for semester field when only text search is used
    if (fieldName === 'semester' && isOnlyTextSearch()) {
        return true; // Not required if only text search is used
    }

    // Default required validation
    return value !== null && value !== undefined && value !== '';
}, "This field is required.");

function showSuffleConfirmation(form) {
    const selectedCount = $('#promotion_table_layout input:checked').length;
    const action = $('#ItemTobeChange').val();

    let title = 'Are you sure?';
    let text = '';

    if (action === 'Semester') {
        title = 'Confirm Semester Change';
        text = `You are about to change semester for ${selectedCount} student(s). This action cannot be undone.`;
    } else if (action === 'Status') {
        title = 'Confirm Status Change';
        text = `You are about to change status for ${selectedCount} student(s).`;
    } else if (action === 'SubStatus') {
        title = 'Confirm Sub-Status Change';
        text = `You are about to change sub-status for ${selectedCount} student(s).`;
    } else if (action === 'Branch') {
        title = 'Confirm Branch Change';
        text = `You are about to change branch for ${selectedCount} student(s).`;
    } else if (action === 'Batch') {
        title = 'Confirm Batch Change';
        text = `You are about to change batch for ${selectedCount} student(s).`;
    } else if (action === 'Session') {
        title = 'Confirm Session Change';
        text = `You are about to change session for ${selectedCount} student(s).`;
    } else if (action === 'Group') {
        title = 'Confirm Group Change';
        text = `You are about to change Group for ${selectedCount} student(s).`;
    } else {
        text = `You are about to perform this action on ${selectedCount} student(s).`;
    }

    Swal.fire({
        title: title,
        text: text,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, proceed!',
        cancelButtonText: 'No, cancel',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary me-2',
            cancelButton: 'btn btn-secondary'
        },
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            processStudentSuffling(form);
        } else {
            $('#btnSuffle').prop('disabled', false).html('Process Changes');
        }
    });
}

async function handleInstituteTypeOnFilterChange(inst) {
    await updateLabelsBasedOnInstituteType(inst);

    if (!inst) {
        $("#sem").removeClass("d-none");
        return;
    }

    const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
        { InId: inst, Action: 'GetInstituteType' }, true);

    let type = res?.result?.[0]?.value || "";

    $('#semester').val("");
    type === "School" ? $("#sem").addClass("d-none") : $("#sem").removeClass("d-none");

    $("#SufflingOptionsCard").addClass("d-none");
    $("#ItemTobeChange").val("");
}

async function updateLabelsBasedOnInstituteType(inst) {
    if (!inst) {
        $("#programClassLabel").text("Program/Class");
        $("#branchSectionLabel").text("Branch/Section");
        $("#promoteClassLabel").text("Class");
        $("#promoteSectionLabel").text("Section");
        return;
    }

    try {
        const res = await new IMSClient().request('/DropDownList/GetBindList', "POST",
            { InId: inst, Action: 'GetInstituteType' }, true);

        let type = res?.result?.[0]?.value || "";

        if (type === "School") {
            $("#programClassLabel").text("Class");
            $("#branchSectionLabel").text("Section");
            $("#Course").prev('label').text("Class");
            $("#Branch").prev('label').text("Section");
            $("#Course option:first").text("--All Classes--");
            $("#Branch option:first").text("--All Sections--");
        } else {
            $("#programClassLabel").text("Program");
            $("#branchSectionLabel").text("Branch");
            $("#Course").prev('label').text("Program");
            $("#Branch").prev('label').text("Branch");
            $("#Course option:first").text("--All Programs--");
            $("#Branch option:first").text("--All Branches--");
        }
    } catch {
        $("#programClassLabel").text("Program/Class");
        $("#branchSectionLabel").text("Branch/Section");
    }
}

function fetchSuffleData(form) {
    const btn = $("#searchBtn");
    const html = btn.html();
    btn.prop("disabled", true).html(`<span class="spinner-border spinner-border-sm"></span> Searching...`);

    $("#SufflingOptionsCard, #btnSuffle").addClass("d-none");
    $("#ItemTobeChange").val("");

    let formData = new FormData(form);
    formData.append('mode', "StudentDetail");

    new IMSClient().request('/Student/Suffling', 'POST', formData, true)
        .then((res) => {
            btn.prop("disabled", false).html(html);

            if (res.statusCode === 200 && res.result?.length) {
                convertStudentArray(res.result);
                exportData = res.result;
                $("#SufflingOptionsCard, #layoutItemTobeChange, #btnSuffle").removeClass("d-none");

                ShowNotification("primary", `Found ${res.result.length} student(s)`, "center");
            } else {
                $("#SufflingOptionsCard, #btnSuffle").addClass("d-none");
                ShowNotification("danger", "No students found", "center");

                $('#promotion_table_layout').html(`
                    <div class="text-center py-4">
                        <i class="ti ti-users-off fs-1 text-muted"></i>
                        <p class="text-muted mt-2">No students found</p>
                    </div>`);
            }
        })
        .catch(() => {
            btn.prop("disabled", false).html(html);
            ShowNotification("danger", "Something went wrong", "center");
        });
}

function convertStudentArray(data) {
    const rows = [];
    const isSchool = $("#sem").hasClass("d-none");

    data.forEach((item) => {
        // For School data
        if (isSchool) {
            rows.push([
                `<input type="checkbox" class="student-check" value="${item.admissionNo}">`,
                `<span class="badge bg-primary px-3 py-2"><i class="ti ti-user me-1"></i>${item.admissionNo}</span>`,
                item.adm_rollno || '—',
                `<b class="text-primary">${item.sName}</b>`,
                item.instituteName,
                item.batch_Name ? `<span class="badge bg-info px-3 py-2">${item.batch_Name}</span>` : '—',
                item.session_Name,
                `<span class="badge bg-secondary px-3 py-2">${item.course_Name}</span>`,
                `<span class="badge bg-warning text-dark px-3 py-2">${item.branch_Name}</span>`,
                item.admissionStatus === "Active"
                    ? `<span class="badge bg-success"><i class="ti ti-check me-1"></i> Active</span>`
                    : `<span class="badge bg-danger"><i class="ti ti-x me-1"></i> ${item.admissionStatus || 'Inactive'}</span>`
            ]);
        }
        // For College data
        else {
            rows.push([
                `<input type="checkbox" class="student-check" value="${item.admissionNo}">`,
                `<span class="badge bg-primary px-3 py-2"><i class="ti ti-user me-1"></i>${item.admissionNo}</span>`,
                item.adm_rollno || '—',
                `<b class="text-primary">${item.sName}</b>`,
                item.instituteName,
                item.batch_Name ? `<span class="badge bg-info px-3 py-2">${item.batch_Name}</span>` : '—',
                item.session_Name,
                `<span class="badge bg-secondary px-3 py-2">${item.course_Name}</span>`,
                `<span class="badge bg-warning text-dark px-3 py-2">${item.branch_Name}</span>`,
                item.semester_Name ? `<span class="badge bg-dark px-3 py-2">${item.semester_Name}</span>` : '—',
                item.admissionStatus === "Active"
                    ? `<span class="badge bg-success"><i class="ti ti-check me-1"></i> Active</span>`
                    : `<span class="badge bg-danger"><i class="ti ti-x me-1"></i> ${item.admissionStatus || 'Inactive'}</span>`
            ]);
        }
    });

    datasetStudentTable(rows, isSchool);
}

function datasetStudentTable(dataRows, isSchool) {
    $('#promotion_table_layout').html(`
        <table class="display table-bottom-border app-data-table table-box-hover w-100" id="studentTable"></table>
    `);

    // Define columns based on institute type
    const cols = isSchool ? [
        { title: `<input type="checkbox" id="checkAll">`, width: "50px" },
        { title: "Admission No", width: "120px" },
        { title: "Roll No", width: "100px" },
        { title: "Student Name", width: "200px" },
        { title: "Institute", width: "150px" },
        { title: "Batch", width: "100px" },
        { title: "Session", width: "120px" },
        { title: "Class", width: "100px" },
        { title: "Section", width: "100px" },
        { title: "Status", width: "100px" }
    ] : [
        { title: `<input type="checkbox" id="checkAll">`, width: "50px" },
        { title: "Admission No", width: "120px" },
        { title: "Roll No", width: "100px" },
        { title: "Student Name", width: "200px" },
        { title: "Institute", width: "150px" },
        { title: "Batch", width: "100px" },
        { title: "Session", width: "120px" },
        { title: "Program", width: "120px" },
        { title: "Branch", width: "120px" },
        { title: "Semester", width: "100px" },
        { title: "Status", width: "100px" }
    ];

    $('#studentTable').DataTable({
        data: dataRows,
        paging: true,
        ordering: false,
        searching: false,
        pageLength: 10,
        lengthChange: false,
        autoWidth: false,
        scrollX: true,
        destroy: true,
        responsive: true,
        columns: cols,
        language: {
            emptyTable: "No students found",
            zeroRecords: "No matching students found"
        },
        dom: '<"top">rt<"bottom"lip><"clear">'
    });

    // Re-initialize checkAll functionality
    $(document).off("change", "#checkAll").on("change", "#checkAll", function () {
        $('.student-check').prop('checked', this.checked);
    });
}

function processStudentSuffling(form) {
    const btn = $("#btnSuffle");
    const originalHTML = btn.html();

    btn.prop("disabled", true).html(`
        <span class="spinner-border spinner-border-sm"></span> Processing...
    `);

    let formData = new FormData(form);

    let selectedStudents = $('#promotion_table_layout input:checked')
        .map(function () { return this.value; })
        .get()
        .join(';');

    if (!selectedStudents.trim()) {
        btn.prop("disabled", false).html(originalHTML);
        Swal.fire({
            icon: 'error',
            title: 'No Students Selected',
            text: 'Please select at least one student.',
            confirmButtonColor: '#d33'
        });
        return;
    }

    formData.append("TblStr", selectedStudents);
    formData.append("mode", "StudentSufflingData");

    new IMSClient().request('/Student/Suffling', 'POST', formData, true)
        .then((res) => {
            btn.prop("disabled", false).html(originalHTML);
            console.log(res)
            if (res.statusCode === 200) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: res.msg || "Students updated successfully!",
                    confirmButtonColor: '#3085d6'
                });

                resetAfterSuffling();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Failed',
                    text: res.msg || "Update failed.",
                    confirmButtonColor: '#d33'
                });
            }
        })
        .catch((error) => {
            btn.prop("disabled", false).html(originalHTML);

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error.message || "Something went wrong during update.",
                confirmButtonColor: '#d33'
            });
        });
}

function resetAfterSuffling() {
    $('#form_studSufflen')[0]?.reset();
    clearFormValidation();
    clearStudentTable();
    resetUIState();
}

function clearFormValidation() {
    $('.form-control').removeClass('is-invalid is-valid');
    $('.invalid-feedback').remove();

    const validator = $('#form_studSufflen').validate();
    if (validator) validator.resetForm();
}

function clearStudentTable() {
    if ($.fn.DataTable && $.fn.DataTable.isDataTable('#studentTable')) {
        $('#studentTable').DataTable().destroy();
    }

    $('#promotion_table_layout').html(`
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-users fa-2x text-muted mb-3"></i>
                <h5 class="text-muted">No Students Found</h5>
                <p class="text-muted">Search again to view students.</p>
            </div>
        </div>
    `);
}

function resetUIState() {
    $("#SufflingOptionsCard").addClass("d-none");
    $("#layoutItemTobeChange").addClass("d-none");
    $("#btnSuffle").addClass("d-none");

    $('input[type="checkbox"]').prop('checked', false);

    if ($.fn.select2) {
        $('select').val(null).trigger('change');
    } else {
        $('select').val('');
    }

    $('button[type="submit"]').prop('disabled', false);

    $('#searchBtn').html('Search');
    $('#btnSuffle').html('Process Changes');
}

function handleSuffleItemChange(e) {
    var mode = $(e).val();

    if (mode) {
        $('#layout_suffle').removeClass('d-none');
    } else {
        $('#layout_suffle').addClass('d-none');
    }

    $('.ims-suffleChangeItem').empty();
    $("#LblChanageItm").text($(e).find("option:selected").text());

    const $bind = $('#bindItemChange');
    $bind.attr('data-Action', mode);
    $bind.removeData('action');
    $bind.trigger('change');
}