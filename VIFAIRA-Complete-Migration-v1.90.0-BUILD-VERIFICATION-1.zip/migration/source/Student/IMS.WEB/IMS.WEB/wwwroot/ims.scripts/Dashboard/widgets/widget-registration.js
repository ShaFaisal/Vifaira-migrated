﻿const RegistrationDashboardRenderer = (function () {
    function renderLoading(widget) {
        const container = DashboardCommonRenderer.getWidgetContainer(widget);
        if (!container.length) return;
        container.html(createRegistrationLoadingCard());
    }

    function render(widget, rawData) {
        const container = DashboardCommonRenderer.getWidgetContainer(widget);
        if (!container.length) return;

        const data = unwrapWidgetData(rawData);
        const model = normalizeRegistrationTables(data.result || []);
        const chartId = 'dashboardRegistrationChart_' + uniqueId();

        container.html(`
            <div class="card h-100 dashboard-analytic-card">
                <div class="card-body p-3 p-md-4">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
                        <div>
                            <h5 class="mb-1">Registration Summary</h5>
                            <small class="text-muted">${DashboardCommonRenderer.escapeHtml(model.currentSessionName || 'Current Session')}</small>
                        </div>
                        <span class="badge bg-primary">Registration</span>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            ${createMiniStatCard('primary', 'ph-stack', 'Total', formatSmartValue(model.grandTotal))}
                        </div>
                        <div class="col-6">
                            ${createMiniStatCard('danger', 'ph-chart-line-up', 'Current', formatSmartValue(model.currentSessionTotal))}
                        </div>
                        <div class="col-6">
                            ${createMiniStatCard('info', 'ph-calendar-check', 'Previous', formatSmartValue(model.previousSessionTotal))}
                        </div>
                        <div class="col-6">
                            ${createMiniStatCard('secondary', 'ph-chart-donut', 'Diff', formatSignedValue(model.differenceCount))}
                        </div>
                    </div>

                    <div class="dashboard-chart-block">
                        <div id="${chartId}"></div>
                    </div>
                </div>
            </div>
        `);

        setTimeout(() => {
            renderRegistrationChart(chartId, model);
        }, 50);
    }

    function renderFallback(widget, message) {
        const container = DashboardCommonRenderer.getWidgetContainer(widget);
        if (!container.length) return;

        container.html(createChartFallbackCard('Registration Summary', message || 'No registration data available', 'primary', 'ph-chart-line'));
    }

    return {
        renderLoading,
        render,
        renderFallback
    };
})();

function normalizeRegistrationTables(result) {
    const table1 = getTableData(result, 'Table1');
    const table2 = getTableData(result, 'Table2');
    const table3 = getTableData(result, 'Table3');

    const instituteRows = table1.map(r => ({
        InstituteID: r.InstituteID || '',
        InstituteName: r.InstituteName || 'Unknown Institute',
        TotalRegistration: Number(r.TotalRegistration || 0)
    }));

    const grandTotal = Number(
        table2?.[0]?.TotalRegistration ||
        instituteRows.reduce((sum, r) => sum + Number(r.TotalRegistration || 0), 0)
    );

    const sessionRows = table3.map(r => ({
        InstituteID: r.InstituteID || '',
        InstituteName: r.InstituteName || 'Unknown Institute',
        SessionName: r.SessionName || 'Unknown Session',
        RegistrationCount: Number(r.RegistrationCount || 0)
    }));

    let uniqueSessions = [...new Set(sessionRows.map(r => r.SessionName).filter(Boolean))];
    if (!uniqueSessions.length) uniqueSessions = ['Current Session'];

    uniqueSessions = uniqueSessions.sort((a, b) => {
        const aStart = parseInt(String(a).split('-')[0], 10) || 0;
        const bStart = parseInt(String(b).split('-')[0], 10) || 0;
        return aStart - bStart;
    });

    const uniqueInstitutes = [...new Set([
        ...instituteRows.map(r => r.InstituteName),
        ...sessionRows.map(r => r.InstituteName)
    ].filter(Boolean))];

    const mergedSessions = [];

    uniqueInstitutes.forEach(instituteName => {
        const t1 = instituteRows.find(r => r.InstituteName === instituteName);
        const instituteSessionRows = sessionRows.filter(r => r.InstituteName === instituteName);

        if (instituteSessionRows.length) {
            uniqueSessions.forEach(session => {
                const found = instituteSessionRows.find(r => r.SessionName === session);
                mergedSessions.push({
                    InstituteName: instituteName,
                    SessionName: session,
                    RegistrationCount: found ? Number(found.RegistrationCount || 0) : 0
                });
            });
        } else {
            uniqueSessions.forEach((session, idx) => {
                mergedSessions.push({
                    InstituteName: instituteName,
                    SessionName: session,
                    RegistrationCount: idx === uniqueSessions.length - 1 ? Number(t1?.TotalRegistration || 0) : 0
                });
            });
        }
    });

    const currentSessionName = uniqueSessions[uniqueSessions.length - 1] || 'Current Session';
    const previousSessionName = uniqueSessions.length > 1 ? uniqueSessions[uniqueSessions.length - 2] : 'Previous Session';

    const currentSessionTotal = mergedSessions
        .filter(r => r.SessionName === currentSessionName)
        .reduce((sum, r) => sum + Number(r.RegistrationCount || 0), 0);

    const previousSessionTotal = mergedSessions
        .filter(r => r.SessionName === previousSessionName)
        .reduce((sum, r) => sum + Number(r.RegistrationCount || 0), 0);

    const differenceCount = currentSessionTotal - previousSessionTotal;
    const comparisonPercent = calculateComparisonPercent(currentSessionTotal, previousSessionTotal);

    return {
        grandTotal,
        uniqueSessions,
        uniqueInstitutes,
        mergedSessions,
        currentSessionName,
        previousSessionName,
        currentSessionTotal,
        previousSessionTotal,
        differenceCount,
        comparisonPercent
    };
}

function renderRegistrationChart(chartId, model) {
    const el = document.querySelector('#' + chartId);
    if (!el || typeof ApexCharts === 'undefined') return;

    destroyChart(chartId);

    const categories = Array.isArray(model.uniqueSessions) && model.uniqueSessions.length ? model.uniqueSessions : ['Current Session'];
    const institutes = Array.isArray(model.uniqueInstitutes) && model.uniqueInstitutes.length ? model.uniqueInstitutes.slice(0, 4) : ['Total'];

    const colors = ['#4361ee', '#dc3545', '#0dcaf0', '#6c757d', '#ffc107'];

    const instituteSeries = institutes.map((institute, idx) => {
        const instituteRows = (model.mergedSessions || []).filter(r => r.InstituteName === institute);
        return {
            name: shortenLabel(institute, 14),
            type: idx === 0 ? 'area' : 'line',
            data: categories.map(category => {
                const found = instituteRows.find(r => r.SessionName === category);
                return found ? Number(found.RegistrationCount || 0) : 0;
            })
        };
    });

    const totalSeries = {
        name: 'Total',
        type: 'line',
        data: categories.map(category => {
            return (model.mergedSessions || [])
                .filter(r => r.SessionName === category)
                .reduce((sum, r) => sum + Number(r.RegistrationCount || 0), 0);
        })
    };

    const finalSeries = [...instituteSeries, totalSeries];

    dashboardChartInstances[chartId] = new ApexCharts(el, {
        chart: {
            height: 280,
            type: 'line',
            toolbar: { show: false },
            fontFamily: '"Rubik", sans-serif',
            background: 'transparent'
        },
        series: finalSeries,
        colors: colors.slice(0, finalSeries.length),
        stroke: {
            curve: 'smooth',
            width: finalSeries.map((s, i) => i === finalSeries.length - 1 ? 3 : 2)
        },
        fill: {
            type: finalSeries.map(s => s.type === 'area' ? 'gradient' : 'solid'),
            gradient: {
                shadeIntensity: 0,
                opacityFrom: 0.15,
                opacityTo: 0.02,
                stops: [0, 90, 100]
            }
        },
        dataLabels: { enabled: false },
        markers: { size: 3, hover: { size: 5 } },
        xaxis: {
            categories: categories,
            labels: { style: { fontSize: '11px', fontWeight: 400 } }
        },
        yaxis: {
            labels: {
                formatter: function (val) { return formatSmartValue(val); },
                style: { fontSize: '11px' }
            }
        },
        grid: { borderColor: '#e9ecef', strokeDashArray: 4 },
        legend: { position: 'top', horizontalAlign: 'right', fontSize: '11px', offsetY: 0 },
        tooltip: { shared: true, intersect: false, theme: 'light' }
    });

    dashboardChartInstances[chartId].render();
}