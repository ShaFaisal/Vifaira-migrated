﻿$(document).ready(function () {

    loadCertificateData();

    $("#form_CertificateReport").submit(function (e) {
        e.preventDefault();
        loadCertificateData();
    });

    $("#btnRefresh").click(function () {
        $("#form_CertificateReport")[0].reset();
        loadCertificateData();
    });

    $(document).on('click', '.btn-view-certificate-history', function () {

        openHistory({
            studentId: $(this).data('studentid'),
            institute: $(this).data('institute'),
            session: $(this).data('session'),
            course: $(this).data('course'),
            branch: $(this).data('branch')
        });

    });

});


async function loadCertificateData() {

    const btn = $("#btnSearchCertificate");
    const oldHtml = btn.html();

    btn.prop("disabled", true)
        .html(`<span class="spinner-border spinner-border-sm"></span>`);

    $("#table_layout").html(`
        <div class="text-center py-4">
            <span class="spinner-border spinner-border-sm"></span>
        </div>
    `);

    try {

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', {
            Institute: $("#Institute").val() || '',
            Session: $("#Session").val() || '',
            Course: $("#Course").val() || '',
            Branch: $("#Branch").val() || '',
            Type: $("#PrintCertificateType").val() || '',
            Date: $("#Date").val() || null,
            ToDate: $("#ToDate").val() || null,
            txtSearch: $("#txtSearch").val() || '',
            mode: "GetCertificateReport"
        }, true);

        initMainTable(res?.result || []);

    } catch {
        showEmpty();
    } finally {
        btn.prop("disabled", false).html(oldHtml);
    }
}


function initMainTable(data) {

    if (!data.length) {
        showEmpty();
        return;
    }

    $("#table_layout").html(`<table id="certTable" class="table table-sm table-bordered w-100"></table>`);

    if ($.fn.DataTable.isDataTable('#certTable')) {
        $('#certTable').DataTable().destroy();
        $('#certTable').empty();
    }

    $('#certTable').DataTable({
        data: data,
        lengthChange: false,
        searching: false,
        ordering: false,
        columns: [

            {
                title: "#",
                data: null,
                render: (d, t, r, m) => m.row + 1
            },

            {
                title: "Student",
                data: null,
                render: x => `
                    <div class="fw-semibold">${x.studentName}</div>
                    <small><i class="ti ti-id me-1"></i>${x.studentID}</small>
                `
            },

            {
                title: "Class",
                data: null,
                render: x => `
                    <span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle">
                        <i class="ti ti-school me-1"></i>${x.course_Name}
                    </span>
                    <div class="small">${x.branch_Name}</div>
                `
            },

            {
                title: "Session",
                data: "session",
                render: d => getSessionBadge(d)
            },

            {
                title: "Type",
                data: "certificateType",
                render: d => getCertificateTypeBadge(d)
            },

            {
                title: "Date",
                data: null,
                render: x => formatDate(x.issueDate || x.printedDate)
            },

            {
                title: "Print",
                data: "printCount",
                render: d => getPrintBadge(d)
            },

            {
                title: "Remark",
                data: "remark",
                defaultContent: "-"
            },

            {
                title: "Action",
                data: null,
                render: x => x.printCount > 0 ? `
                    <button class="btn btn-sm btn-outline-secondary btn-view-certificate-history"
                        data-studentid="${x.studentID}"
                        data-institute="${x.institute}"
                        data-session="${x.session}"
                        data-course="${x.courseID}"
                        data-branch="${x.branchID}">
                        <i class="ti ti-history"></i>
                    </button>` : ""
            }
        ]
    });

    $("#totalSubjects").text(data.length);
    $("#lastUpdated").text(new Date().toLocaleTimeString());
}


async function openHistory(meta) {

    const modal = new bootstrap.Modal(document.getElementById('certificateHistoryModal'));

    $('#historyContainer').html(`
        <div class="text-center py-4">
            <span class="spinner-border spinner-border-sm"></span>
        </div>
    `);

    modal.show();

    try {

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', {
            Institute: meta.institute,
            Session: meta.session,
            Course: meta.course,
            Branch: meta.branch,
            StudentID: meta.studentId,
            mode: "GetCertificateHistory"
        }, true);

        let data = res?.result || [];

        if (!data.length) {
            $('#historyContainer').html(`<div class="text-center py-4">No history</div>`);
            return;
        }

        $('#historyContainer').html(`<table id="historyTable" class="table table-sm table-bordered w-100"></table>`);

        if ($.fn.DataTable.isDataTable('#historyTable')) {
            $('#historyTable').DataTable().destroy();
            $('#historyTable').empty();
        }

        $('#historyTable').DataTable({
            data: data,
            lengthChange:false,
            searching: false,
            ordering: false,
            columns: [

                {
                    title: "#",
                    data: null,
                    render: (d, t, r, m) => m.row + 1
                },

                {
                    title: "Type",
                    data: "certificateType",
                    render: d => getCertificateTypeBadge(d)
                },

                {
                    title: "Date",
                    data: null,
                    render: x => formatDate(x.issueDate || x.createdDate)
                },

                {
                    title: "Remark",
                    data: "remark",
                    defaultContent: "-"
                },

                {
                    title: "Print",
                    data: "printCount",
                    render: d => getPrintBadge(d)
                },

                {
                    title: "Printed",
                    data: "printedDate",
                    render: d => formatDate(d)
                }
            ]
        });

    } catch {
        $('#historyContainer').html(`<div class="text-center text-danger py-4">Error</div>`);
    }
}


function getCertificateTypeBadge(type) {

    if (!type) return `<span class="badge border">-</span>`;

    type = type.toUpperCase();

    if (type === 'CHARACTER')
        return `<span class="badge bg-success-subtle text-success-emphasis border border-success-subtle"><i class="ti ti-user-check me-1"></i>Character</span>`;

    if (type === 'PROVISIONAL')
        return `<span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle"><i class="ti ti-file-check me-1"></i>Provisional</span>`;

    if (type === 'MIGRATION')
        return `<span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle"><i class="ti ti-arrows-exchange me-1"></i>Migration</span>`;

    if (type === 'DMC')
        return `<span class="badge bg-info-subtle text-info-emphasis border border-info-subtle"><i class="ti ti-report me-1"></i>DMC</span>`;

    if (type === 'BONAFIDE')
        return `<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle"><i class="ti ti-certificate me-1"></i>Bonafide</span>`;

    return `<span class="badge border">${type}</span>`;
}


function getPrintBadge(count) {
    return `<span class="badge ${count > 0
        ? 'bg-success-subtle text-success-emphasis border border-success-subtle'
        : 'bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle'}">
        <i class="ti ti-printer me-1"></i>${count}
    </span>`;
}


function getSessionBadge(session) {
    return `<span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle">
        <i class="ti ti-calendar me-1"></i>${session}
    </span>`;
}


function formatDate(d) {
    if (!d) return "-";
    return new Date(d).toLocaleString();
}


function showEmpty() {
    $("#table_layout").html(` <div class="text-center py-5">
                            <i class="fas fa-id-card fa-3x text-muted opacity-25"></i>
                            <h5 class="text-muted fw-semibold mt-2">No Student Data Found</h5>
                            <p class="text-muted mb-2">Use filters above to load eligible student records for Certicicate.</p>
                            <div class="px-3 py-2 rounded d-inline-block bg-primary border">
                                <i class="fas fa-lightbulb text-warning me-2"></i>
                                <small>Search by Institute, Session, Class, Section, Semester or Txt Search.</small>
                            </div>
                        </div>`);
}