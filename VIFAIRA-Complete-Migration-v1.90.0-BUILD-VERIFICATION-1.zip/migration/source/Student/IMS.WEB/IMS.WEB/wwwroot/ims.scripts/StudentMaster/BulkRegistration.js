﻿
$(function () {
  
    console.log('Initializing FilePond...');
    const filePond = initializeFilePond();

    // Download template handler
    $('#downloadTemplate').on('click', function (e) {
        e.preventDefault();
        downloadBulkTemplate();
    });

    // Validate data button
    $('#validateDataBtn').on('click', function () {
        validateBulkData();
    });

    // Save bulk upload
    $('#saveBulkUpload').on('click', function () {
        saveBulkRegistration();
    });

    // Clear bulk data
    $('#clearBulkData').on('click', function () {
        resetBulkUpload();
    });

    // Institute change handler for bulk section
    $('#BulkInstituteId').on('change', function () {
        validateAcademicFilters();
    });

    $('#BulkProgram').on('change', function () {
        validateAcademicFilters();
    });

    $('#BulkBranch').on('change', function () {
        validateAcademicFilters();
    });

    console.log('Bulk registration initialized successfully');
});

// Initialize FilePond
function initializeFilePond() {
    FilePond.registerPlugin(
        FilePondPluginFileValidateType,
        FilePondPluginFileValidateSize
    );

    const pond = FilePond.create(document.getElementById('excelFilePond'), {
        allowFileTypeValidation: true,
        acceptedFileTypes: ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
        maxFileSize: '10MB',
        maxFiles: 1,
        allowMultiple: false,
        instantUpload: false,

        labelIdle: 'Drag & Drop your Excel file or <span class="filepond--label-action">Browse</span>',
        labelInvalidField: 'Field contains invalid files',
        labelFileWaitingForSize: 'Waiting for size',
        labelFileSizeNotAvailable: 'Size not available',
        labelFileLoading: 'Loading',
        labelFileLoadError: 'Error during load',
        labelFileProcessing: 'Processing',
        labelFileProcessingComplete: 'Processing complete',
        labelFileProcessingAborted: 'Processing cancelled',
        labelFileProcessingError: 'Error during processing',
        labelFileProcessingRevertError: 'Error during revert',
        labelFileRemoveError: 'Error during remove',
        labelTapToCancel: 'tap to cancel',
        labelTapToRetry: 'tap to retry',
        labelTapToUndo: 'tap to undo',
        labelButtonRemoveItem: 'Remove',
        labelButtonAbortItemLoad: 'Abort',
        labelButtonRetryItemLoad: 'Retry',
        labelButtonAbortItemProcessing: 'Cancel',
        labelButtonUndoItemProcessing: 'Undo',
        labelButtonRetryItemProcessing: 'Retry',
        labelButtonProcessItem: 'Process'
    });

    pond.on('addfile', (error, file) => {
        if (error) {
            ShowNotification("danger", "Error adding file: " + error, "center");
            return;
        }

        console.log('File added:', file.filename);

        if (!validateAcademicFilters()) {
            pond.removeFile();
            return;
        }

        const fileName = file.filename.toLowerCase();
        if (!fileName.endsWith('.xls') && !fileName.endsWith('.xlsx')) {
            ShowNotification("primary", "Please upload only Excel files (.xls, .xlsx)", "center");
            pond.removeFile();
            return;
        }

        $('.upload-progress').show();
        updateProgress(20);

        setTimeout(() => {
            readExcelFile(file.file);
        }, 500);
    });

    pond.on('removefile', () => {
        console.log('File removed');
        resetBulkPreview();
    });

    window.pond = pond;
    return pond;
}

// Validate academic filters
function validateAcademicFilters() {
    const instituteId = $('#BulkInstituteId').val();
    const program = $('#BulkProgram').val();
    const branch = $('#BulkBranch').val();

    if (!instituteId) {
        ShowNotification("primary", "Please select Institute first", "center");
        return false;
    }
    if (!program) {
        ShowNotification("primary", "Please select Program", "center");
        return false;
    }
    if (!branch) {
        ShowNotification("primary", "Please select Branch", "center");
        return false;
    }

    return true;
}

// Read and process Excel file
function readExcelFile(file) {
    console.log('Reading Excel file:', file.name);

    const reader = new FileReader();

    reader.onload = function (e) {
        try {
            updateProgress(60);
            console.log('File read successfully');

            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetNames = workbook.SheetNames;
            const firstSheetName = sheetNames[0];
            const firstSheet = workbook.Sheets[firstSheetName];
            const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });

            console.log('Excel data loaded:', jsonData.length, 'rows');
            console.log('First few rows:', jsonData.slice(0, 3));

            if (jsonData.length < 2) {
                ShowNotification("primary", "Excel file is empty or has no data", "center");
                updateProgress(100);
                setTimeout(() => $('.upload-progress').hide(), 1000);
                return;
            }

            // Store data globally for editing
            window.currentExcelData = jsonData;
            previewBulkData(jsonData);
            updateProgress(100);

            setTimeout(() => {
                $('.upload-progress').hide();
                const recordCount = jsonData.length - 1;
                ShowNotification("success", `File processed successfully. ${recordCount} records found.`, "center");
                $('#validateDataBtn').prop('disabled', false);
                $('#clearBulkData').prop('disabled', false);
            }, 500);

        } catch (error) {
            console.error('Error processing Excel:', error);
            updateProgress(100);
            setTimeout(() => $('.upload-progress').hide(), 1000);
            ShowNotification("danger", "Error reading Excel file: " + error.message, "center");
        }
    };

    reader.onerror = function (error) {
        console.error('FileReader error:', error);
        updateProgress(100);
        setTimeout(() => $('.upload-progress').hide(), 1000);
        ShowNotification("danger", "Error reading file", "center");
    };

    reader.readAsArrayBuffer(file);
}

// Preview bulk data with all fields
function previewBulkData(data) {
    console.log('Previewing data with all fields, rows:', data.length);

    const tbody = $('#bulkPreviewTableBody');
    tbody.empty();

    let validCount = 0;
    let invalidCount = 0;
    let errorMessages = [];

    // Direct column mapping according to Excel template
    const columnMapping = {
        0: 'FirstName',      // A - FirstName*
        1: 'MiddleName',     // B - MiddleName  
        2: 'LastName',       // C - LastName
        3: 'StudDOB',        // D - DOB*
        4: 'StudMobile',     // E - Mobile*
        5: 'StudEmail',      // F - Email
        6: 'Gender',         // G - Gender*
        7: 'FatherName',     // H - FatherName*
        8: 'FatherMob',      // I - FatherMobile*
        9: 'FatherEmail',    // J - FatherEmail
        10: 'MotherName',    // K - MotherName*
        11: 'MotherMob',     // L - MotherMobile
        12: 'LstQualification', // M - Qualification*
        13: 'Category',      // N - Category
        14: 'StudAadhar',    // O - AadharNumber
        15: 'CurrAddress',   // P - Address*
        16: 'City',          // Q - City
        17: 'District',      // R - District
        18: 'State',         // S - State*
        19: 'Zipcode'        // T - Pincode
    };

    const headers = data[0] || [];
    console.log('Excel Headers:', headers);

    // Use direct mapping
    const actualMapping = columnMapping;

    console.log('Using mapping:', actualMapping);

    // Process data rows (skip header)
    for (let i = 1; i < data.length; i++) {
        const row = data[i];
        if (row && row.length > 0 && !isEmptyRow(row)) {

            console.log(`Processing Row ${i}:`, row);

            // Get ALL values for the row
            const rowValues = {};
            for (let j = 0; j < 20; j++) {
                rowValues[j] = getCellValue(row, j, actualMapping);
            }
            console.log(`Row ${i} values:`, rowValues);

            const validation = validateStudentRow(row, actualMapping);
            const isValid = validation.isValid;

            if (isValid) validCount++;
            else invalidCount++;

            if (validation.errors.length > 0) {
                errorMessages.push(`Row ${i}: ${validation.errors.join(', ')}`);
            }

            const status = isValid ?
                '<span class="badge bg-success">Valid</span>' :
                '<span class="badge bg-danger">Invalid</span>';

            // Create table row with ALL fields
            const tableRow = `
                <tr data-row-index="${i}" class="${isValid ? '' : 'table-warning'}" data-original-values='${JSON.stringify(rowValues)}'>
                    <td>${i}</td>
                    <!-- Personal Details -->
                    <td>${rowValues[0] || ''}</td>
                    <td>${rowValues[1] || ''}</td>
                    <td>${rowValues[2] || ''}</td>
                    <td>${formatDate(rowValues[3]) || '-'}</td>
                    <td>${rowValues[4] || ''}</td>
                    <td>${rowValues[5] || ''}</td>
                    <td>${rowValues[6] || ''}</td>
                    
                    <!-- Father Details -->
                    <td>${rowValues[7] || ''}</td>
                    <td>${rowValues[8] || ''}</td>
                    <td>${rowValues[9] || ''}</td>
                    
                    <!-- Mother Details -->
                    <td>${rowValues[10] || ''}</td>
                    <td>${rowValues[11] || ''}</td>
                    
                    <!-- Academic Details -->
                    <td>${rowValues[12] || ''}</td>
                    <td>${rowValues[13] || ''}</td>
                    
                    <!-- Aadhar -->
                    <td>${rowValues[14] || ''}</td>
                    
                    <!-- Address Details -->
                    <td class="text-truncate" style="max-width: 200px;" title="${rowValues[15] || ''}">
                        ${rowValues[15] || ''}
                    </td>
                    <td>${rowValues[16] || ''}</td>
                    <td>${rowValues[17] || ''}</td>
                    <td>${rowValues[18] || ''}</td>
                    <td>${rowValues[19] || ''}</td>
                    
                    <td>${status}</td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-outline-primary me-1" onclick="editBulkRow(this)" data-bs-toggle="tooltip" title="Edit Row">
                            <i class="ti ti-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="removeBulkRow(this)" data-bs-toggle="tooltip" title="Remove Row">
                            <i class="ti ti-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
            tbody.append(tableRow);
        }
    }

    updateBulkCounters(validCount, invalidCount);

    if (errorMessages.length > 0) {
        $('#bulkErrors').html(`
            <div class="alert alert-warning">
                <h6><i class="ti ti-alert-triangle me-2"></i>Validation Issues Found</h6>
                <ul class="mb-0">
                    ${errorMessages.slice(0, 5).map(msg => `<li class="small">${msg}</li>`).join('')}
                    ${errorMessages.length > 5 ? `<li class="small">... and ${errorMessages.length - 5} more issues</li>` : ''}
                </ul>
            </div>
        `).show();
    } else {
        $('#bulkErrors').hide();
    }

    initializeBulkPreviewTable();
    $('[data-bs-toggle="tooltip"]').tooltip();
}

// Get cell value with mapping
function getCellValue(row, expectedIndex, mapping) {
    // Direct mapping - expectedIndex is the actual Excel column index
    const actualIndex = expectedIndex;

    if (actualIndex !== undefined && row[actualIndex] !== undefined && row[actualIndex] !== null) {
        const value = row[actualIndex];

        // Convert to string and trim
        let stringValue;
        if (typeof value === 'number') {
            // Handle Excel numbers
            if (expectedIndex === 3) { // Date
                stringValue = value.toString();
            } else if (expectedIndex === 4 || expectedIndex === 8 || expectedIndex === 11) { // Mobile numbers
                stringValue = value.toString().split('.')[0];
            } else {
                stringValue = value.toString();
            }
        } else {
            stringValue = value.toString();
        }

        return stringValue.trim();
    }

    return '';
}

// Validate student row
function validateStudentRow(row, mapping) {
    const errors = [];

    console.log('=== VALIDATING ROW ===');

    // Get ALL values first
    const values = {};
    for (let i = 0; i < 20; i++) {
        values[i] = getCellValue(row, i, mapping);
    }

    console.log('All field values:', values);

    // Required fields validation
    if (!values[0]) errors.push("First Name is required");

    if (!values[3]) {
        errors.push("Date of Birth is required");
    } else if (!isValidDate(values[3])) {
        errors.push("Invalid Date of Birth format");
    }

    if (!values[12]) errors.push("Qualification is required");

    if (!values[6]) {
        errors.push("Gender is required");
    } else {
        const genderLower = values[6].toLowerCase();
        if (!['male', 'female', 'other'].includes(genderLower)) {
            errors.push("Gender must be Male, Female, or Other");
        }
    }

    if (!values[4]) {
        errors.push("Mobile is required");
    } else if (!isValidMobile(values[4])) {
        errors.push("Invalid Mobile number");
    }

    if (!values[8]) {
        errors.push("Father Mobile is required");
    } else if (!isValidMobile(values[8])) {
        errors.push("Invalid Father Mobile number");
    }

    if (!values[7]) errors.push("Father Name is required");

    if (!values[10]) errors.push("Mother Name is required");

    if (!values[15]) errors.push("Address is required");

    if (!values[18]) errors.push("State is required");

    console.log('Validation errors:', errors);
    console.log('=== VALIDATION COMPLETE ===');

    return {
        isValid: errors.length === 0,
        errors: errors
    };
}

// Utility validations
function isValidDate(dateString) {
    if (!dateString) return false;

    try {
        // Handle Excel serial date numbers
        if (typeof dateString === 'number') {
            return true;
        }

        // Handle string dates
        const date = new Date(dateString);
        return !isNaN(date.getTime());
    } catch {
        return false;
    }
}

function isValidMobile(mobile) {
    if (!mobile) return false;

    // Handle different input types
    let mobileStr;
    if (typeof mobile === 'number') {
        mobileStr = mobile.toString().split('.')[0];
    } else {
        mobileStr = mobile.toString();
    }

    // Remove all non-digit characters
    mobileStr = mobileStr.replace(/\D/g, '');

    // Check if it's a valid 10-digit Indian mobile number
    const mobileRegex = /^[6-9]\d{9}$/;
    return mobileRegex.test(mobileStr);
}

function isEmptyRow(row) {
    return !row.some(cell => cell !== null && cell !== undefined && cell.toString().trim() !== '');
}

function formatDate(dateString) {
    if (!dateString) return '-';
    try {
        // Handle Excel serial date numbers
        if (typeof dateString === 'number') {
            try {
                const date = XLSX.SSF.parse_date_code(dateString);
                return new Date(date.y, date.m - 1, date.d).toLocaleDateString();
            } catch (e) {
                return dateString.toString();
            }
        }

        const date = new Date(dateString);
        if (isNaN(date.getTime())) return dateString.toString();
        return date.toLocaleDateString();
    } catch (e) {
        return dateString.toString();
    }
}

// Update progress bar
function updateProgress(percent) {
    $('#progressBar').css('width', percent + '%');
    $('#progressPercent').text(percent + '%');
}

// Remove row from bulk preview
function removeBulkRow(button) {
    const row = $(button).closest('tr');

    Swal.fire({
        title: 'Remove Record?',
        text: "Are you sure you want to remove this record from the upload?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, remove it!',
        cancelButtonText: 'Cancel',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-danger me-2',
            cancelButton: 'btn btn-secondary'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            row.remove();
            updateBulkCounters();
            ShowNotification("info", "Record removed from upload", "center");
        }
    });
}

// Edit row
function editBulkRow(button) {
    console.log('Edit row clicked');

    const row = $(button).closest('tr');
    const cells = row.find('td');

    // Get original values from data attribute
    const originalValues = JSON.parse(row.attr('data-original-values') || '{}');
    console.log('Original values:', originalValues);

    // Convert to editable for all data columns (skip #, Status, Actions)
    cells.slice(1, 21).each(function (index) {
        const cell = $(this);
        const currentValue = cell.text().trim();

        console.log(`Editing cell ${index}: "${currentValue}"`);

        if (index === 3) { // DOB field - date input
            cell.html(`<input type="date" class="form-control form-control-sm" value="${formatDateForInput(currentValue)}">`);
        } else if (index === 6) { // Gender field - select
            const gender = currentValue.toLowerCase();
            cell.html(`
                <select class="form-select form-select-sm">
                    <option value="">Select Gender</option>
                    <option value="Male" ${gender === 'male' ? 'selected' : ''}>Male</option>
                    <option value="Female" ${gender === 'female' ? 'selected' : ''}>Female</option>
                    <option value="Other" ${gender === 'other' ? 'selected' : ''}>Other</option>
                </select>
            `);
        } else {
            cell.html(`<input type="text" class="form-control form-control-sm" value="${currentValue}">`);
        }
    });

    // Change buttons to save/cancel
    row.find('td:last').html(`
        <button class="btn btn-sm btn-success me-1" onclick="saveBulkRowEdit(this)" data-bs-toggle="tooltip" title="Save Changes">
            <i class="ti ti-check"></i>
        </button>
        <button class="btn btn-sm btn-secondary" onclick="cancelBulkRowEdit(this)" data-bs-toggle="tooltip" title="Cancel">
            <i class="ti ti-x"></i>
        </button>
    `);

    // Add editing class for styling
    row.addClass('table-info');

    console.log('Row editing mode activated');
}

// Format date for date input
function formatDateForInput(dateString) {
    if (!dateString) return '';

    try {
        // Handle Excel serial dates
        if (typeof dateString === 'number') {
            try {
                const date = XLSX.SSF.parse_date_code(dateString);
                const year = date.y;
                const month = String(date.m).padStart(2, '0');
                const day = String(date.d).padStart(2, '0');
                return `${year}-${month}-${day}`;
            } catch (e) {
                return '';
            }
        }

        // Handle string dates
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return '';

        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    } catch (e) {
        return '';
    }
}

// Save edited row
function saveBulkRowEdit(button) {
    console.log('Save row edit clicked');

    const row = $(button).closest('tr');
    const cells = row.find('td');
    const newValues = [];

    // Collect all edited values
    cells.slice(1, 21).each(function (index) {
        const input = $(this).find('input, select');
        if (input.length > 0) {
            const value = input.val() || '';
            newValues.push(value);
            $(this).text(value);
        } else {
            newValues.push($(this).text());
        }
    });

    console.log('New values collected:', newValues);

    // Update the data attribute with new values
    const updatedValues = {};
    for (let i = 0; i < newValues.length; i++) {
        updatedValues[i] = newValues[i];
    }
    row.attr('data-original-values', JSON.stringify(updatedValues));

    // Revalidate the row with the NEW values
    const validation = validateStudentRow(newValues, {});
    const statusCell = cells.eq(21);

    console.log('Revalidation result:', validation);

    statusCell.html(validation.isValid ?
        '<span class="badge bg-success">Valid</span>' :
        '<span class="badge bg-danger">Invalid</span>'
    );

    if (!validation.isValid) {
        row.addClass('table-warning').removeClass('table-info');
        ShowNotification("primary", `Row validation failed: ${validation.errors.join(', ')}`, "center");
    } else {
        row.removeClass('table-warning table-info');
        ShowNotification("success", "Row updated successfully", "center");
    }

    // Restore action buttons
    cells.eq(22).html(`
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editBulkRow(this)" data-bs-toggle="tooltip" title="Edit Row">
            <i class="ti ti-edit"></i>
        </button>
        <button class="btn btn-sm btn-outline-danger" onclick="removeBulkRow(this)" data-bs-toggle="tooltip" title="Remove Row">
            <i class="ti ti-trash"></i>
        </button>
    `);

    updateBulkCounters();

    console.log('Row edit saved');
}

// Cancel edit
function cancelBulkRowEdit(button) {
    console.log('Cancel row edit clicked');

    const row = $(button).closest('tr');
    const cells = row.find('td');
    const originalValues = JSON.parse(row.attr('data-original-values') || '{}');

    console.log('Restoring original values:', originalValues);

    if (Object.keys(originalValues).length > 0) {
        // Restore original values
        cells.slice(1, 21).each(function (index) {
            if (originalValues[index] !== undefined) {
                $(this).text(originalValues[index]);
            }
        });
    }

    // Restore action buttons
    cells.eq(22).html(`
        <button class="btn btn-sm btn-outline-primary me-1" onclick="editBulkRow(this)" data-bs-toggle="tooltip" title="Edit Row">
            <i class="ti ti-edit"></i>
        </button>
        <button class="btn btn-sm btn-outline-danger" onclick="removeBulkRow(this)" data-bs-toggle="tooltip" title="Remove Row">
            <i class="ti ti-trash"></i>
        </button>
    `);

    // Remove editing classes
    row.removeClass('table-info table-warning');

    // Revalidate with original values
    const originalArray = Object.values(originalValues);
    const validation = validateStudentRow(originalArray, {});
    const statusCell = cells.eq(21);

    statusCell.html(validation.isValid ?
        '<span class="badge bg-success">Valid</span>' :
        '<span class="badge bg-danger">Invalid</span>'
    );

    if (!validation.isValid) {
        row.addClass('table-warning');
    }

    updateBulkCounters();
    ShowNotification("info", "Edit cancelled", "center");

    console.log('Row edit cancelled');
}

// Update bulk counters
function updateBulkCounters(validCount = null, invalidCount = null) {
    if (validCount === null || invalidCount === null) {
        validCount = $('#bulkPreviewTableBody .badge.bg-success').length;
        invalidCount = $('#bulkPreviewTableBody .badge.bg-danger').length;
    }

    const totalRows = validCount + invalidCount;

    $('#previewCount').text(`${totalRows} records`);
    $('#validCount').text(`${validCount} valid`);
    $('#invalidCount').text(`${invalidCount} invalid`);

    const progressPercent = totalRows > 0 ? Math.round((validCount / totalRows) * 100) : 0;
    $('#validationProgress').css('width', `${progressPercent}%`);
    $('#validationSummary').text(`${validCount}/${totalRows} records valid (${progressPercent}%)`);
}

// Initialize bulk preview table DataTable
function initializeBulkPreviewTable() {
    if ($.fn.DataTable.isDataTable('#bulkDataPreview')) {
        $('#bulkDataPreview').DataTable().destroy();
    }

    $('#bulkDataPreview').DataTable({
        searching: true,
        paging: true,
        info: true,
        lengthChange: true,
        pageLength: 5,
        responsive: true,
        scrollX: true,
        dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rt<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            search: "Search records:",
            lengthMenu: "Show _MENU_ records",
            info: "Showing _START_ to _END_ of _TOTAL_ records",
            infoEmpty: "No records available",
            emptyTable: "No data to display",
            paginate: {
                first: "First",
                last: "Last",
                next: "Next",
                previous: "Previous"
            }
        },
        columnDefs: [
            { targets: [0, 21, 22], orderable: false },
            { targets: 0, width: "50px" },
            { targets: 21, width: "90px" },
            { targets: 22, width: "120px" },
            { targets: 15, width: "200px" }
        ],
        order: [[0, 'asc']]
    });
}

// Validate all bulk data
function validateBulkData() {
    const invalidRows = $('#bulkPreviewTableBody .badge.bg-danger').length;
    const totalRows = $('#bulkPreviewTableBody tr').length;

    if (totalRows === 0) {
        ShowNotification("primary", "No data to validate. Please upload an Excel file first.", "center");
        return false;
    }

    if (invalidRows > 0) {
        ShowNotification("primary", `Found ${invalidRows} invalid records. Please fix them before uploading.`, "center");

        const firstInvalid = $('#bulkPreviewTableBody .badge.bg-danger').first().closest('tr');
        if (firstInvalid.length) {
            $('html, body').animate({
                scrollTop: firstInvalid.offset().top - 100
            }, 500);
        }

        return false;
    }

    $('#saveBulkUpload').prop('disabled', false);
    ShowNotification("success", "All data validated successfully! Ready for upload.", "center");
    return true;
}

// Download template
function downloadBulkTemplate() {
    const templateData = [
        ['FirstName*', 'MiddleName', 'LastName', 'DOB*(YYYY-MM-DD)', 'Mobile*(10 digits)', 'Email', 'Gender*(Male/Female/Other)', 'FatherName*', 'FatherMobile*', 'FatherEmail', 'MotherName*', 'MotherMobile', 'Qualification*', 'Category', 'AadharNumber', 'Address*', 'City', 'District', 'State*', 'Pincode'],
        ['John', '', 'Doe', '2000-01-01', '9876543210', 'john@email.com', 'Male', 'Robert Doe', '9876543211', 'robert@email.com', 'Jane Doe', '9876543212', 'Graduate', 'GEN', '123456789012', '123 Main Street, Andheri West', 'Mumbai', 'Mumbai', 'Maharashtra', '400001'],
        ['Priya', 'Kumari', 'Sharma', '2001-05-15', '9876543213', 'priya@email.com', 'Female', 'Rajesh Sharma', '9876543214', 'rajesh@email.com', 'Sita Sharma', '9876543215', '12th Pass', 'OBC', '987654321098', '456 Park Avenue, Connaught Place', 'Delhi', 'New Delhi', 'Delhi', '110001']
    ];

    const ws = XLSX.utils.aoa_to_sheet(templateData);
    const wb = XLSX.utils.book_new();

    const colWidths = [
        { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 15 },
        { wch: 12 }, { wch: 20 }, { wch: 10 }, { wch: 15 },
        { wch: 12 }, { wch: 20 }, { wch: 15 }, { wch: 12 },
        { wch: 15 }, { wch: 10 }, { wch: 15 }, { wch: 25 },
        { wch: 12 }, { wch: 12 }, { wch: 15 }, { wch: 10 }
    ];
    ws['!cols'] = colWidths;

    XLSX.utils.book_append_sheet(wb, ws, "Student Template");
    XLSX.writeFile(wb, "student_bulk_template.xlsx");
    ShowNotification("success", "Template downloaded successfully!", "center");
}

// Save bulk registration
function saveBulkRegistration() {
    const instituteId = $('#BulkInstituteId').val();
    const program = $('#BulkProgram').val();
    const branch = $('#BulkBranch').val();
    const createBy = 'admin';

    if (!validateAcademicFilters()) {
        return;
    }

    const bulkData = [];
    let invalidRows = 0;

    $('#bulkPreviewTableBody tr').each(function () {
        const row = $(this);
        const statusBadge = row.find('.badge');

        if (statusBadge.hasClass('bg-danger')) {
            invalidRows++;
            return;
        }

        const cells = row.find('td');
        if (cells.length >= 23) {
            const student = {
                InstituteId: instituteId,
                SessionId: '',
                RegID: '',
                Program: program,
                Branch: branch,
                FirstName: cells.eq(1).text().trim() || '',
                MiddleName: cells.eq(2).text().trim() || '',
                LastName: cells.eq(3).text().trim() || '',
                Category: cells.eq(14).text().trim() || '',
                StudDOB: formatDateForServer(cells.eq(4).text()) || '',
                StudMobile: cells.eq(5).text().trim() || '',
                StudEmail: cells.eq(6).text().trim() || '',
                LstQualification: cells.eq(13).text().trim() || '',
                StudAadhar: cells.eq(15).text().trim() || '',
                StudPancard: '',
                Gender: cells.eq(7).text().trim() || '',
                FatherName: cells.eq(8).text().trim() || '',
                FatherMob: cells.eq(9).text().trim() || '',
                FatherEmail: cells.eq(10).text().trim() || '',
                FatherAadhar: '',
                MotherName: cells.eq(11).text().trim() || '',
                MotherMob: cells.eq(12).text().trim() || '',
                MotherEmail: '',
                MotherAadhar: '',
                RegDate: '', // Current date as registration date
                CurrAddress: cells.eq(16).text().trim() || '',
                City: cells.eq(17).text().trim() || '',
                District: cells.eq(18).text().trim() || '',
                State: cells.eq(19).text().trim() || '',
                Zipcode: cells.eq(20).text().trim() || '',
                CreateBy: createBy,
                CreateDate:''
            };
            bulkData.push(student);
        }
    });

    if (invalidRows > 0) {
        ShowNotification("primary", `Cannot proceed. ${invalidRows} invalid records found. Please validate all data first.`, "center");
        return;
    }

    if (bulkData.length === 0) {
        ShowNotification("primary", "No valid data to save", "center");
        return;
    }
    console.log("asas",bulkData)
    Swal.fire({
        title: 'Confirm Bulk Upload',
        text: `Are you sure you want to upload ${bulkData.length} student records?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, upload now!',
        cancelButtonText: 'No, cancel',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary me-2',
            cancelButton: 'btn btn-secondary'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            performBulkUpload(bulkData, instituteId, createBy);
        }
    });
}

function formatDateForServer(dateString) {
    if (!dateString) return '';
    try {
        // Handle Excel serial date numbers
        if (typeof dateString === 'number') {
            try {
                const date = XLSX.SSF.parse_date_code(dateString);
                const year = date.y;
                const month = String(date.m).padStart(2, '0');
                const day = String(date.d).padStart(2, '0');
                return `${year}-${month}-${day}`;
            } catch (e) {
                return dateString.toString();
            }
        }

        const date = new Date(dateString);
        if (isNaN(date.getTime())) return dateString.toString();

        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    } catch (e) {
        return dateString.toString();
    }
}



function performBulkUpload(bulkData, instituteId, createBy) {
    const $btn = $("#saveBulkUpload");
    $btn.addClass("pe-none").html(`
        <span class="spinner-border spinner-border-sm me-2" role="status"></span>
        Uploading ${bulkData.length} Records...
    `);

    const formData = {
        Action: 'BulkAdd',
        InstituteID: instituteId,
        CreateBy: createBy,
        CreateDate: new Date().toISOString(),
        BulkData: bulkData
    };

    console.log('Sending bulk data:', formData);

    new IMSClient().request('/Student/Registration', 'POST', formData, true)
        .then((res) => {
            if (res.statusCode === 200) {
                ShowNotification("success", res.message, "center");

                Swal.fire({
                    title: 'Bulk Upload Successful!',
                    text: res.message || 'Student records have been successfully uploaded and saved.',
                    icon: 'success',
                    showCancelButton: false,
                    confirmButtonText: 'OK',
                    buttonsStyling: false,
                }).then((result) => {
                    if (result.isConfirmed || result.dismiss === Swal.DismissReason.timer) {
                        resetBulkUpload();

                        setTimeout(() => {
                            $('#bulkUploadSection').addClass('d-none');
                            $('#registration_table_layout').removeClass('d-none');
                            fetchRegistration();
                        }, 3000);

                    }
                });

              
            
            } else {
                ShowNotification("danger", res.message, "center");
            }
        })
        .catch((err) => {
            console.error('Bulk upload error:', err);
            ShowNotification("danger", err.message || "Error during bulk upload", "center");
        })
        .finally(() => {
            $btn.removeClass("pe-none").html("SAVE BULK UPLOAD");
        });
}

// Reset bulk upload
function resetBulkUpload() {
    if (window.pond) {
        window.pond.removeFiles();
    }

    resetBulkPreview();

    $('#validateDataBtn').prop('disabled', true);
    $('#saveBulkUpload').prop('disabled', true);
    $('#clearBulkData').prop('disabled', true);
    $('#bulkErrors').hide();

    $('.upload-progress').hide();

    ShowNotification("info", "Bulk upload form reset", "center");
}

function resetBulkPreview() {
    $('#bulkPreviewTableBody').empty();
    $('#bulkPreviewTableBody').html(`
        <tr>
            <td colspan="23" class="text-center text-muted py-5">
                <i class="ti ti-file-upload fs-1 mb-3 d-block"></i>
                <h5>No Data Preview</h5>
                <p class="mb-0">Upload an Excel file to preview your data here</p>
            </td>
        </tr>
    `);

    $('#previewCount').text('0 records');
    $('#validCount').text('0 valid');
    $('#invalidCount').text('0 invalid');
    $('#validationProgress').css('width', '0%');
    $('#validationSummary').text('0/0 records valid (0%)');

    if ($.fn.DataTable.isDataTable('#bulkDataPreview')) {
        $('#bulkDataPreview').DataTable().destroy();
    }
}

// Store current Excel data globally
window.currentExcelData = null;