﻿let isPrintTcListLoading = false;
let printTcAutoSearchTimer = null;
let isReAdmitProcessing = false;
let printTcTableInstance = null;
let tcPrintPreviewModalInstance = null;
let currentPrintHtml = '';

$(function () {
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 500);

    injectTopActionButtons();
    bindPrintTcEvents();
    initPrintTcValidation();
    initPrintTcEmptyState();

    setTimeout(function () {
        triggerPrintTcAutoSearch();
    }, 900);
});

function injectTopActionButtons() {
    if ($('#printTcTopActions').length) return;

    const actionHtml = `
        <div id="printTcTopActions" class="d-flex flex-wrap align-items-center gap-2 mb-3">
            <button type="button"
                    id="btnPrintSelectedTcNso"
                    class="btn btn-primary btn-sm d-none d-inline-flex align-items-center gap-1">
                <i class="ph ph-printer"></i>
                <span>Print Selected</span>
            </button>

            <button type="button"
                    id="btnReAdmitSelectedTcNso"
                    class="btn btn-outline-success btn-sm d-none d-inline-flex align-items-center gap-1">
                <i class="ph ph-arrow-counter-clockwise"></i>
                <span>Re-Admit Selected</span>
            </button>
        </div>
    `;

    $('#table_layout').before(actionHtml);
}

function bindPrintTcEvents() {
    if ($('#BtnSave').length) {
        $('#BtnSave').closest('.col-md-2').remove();
    }

    $('#form_remarksEntry').off('submit').on('submit', function (e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        if (isPrintTcListLoading) return false;

        if ($(this).valid()) {
            fetchPrintTcList();
        }
        return false;
    });

    $('#form_remarksEntry').off('keydown.printenter').on('keydown.printenter', 'input, select', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            triggerPrintTcAutoSearch();
            return false;
        }
    });

    $('#refreshsubjectTable').off('click').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        resetPrintTcSearchArea();
        return false;
    });

    $('#SchoolID, #SessionId, #clsid, #SectionID, #Type')
        .off('change.printautosearch')
        .on('change.printautosearch', function () {
            triggerPrintTcAutoSearch();
        });

    $(document).off('change', '#selectAllPrintTc').on('change', '#selectAllPrintTc', function () {
        const isChecked = $(this).is(':checked');
        $('.print-tc-row-check').prop('checked', isChecked);
        syncPrintTcSelectAll();
        toggleTopActionButtons();
    });

    $(document).off('change', '.print-tc-row-check').on('change', '.print-tc-row-check', function () {
        syncPrintTcSelectAll();
        toggleTopActionButtons();
    });

    $(document).off('click', '#btnPrintSelectedTcNso').on('click', '#btnPrintSelectedTcNso', function (e) {
        e.preventDefault();
        e.stopPropagation();
        printSelectedTcRows();
        return false;
    });

    $(document).off('click', '#btnReAdmitSelectedTcNso').on('click', '#btnReAdmitSelectedTcNso', function (e) {
        e.preventDefault();
        e.stopPropagation();
        handleBulkReAdmit();
        return false;
    });

    $(document).off('click', '.btn-print-single').on('click', '.btn-print-single', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const studentId = ($(this).data('studentid') || '').toString().trim();
        const type = ($(this).data('type') || '').toString().toUpperCase().trim();

        openPrintTcReport(studentId, type);
        return false;
    });

    $(document).off('click', '.btn-re-admit-single').on('click', '.btn-re-admit-single', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const studentId = ($(this).data('studentid') || '').toString().trim();
        const studentName = ($(this).data('studentname') || '').toString().trim();
        const issueType = ($(this).data('type') || '').toString().toUpperCase().trim();

        if (!studentId) {
            notify("warning", "Student ID missing");
            return false;
        }

        openReAdmitConfirm(studentId, studentName, issueType);
        return false;
    });

    $(document).off('click', '#btnPrintPreviewDoc').on('click', '#btnPrintPreviewDoc', function (e) {
        e.preventDefault();
        e.stopPropagation();
        printTcPreviewContent();
        return false;
    });
}

function triggerPrintTcAutoSearch() {
    clearTimeout(printTcAutoSearchTimer);

    printTcAutoSearchTimer = setTimeout(function () {
        if ($("#form_remarksEntry").valid()) {
            fetchPrintTcList();
        }
    }, 350);
}

function initPrintTcValidation() {
    if ($("#form_remarksEntry").data('validator')) {
        $("#form_remarksEntry").removeData("validator");
        $("#form_remarksEntry").removeData("unobtrusiveValidation");
    }

    $("#form_remarksEntry").validate({
        ignore: [],
        rules: {
            SchoolID: { required: true }
        },
        messages: {
            SchoolID: "Please select Institute"
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback").insertAfter(element);
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        }
    });
}

function initPrintTcEmptyState() {
    $('#table_layout').html(`
        <div class="text-center py-5">
            <div class="mb-2">
                <span class="badge bg-primary-subtle text-primary border px-3 py-2">
                    <i class="ph ph-printer me-1"></i> Print TC / NSO
                </span>
            </div>
            <h5 class="text-muted fw-semibold mt-2">No Data Found</h5>
            <p class="text-muted mb-2">Select filters to load issued TC / NSO records</p>
            <div class="d-inline-flex align-items-center gap-2">
                <span class="badge bg-warning-subtle text-warning border px-3 py-2">
                    <i class="fas fa-lightbulb me-1"></i> Auto search enabled
                </span>
            </div>
        </div>
    `);

    $('#totalSubjects').text('0');
    $('#lastUpdated').text('Just now');
    toggleTopActionButtons();
}

async function fetchPrintTcList() {
    if (isPrintTcListLoading) return;

    const refreshBtn = $('#refreshsubjectTable');
    const oldHtml = refreshBtn.html();

    isPrintTcListLoading = true;
    refreshBtn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Refresh`);

    try {
        const parms = {
            Institute: $('#SchoolID').val() || '',
            Session: $('#SessionId').val() || '',
            Course: $('#clsid').val() || '',
            Branch: $('#SectionID').val() || '',
            Type: ($('#Type').val() || '').toString().toUpperCase(),
            mode: 'ReportNsoTc'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        let data = normalizeResultArray(res);

        data = dedupePrintTcRows(data);

        if (Array.isArray(data) && data.length > 0) {
            renderPrintTcTable(data);
            $('#totalSubjects').text(data.length);
            $('#lastUpdated').text(new Date().toLocaleTimeString());
        } else {
            initPrintTcEmptyState();
        }

    } catch (error) {
        console.error(error);
        initPrintTcEmptyState();
        notify("danger", "Something went wrong while loading list");
    } finally {
        isPrintTcListLoading = false;
        refreshBtn.prop('disabled', false).html(oldHtml);
    }
}

function dedupePrintTcRows(data) {
    if (!Array.isArray(data)) return [];

    const map = new Map();

    data.forEach(item => {
        const studentId = getValueByKeyContains(item, ['studentid'], '').toString().trim();
        const type = getValueByKeyContains(item, ['certificatetype', 'nsotctype', 'type'], '').toString().trim().toUpperCase();
        const createdDate = getValueByKeyContains(item, ['createddate', 'issuedate'], '');
        const key = `${studentId}|${type}`;

        if (!studentId) return;

        if (!map.has(key)) {
            map.set(key, item);
            return;
        }

        const oldItem = map.get(key);

        const oldDate = new Date(
            getValueByKeyContains(oldItem, ['createddate', 'issuedate'], '') || 0
        ).getTime();

        const newDate = new Date(createdDate || 0).getTime();

        if (newDate >= oldDate) {
            map.set(key, item);
        }
    });

    return Array.from(map.values());
}

function renderPrintTcTable(data) {
    const rows = [];

    data.forEach((item, index) => {
        const tcNo = getValueByKeyContains(item, ['id', 'nsotcno'], '');
        const sessionName = getValueByKeyContains(item, ['batch_name', 'session_name', 'session'], '');
        const instituteName = getValueByKeyContains(item, ['institutename'], '');
        const courseName = getValueByKeyContains(item, ['course_name'], '');
        const branchName = getValueByKeyContains(item, ['branch_name'], '');
        const studentId = getValueByKeyContains(item, ['studentid'], '');
        const studentName = getValueByKeyContains(item, ['studentname'], '');
        const fatherName = getValueByKeyContains(item, ['fathername'], '');
        const issueType = getValueByKeyContains(item, ['certificatetype', 'nsotctype', 'type'], '').toString().toUpperCase();
        const issueDate = formatDisplayDate(getValueByKeyContains(item, ['issuedate', 'printeddate', 'createddate'], ''));

        const typeBadge = issueType === 'NSO'
            ? `<span class="badge bg-info-subtle text-info border px-3 py-2">NSO</span>`
            : `<span class="badge bg-primary-subtle text-primary border px-3 py-2">TC</span>`;

        const rowCheckHtml = `
            <div class="form-check d-flex justify-content-center m-0">
                <input class="form-check-input print-tc-row-check"
                       type="checkbox"
                       value="${escapeHtml(studentId)}"
                       data-studentid="${escapeHtml(studentId)}"
                       data-studentname="${escapeHtml(studentName)}"
                       data-type="${escapeHtml(issueType)}">
            </div>
        `;

        const actionHtml = `
            <div class="d-flex justify-content-center align-items-center gap-1 flex-nowrap">
                <button type="button"
                        class="btn btn-outline-primary btn-sm btn-print-single d-inline-flex align-items-center gap-1 text-nowrap"
                        data-studentid="${escapeHtml(studentId)}"
                        data-type="${escapeHtml(issueType)}"
                        title="Print Record">
                    <i class="ph ph-printer"></i>
                    <span>Print</span>
                </button>

                <button type="button"
                        class="btn btn-outline-success btn-sm btn-re-admit-single d-inline-flex align-items-center gap-1 text-nowrap"
                        data-studentid="${escapeHtml(studentId)}"
                        data-studentname="${escapeHtml(studentName)}"
                        data-type="${escapeHtml(issueType)}"
                        title="Re-Admit Student">
                    <i class="ph ph-arrow-counter-clockwise"></i>
                    <span>Re-Admit</span>
                </button>
            </div>
        `;

        rows.push([
            `<span class="fw-semibold text-muted">${index + 1}</span>`,
            rowCheckHtml,
            `<span class="fw-semibold text-dark">${escapeHtml(tcNo || '-')}</span>`,
            `<span class="fw-semibold text-primary">${escapeHtml(studentId || '-')}</span>`,
            `<span class="fw-semibold">${escapeHtml(studentName || '-')}</span>`,
            `<span class="small text-muted">${escapeHtml(fatherName || '-')}</span>`,
            `<span class="badge bg-success-subtle text-success border px-3 py-2">${escapeHtml(courseName || '-')}</span>`,
            `<span class="badge bg-danger-subtle text-danger border px-3 py-2">${escapeHtml(branchName || '-')}</span>`,
            `<span class="badge bg-info-subtle text-info border px-3 py-2">${escapeHtml(sessionName || '-')}</span>`,
            `<span class="fw-medium">${escapeHtml(instituteName || '-')}</span>`,
            typeBadge,
            `<span class="small">${escapeHtml(issueDate || '-')}</span>`,
            actionHtml
        ]);
    });

    const tableHtml = `
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-header bg-transparent py-2 px-3 border-bottom">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <h6 class="mb-0 small fw-semibold text-dark d-inline-flex align-items-center gap-2">
                        <span class="badge bg-primary-subtle text-primary border px-2 py-2">
                            <i class="ph ph-list"></i>
                        </span>
                        <span>Issued TC / NSO List</span>
                    </h6>
                    <span class="badge bg-primary-subtle text-primary border px-3 py-2">
                        Total: ${data.length}
                    </span>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive app-scroll app-datatable-default project-table">
                    <table class="table table-sm table-bordered table-hover mb-0 align-middle" id="printTcNsoTable"></table>
                </div>
            </div>
        </div>
    `;

    $('#table_layout').html(tableHtml);

    if ($.fn.DataTable.isDataTable('#printTcNsoTable')) {
        $('#printTcNsoTable').DataTable().destroy();
        $('#printTcNsoTable').empty();
    }

    printTcTableInstance = $('#printTcNsoTable').DataTable({
        data: rows,
        paging: true,
        lengthChange: false,
        searching: false,
        ordering: false,
        info: true,
        autoWidth: false,
        responsive: false,
        scrollX: true,
        destroy: true,
        columns: [
            { title: '#', width: "60px", className: "align-middle text-center" },
            {
                title: `<div class="form-check d-flex justify-content-center m-0">
                            <input class="form-check-input" type="checkbox" id="selectAllPrintTc">
                        </div>`,
                width: "60px",
                className: "align-middle text-center"
            },
            { title: 'TC No', width: "130px", className: "align-middle" },
            { title: 'Student ID', width: "120px", className: "align-middle" },
            { title: 'Student Name', width: "220px", className: "align-middle" },
            { title: 'Father Name', width: "200px", className: "align-middle" },
            { title: 'Class', width: "100px", className: "align-middle text-center" },
            { title: 'Section', width: "100px", className: "align-middle text-center" },
            { title: 'Session', width: "120px", className: "align-middle text-center" },
            { title: 'Institute', width: "220px", className: "align-middle" },
            { title: 'Type', width: "90px", className: "align-middle text-center" },
            { title: 'Issue Date', width: "130px", className: "align-middle text-center" },
            { title: 'Action', width: "280px", className: "align-middle text-center" }
        ],
        headerCallback: function (thead) {
            $(thead).find('th').addClass('fw-semibold text-dark border-bottom py-3 px-3 small');
        },
        drawCallback: function () {
            syncPrintTcSelectAll();
            toggleTopActionButtons();
        }
    });
}

function syncPrintTcSelectAll() {
    const allRows = $('.print-tc-row-check');
    const checkedRows = $('.print-tc-row-check:checked');

    if (!allRows.length) {
        $('#selectAllPrintTc').prop('checked', false).prop('indeterminate', false);
        return;
    }

    if (checkedRows.length === 0) {
        $('#selectAllPrintTc').prop('checked', false).prop('indeterminate', false);
    } else if (checkedRows.length === allRows.length) {
        $('#selectAllPrintTc').prop('checked', true).prop('indeterminate', false);
    } else {
        $('#selectAllPrintTc').prop('checked', false).prop('indeterminate', true);
    }
}

function toggleTopActionButtons() {
    const selectedCount = $('.print-tc-row-check:checked').length;
    const printBtn = $('#btnPrintSelectedTcNso');
    const readmitBtn = $('#btnReAdmitSelectedTcNso');

    if (selectedCount > 0) {
        printBtn.removeClass('d-none');
        readmitBtn.removeClass('d-none');

        printBtn.find('span').text(`Print Selected (${selectedCount})`);
        readmitBtn.find('span').text(`Re-Admit Selected (${selectedCount})`);
    } else {
        printBtn.addClass('d-none');
        readmitBtn.addClass('d-none');

        printBtn.find('span').text('Print Selected');
        readmitBtn.find('span').text('Re-Admit Selected');
    }
}

function getSelectedPrintTcRows() {
    const selected = [];

    $('.print-tc-row-check:checked').each(function () {
        selected.push({
            studentId: ($(this).data('studentid') || '').toString().trim(),
            studentName: ($(this).data('studentname') || '').toString().trim(),
            type: ($(this).data('type') || '').toString().trim().toUpperCase()
        });
    });

    return selected;
}

async function openPrintTcReport(studentIds, type) {
    let ids = [];

    if (Array.isArray(studentIds)) {
        ids = studentIds
            .map(x => String(x || '').trim())
            .filter(Boolean);
    } else {
        const singleId = String(studentIds || '').trim();
        if (singleId) ids = [singleId];
    }

    ids = [...new Set(ids)];

    if (!ids.length) {
        notify("warning", "Student ID missing");
        return;
    }

    const tblStr = ids.join(';') + ';';

    const parms = {
        TblStr: tblStr,
        Session: $('#SessionId').val() || '',
        Institute: $('#SchoolID').val() || '',
        Course: $('#clsid').val() || '',
        Branch: $('#SectionID').val() || '',
        Type: (type || $('#Type').val() || '').toString().toUpperCase(),
        mode: 'RDLCReportNsoTc'
    };

    try {
        notify("info", ids.length > 1 ? "Loading multiple print preview..." : "Loading print preview...");
        const res = await new IMSClient().request('/student/PrintTcNso', 'POST', parms, true, 'html');

        const html = extractHtmlResponse(res);
        if (!html) {
            notify("danger", "Empty print response");
            return;
        }

        showTcPrintPreview(html);

    } catch (error) {
        console.error(error);
        notify("danger", "Failed to load print preview");
    }
}

async function printSelectedTcRows() {
    const selectedRows = getSelectedPrintTcRows();

    if (!selectedRows.length) {
        notify("warning", "Please select at least one record");
        return;
    }

    const uniqueIds = [...new Set(
        selectedRows
            .map(x => x.studentId)
            .filter(Boolean)
    )];

    const uniqueTypes = [...new Set(
        selectedRows
            .map(x => x.type)
            .filter(Boolean)
    )];

    const finalType = uniqueTypes.length === 1
        ? uniqueTypes[0]
        : ($('#Type').val() || '').toString().toUpperCase();

    await openPrintTcReport(uniqueIds, finalType);
}

function extractHtmlResponse(res) {
    if (!res) return '';

    if (typeof res === 'string' && looksLikeHtml(res)) return res;
    if (typeof res?.result === 'string' && looksLikeHtml(res.result)) return res.result;
    if (typeof res?.Result === 'string' && looksLikeHtml(res.Result)) return res.Result;
    if (typeof res?.data === 'string' && looksLikeHtml(res.data)) return res.data;
    if (typeof res?.Data === 'string' && looksLikeHtml(res.Data)) return res.Data;
    if (typeof res?.d === 'string' && looksLikeHtml(res.d)) return res.d;

    return '';
}

function ensurePrintPreviewModal() {
    const modalEl = document.getElementById('tcPrintPreviewModal');
    if (!modalEl) return null;

    if (!tcPrintPreviewModalInstance) {
        tcPrintPreviewModalInstance = new bootstrap.Modal(modalEl, {
            backdrop: 'static',
            keyboard: true
        });
    }

    return tcPrintPreviewModalInstance;
}

function showTcPrintPreview(html) {
    currentPrintHtml = html || '';

    const modal = ensurePrintPreviewModal();
    if (!modal) {
        notify("danger", "Print preview modal not found");
        return;
    }

    $('#tcPrintPreviewContainer').html(`
        <div class="bg-white p-2">
            <div id="tcPrintableArea" class="tc-printable-area">
                ${currentPrintHtml}
            </div>
        </div>
    `);

    modal.show();
}

function printTcPreviewContent() {
    const printable = document.getElementById('tcPrintableArea');

    if (!printable) {
        notify("warning", "Nothing to print");
        return;
    }

    const printWindow = window.open('', '_blank', 'width=1200,height=900');

    if (!printWindow) {
        notify("warning", "Popup blocked. Please allow popups.");
        return;
    }

    const htmlToPrint = printable.innerHTML;

    printWindow.document.open();
    printWindow.document.write(`
        <!doctype html>
        <html>
        <head>
            <title>TC / NSO Print</title>
            <meta charset="utf-8" />
        </head>
        <body>
            ${htmlToPrint}
        </body>
        </html>
    `);
    printWindow.document.close();

    printWindow.focus();

    setTimeout(function () {
        try {
            printWindow.print();
        } catch (e) {
            console.error(e);
        }
    }, 600);
}

async function handleBulkReAdmit() {
    const selectedRows = getSelectedPrintTcRows();

    if (!selectedRows.length) {
        notify("warning", "Please select at least one record");
        return;
    }

    const namesPreview = selectedRows
        .slice(0, 3)
        .map(x => x.studentName || x.studentId)
        .join(', ');

    const result = await Swal.fire({
        title: 'Confirm Re-Admit',
        html: `
            <div class="text-start">
                <div class="mb-2">
                    <strong>${selectedRows.length}</strong> selected record(s) will be re-admitted.
                </div>
                <div class="small text-muted mb-3">${escapeHtml(namesPreview)}${selectedRows.length > 3 ? ' ...' : ''}</div>
                <label class="form-label fw-semibold mb-1">Remark <span class="text-danger">*</span></label>
                <textarea id="swalReAdmitRemark"
                          class="swal2-textarea"
                          placeholder="Enter re-admit remark"
                          style="display:flex; width:100%; min-height:90px; margin:0;"></textarea>
            </div>
        `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Re-Admit',
        cancelButtonText: 'Cancel',
        focusConfirm: false,
        preConfirm: () => {
            const remark = ($('#swalReAdmitRemark').val() || '').trim();
            if (!remark) {
                Swal.showValidationMessage('Please enter remark');
                return false;
            }
            return { remark };
        }
    });

    if (!result.isConfirmed) return;

    const remark = result.value.remark || '';
    await processBulkReAdmit(selectedRows, remark);
}

function openReAdmitConfirm(studentId, studentName, issueType) {
    Swal.fire({
        title: 'Confirm Re-Admit',
        html: `
            <div class="text-start">
                <div class="mb-2"><strong>Student ID:</strong> ${escapeHtml(studentId)}</div>
                <div class="mb-2"><strong>Student Name:</strong> ${escapeHtml(studentName || '-')}</div>
                <div class="mb-3"><strong>Type:</strong> ${escapeHtml(issueType || '-')}</div>

                <label class="form-label fw-semibold mb-1">Remark <span class="text-danger">*</span></label>
                <textarea id="swalReAdmitRemark"
                          class="swal2-textarea"
                          placeholder="Enter re-admit remark"
                          style="display:flex; width:100%; min-height:90px; margin:0;"></textarea>
            </div>
        `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Re-Admit',
        cancelButtonText: 'Cancel',
        focusConfirm: false,
        preConfirm: () => {
            const remark = ($('#swalReAdmitRemark').val() || '').trim();
            if (!remark) {
                Swal.showValidationMessage('Please enter remark');
                return false;
            }
            return { remark };
        }
    }).then(async (result) => {
        if (!result.isConfirmed) return;

        const remark = result.value.remark || '';
        await processSingleReAdmit(studentId, issueType, remark);
    });
}

async function processSingleReAdmit(studentId, issueType, remark) {
    if (!studentId || isReAdmitProcessing) return;

    isReAdmitProcessing = true;

    try {
        const parms = {
            StudentID: studentId,
            Status: 'Active',
            Remark: remark,
            Type: (issueType || '').toString().toUpperCase(),
            CUser: $('#hfUserId').val() || $('#hdnUserID').val() || $('#UserID').val() || '',
            mode: 'StudentSufflingUpdate'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const msg = res.message || res.Message || 'Student re-admitted successfully';

        notify("success", msg);

        setTimeout(function () {
            fetchPrintTcList();
        }, 300);

    } catch (error) {
        console.error(error);
        notify("danger", "Failed to re-admit student");
    } finally {
        isReAdmitProcessing = false;
    }
}

async function processBulkReAdmit(rows, remark) {
    if (!Array.isArray(rows) || !rows.length || isReAdmitProcessing) return;

    isReAdmitProcessing = true;

    let successCount = 0;
    let failCount = 0;

    try {
        for (const row of rows) {
            try {
                const parms = {
                    StudentID: row.studentId,
                    Status: 'Active',
                    Remark: remark,
                    Type: (row.type || '').toString().toUpperCase(),
                    CUser: $('#hfUserId').val() || $('#hdnUserID').val() || $('#UserID').val() || '',
                    mode: 'StudentSufflingUpdate'
                };

                await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
                successCount++;
            } catch (innerError) {
                console.error(innerError);
                failCount++;
            }
        }

        if (successCount > 0 && failCount === 0) {
            notify("success", `${successCount} student(s) re-admitted successfully`);
        } else if (successCount > 0 && failCount > 0) {
            notify("warning", `${successCount} success, ${failCount} failed`);
        } else {
            notify("danger", "All re-admit requests failed");
        }

        setTimeout(function () {
            fetchPrintTcList();
        }, 400);

    } finally {
        isReAdmitProcessing = false;
    }
}

function resetPrintTcSearchArea() {
    if ($('#form_remarksEntry').length) {
        $('#form_remarksEntry')[0].reset();
    }

    if ($("#form_remarksEntry").data('validator')) {
        $("#form_remarksEntry").validate().resetForm();
        $('#form_remarksEntry').find('.is-invalid, .is-valid').removeClass('is-invalid is-valid');
    }

    initPrintTcEmptyState();

    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 300);

    setTimeout(function () {
        triggerPrintTcAutoSearch();
    }, 700);
}

function normalizeResultArray(res) {
    if (!res) return [];
    if (Array.isArray(res)) return res;
    if (Array.isArray(res.result)) return res.result;
    if (Array.isArray(res.Result)) return res.Result;
    if (Array.isArray(res.data)) return res.data;
    if (Array.isArray(res.Data)) return res.Data;
    if (Array.isArray(res.d)) return res.d;

    if (typeof res.d === 'string') {
        try {
            const parsed = JSON.parse(res.d);
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) { }
    }

    return [];
}

function looksLikeHtml(str) {
    const v = String(str || '').trim();
    return /^<(!doctype|html|div|table|section|article|style|body)/i.test(v);
}

function getValueByKeyContains(obj, keys, defaultValue = '') {
    if (!obj || typeof obj !== 'object') return defaultValue;

    const objKeys = Object.keys(obj);
    if (!objKeys.length) return defaultValue;

    const normalize = (v) => String(v || '').replace(/[\s_\-]/g, '').toLowerCase();

    const normalizedObjKeys = objKeys.map(k => ({
        original: k,
        normalized: normalize(k)
    }));

    const normalizedWanted = (keys || []).map(k => normalize(k));

    for (const wanted of normalizedWanted) {
        const found = normalizedObjKeys.find(x => x.normalized === wanted);
        if (found) {
            const val = obj[found.original];
            if (val !== undefined && val !== null && String(val).trim() !== '') {
                return val;
            }
        }
    }

    for (const wanted of normalizedWanted) {
        const found = normalizedObjKeys.find(x =>
            x.normalized.includes(wanted) || wanted.includes(x.normalized)
        );
        if (found) {
            const val = obj[found.original];
            if (val !== undefined && val !== null && String(val).trim() !== '') {
                return val;
            }
        }
    }

    return defaultValue;
}

function formatDisplayDate(value) {
    const str = String(value || '').trim();
    if (!str) return '';

    const dt = new Date(str);
    if (!isNaN(dt.getTime())) {
        const dd = String(dt.getDate()).padStart(2, '0');
        const mm = dt.toLocaleString('en-GB', { month: 'short' });
        const yyyy = dt.getFullYear();
        return `${dd} ${mm} ${yyyy}`;
    }

    return str;
}

function notify(type, message) {
    if (typeof ShowNotification === 'function') {
        ShowNotification(type, message, "center");
    } else {
        console.log(type + ': ' + message);
    }
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}