﻿let issueCertificateModalInstance = null;
let historyModalInstance = null;
let selectedStudentMeta = null;
let currentCertificateQuestionList = [];
let currentStudentAutoData = null;
let isIssueListLoading = false;
let isIssueSaving = false;
let issueStudentTableInstance = null;

const SUPPORTED_CERTIFICATE_TYPES = ['CHARACTER', 'PROVISIONAL', 'MIGRATION', 'DMC', 'BONAFIDE'];
const CERTIFICATE_TYPES_WITH_QUESTIONS = ['CHARACTER', 'PROVISIONAL', 'MIGRATION', 'DMC'];

$(function () {
    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 500);

    bindCertificateEvents();
    initIssueSearchValidation();
    initIssueValidation();
    initIssueEmptyState();
    setTodayDate();
    setLastUpdated();

    $('#issueCertificateModal').on('hidden.bs.modal', function () {
        resetIssueForm();
    });
});

function bindCertificateEvents() {
    $('#btnSearchIssue').off('click').on('click', function (e) {
        e.preventDefault();
        $('#form_issueCertificate').trigger('submit');
        return false;
    });

    $('#form_issueCertificate').off('submit').on('submit', function (e) {
        e.preventDefault();
        if (isIssueListLoading) return false;
        if ($(this).valid()) {
            fetchIssueStudentList();
        }
        return false;
    });

    $('#btnRefreshAll').off('click').on('click', function (e) {
        e.preventDefault();
        resetAllFilters();
        return false;
    });

    $(document).off('click', '.btn-issue-certificate').on('click', '.btn-issue-certificate', async function (e) {
        e.preventDefault();

        const $btn = $(this);
        const selectedType = getSelectedIssueType();

        if (!selectedType) {
            ShowNotification("warning", "Please select Certificate Type first", "center");
            return false;
        }

        const issuedTypesRaw = String($btn.data('issuedtypes') || '').toUpperCase();
        const issuedTypes = issuedTypesRaw.split(',').map(x => x.trim()).filter(Boolean);

        const meta = {
            studentId: $btn.data('studentid') || '',
            institute: $btn.data('institute') || '',
            session: $btn.data('session') || '',
            course: $btn.data('course') || '',
            branch: $btn.data('branch') || '',
            photo: $btn.data('photo') || '',
            studentName: $btn.data('studentname') || '',
            fatherName: $btn.data('fathername') || '',
            motherName: $btn.data('mothername') || '',
            className: $btn.data('classname') || '',
            branchName: $btn.data('branchname') || '',
            sessionName: $btn.data('sessionname') || '',
            instituteName: $btn.data('institutename') || '',
            admissionNo: $btn.data('admissionno') || '',
            balance: $btn.data('balance') || '',
            certificateType: selectedType,
            issuedTypes: issuedTypes
        };

        await openIssueModal(meta);
        return false;
    });

    $('#btnSaveCertificate').off('click').on('click', function (e) {
        e.preventDefault();
        if (isIssueSaving) return false;
        saveCertificate();
        return false;
    });

    $(document).off('click', '.btn-view-certificate-history').on('click', '.btn-view-certificate-history', async function (e) {
        e.preventDefault();

        const $btn = $(this);

        const meta = {
            studentId: $btn.data('studentid') || '',
            institute: $btn.data('institute') || '',
            session: $btn.data('session') || '',
            course: $btn.data('course') || '',
            branch: $btn.data('branch') || '',
            studentName: $btn.data('studentname') || ''
        };

        await openCertificateHistory(meta);
        return false;
    });
}

function initIssueSearchValidation() {
    const $form = $("#form_issueCertificate");

    if (!$form.length) return;

    if ($form.data('validator')) {
        $form.removeData("validator");
        $form.removeData("unobtrusiveValidation");
    }

    $form.validate({
        ignore: [],
        rules: {
            IssueSchoolID: { required: true },
            IssueSessionId: { required: true },
            CertificateType: { required: true }
        },
        messages: {
            IssueSchoolID: "Please select Institute",
            IssueSessionId: "Please select Session",
            CertificateType: "Please select Certificate Type"
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            if (element.parent('.input-group').length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass('is-invalid').removeClass('is-valid');
        },
        unhighlight: function (element) {
            $(element).removeClass('is-invalid').addClass('is-valid');
        }
    });
}

function initIssueValidation() {
    const $form = $("#formIssueCertificate");

    if (!$form.length) return;

    if ($form.data('validator')) {
        $form.removeData("validator");
        $form.removeData("unobtrusiveValidation");
    }

    $form.validate({
        ignore: [],
        rules: {
            Date: { required: true },
            Remark: { required: true }
        },
        messages: {
            Date: "Please select Issue Date",
            Remark: "Please enter Issue Remark"
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            if (element.parent('.input-group').length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass('is-invalid').removeClass('is-valid');
        },
        unhighlight: function (element) {
            $(element).removeClass('is-invalid').addClass('is-valid');
        }
    });
}

function getSelectedIssueType() {
    return ($('#IssueCertificateType').val() || $('#CertificateType').val() || '').trim().toUpperCase();
}

function isSupportedCertificateType(type) {
    return SUPPORTED_CERTIFICATE_TYPES.includes(String(type || '').trim().toUpperCase());
}

function shouldLoadDynamicQuestions(type) {
    const t = String(type || '').trim().toUpperCase();
    return CERTIFICATE_TYPES_WITH_QUESTIONS.includes(t);
}

function formatCertificateType(type) {
    const t = String(type || '').trim().toUpperCase();
    switch (t) {
        case 'CHARACTER': return 'Character';
        case 'PROVISIONAL': return 'Provisional';
        case 'MIGRATION': return 'Migration';
        case 'DMC': return 'DMC';
        case 'BONAFIDE': return 'Bonafide';
        default: return t || '-';
    }
}

function setTodayDate() {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    $('#IssueDate').val(`${yyyy}-${mm}-${dd}`);
}

function setLastUpdated() {
    $('#lastUpdated').text(new Date().toLocaleTimeString());
}

function initIssueEmptyState() {
    $('#issueTableLayout').html(`
        <div class="text-center py-5">
            <i class="fas fa-user-graduate fa-3x text-muted opacity-25"></i>
            <h6 class="text-muted fw-semibold mt-2">No Pending Students</h6>
            <p class="text-muted mb-0 small">
                Select institute, session and certificate type to load pending records.
            </p>
        </div>
    `);
    $('#totalIssueEntries').text('0');
}

async function fetchIssueStudentList() {
    if (isIssueListLoading) return;

    const institute = $('#IssueSchoolID').val() || '';
    const session = $('#IssueSessionId').val() || '';
    const selectedType = getSelectedIssueType();

    if (!institute) {
        ShowNotification("warning", "Please select Institute", "center");
        return;
    }

    if (!session) {
        ShowNotification("warning", "Please select Session", "center");
        return;
    }

    if (!selectedType) {
        ShowNotification("warning", "Please select Certificate Type", "center");
        return;
    }

    const $form = $('#form_issueCertificate');
    if ($form.length && !$form.valid()) return;

    if (!isSupportedCertificateType(selectedType)) {
        ShowNotification("warning", "Please select valid Certificate Type", "center");
        return;
    }

    const btn = $('#btnSearchIssue');
    const oldHtml = btn.html();

    isIssueListLoading = true;
    btn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Searching...`);

    try {
        const parms = {
            Institute: institute,
            Session: session,
            Course: $('#IssueCourseId').val() || '',
            Branch: $('#IssueBranchId').val() || '',
            Status: $('#IssueStatus').val() || '',
            txtSearch: $('#txtSearchIssue').val() || '',
            Type: selectedType,
            mode: 'CertStudentDetail'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const data = normalizeResultArray(res);

        if (Array.isArray(data) && data.length > 0) {
            renderIssueStudentTable(data);
            $('#totalIssueEntries').text(data.length);
            setLastUpdated();
        } else {
            initIssueEmptyState();
        }
    } catch (error) {
        console.error(error);
        initIssueEmptyState();
        ShowNotification("danger", "Unable to load pending students", "center");
    } finally {
        isIssueListLoading = false;
        btn.prop('disabled', false).html(oldHtml);
    }
}
function renderIssueStudentTable(data) {
    const rows = data.map((item, index) => {
        const admissionNo = getValueByKeyContains(item, ['admissionno', 'admno'], '');
        const regNo = getValueByKeyContains(item, ['adm_regno', 'regno', 'registrationno'], '') || '-';
        const rollNo = getValueByKeyContains(item, ['adm_rollno', 'rollno'], '') || '-';

        const rawStudentName = getValueByKeyContains(item, ['studentname', 'sname'], '');
        const studentName = rawStudentName && String(rawStudentName).trim() !== '' ? rawStudentName : admissionNo;

        const rawStudentId = getValueByKeyContains(item, ['studentid', 'stu_id'], '');
        const studentId = rawStudentId && String(rawStudentId).trim() !== '' ? rawStudentId : admissionNo;

        const fatherName = getValueByKeyContains(item, ['fathername'], '') || '-';
        const motherName = getValueByKeyContains(item, ['mothername'], '') || '-';
        const courseName = getValueByKeyContains(item, ['course_name'], '') || '-';
        const branchName = getValueByKeyContains(item, ['branch_name'], '') || '-';

        const batchName = getValueByKeyContains(item, ['batch_name', 'session_name'], '');
        const sessionIdValue = getValueByKeyContains(item, ['session_id', 'session'], '');
        const sessionName = batchName && String(batchName).trim() !== '' ? batchName : (sessionIdValue || '-');

        const instituteName = getValueByKeyContains(item, ['institutename'], '') || '-';
        const instituteId = getValueByKeyContains(item, ['institute_id', 'institute'], '') || '';
        const sessionId = sessionIdValue || '';
        const courseId = getValueByKeyContains(item, ['course_id', 'course'], '') || '';
        const branchId = getValueByKeyContains(item, ['branch_id', 'branch'], '') || '';
        const status = getValueByKeyContains(item, ['admissionstatus'], '') || '-';
        const balance = parseFloat(getValueByKeyContains(item, ['balance'], 0) || 0);
        const studentPhoto = getValueByKeyContains(item, ['picture'], '') || '';
        const issuedList = String(getValueByKeyContains(item, ['issuedcertificatelist'], '') || '');
        const totalIssued = parseInt(getValueByKeyContains(item, ['totalissuedcertificates'], '0') || 0, 10);

        const balanceHtml = balance <= 0
            ? `<span class="badge bg-success-subtle text-success-emphasis border border-success-subtle rounded-pill"><i class="ti ti-circle-check me-1"></i>Clear</span>`
            : `<span class="badge bg-danger-subtle text-danger-emphasis border border-danger-subtle rounded-pill"><i class="ti ti-receipt-2 me-1"></i>₹${escapeHtml(balance.toString())}</span>`;

        const issuedBadge = issuedList
            ? `<span class="badge bg-info-subtle text-info-emphasis border border-info-subtle rounded-pill"><i class="ti ti-file-certificate me-1"></i>${escapeHtml(issuedList)}</span>`
            : `<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle rounded-pill"><i class="ti ti-minus me-1"></i>None</span>`;

        const statusHtml = `
            <span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle rounded-pill">
                <i class="ti ti-user-check me-1"></i>${escapeHtml(status)}
            </span>
        `;

        const totalIssuedHtml = `
            <span class="badge bg-success-subtle text-success-emphasis border border-success-subtle rounded-pill">
                <i class="ti ti-list-check me-1"></i>${escapeHtml(String(totalIssued))}
            </span>
        `;

        const hasHistory = totalIssued > 0;

        const historyBtnHtml = hasHistory
            ? `
                <button type="button"
                        class="btn btn-outline-secondary btn-sm btn-view-certificate-history px-2"
                        data-studentid="${escapeHtml(studentId)}"
                        data-institute="${escapeHtml(instituteId)}"
                        data-session="${escapeHtml(sessionId)}"
                        data-course="${escapeHtml(courseId)}"
                        data-branch="${escapeHtml(branchId)}"
                        data-studentname="${escapeHtml(studentName)}"
                        title="View History">
                    <i class="ti ti-history"></i>
                </button>
              `
            : '';

        const actionHtml = `
            <div class="d-flex align-items-center justify-content-center gap-1 flex-nowrap">
                <button type="button"
                        class="btn btn-outline-primary btn-sm btn-issue-certificate px-2"
                        data-studentid="${escapeHtml(studentId)}"
                        data-institute="${escapeHtml(instituteId)}"
                        data-session="${escapeHtml(sessionId)}"
                        data-course="${escapeHtml(courseId)}"
                        data-branch="${escapeHtml(branchId)}"
                        data-photo="${escapeHtml(studentPhoto)}"
                        data-studentname="${escapeHtml(studentName)}"
                        data-fathername="${escapeHtml(fatherName)}"
                        data-mothername="${escapeHtml(motherName)}"
                        data-classname="${escapeHtml(courseName)}"
                        data-branchname="${escapeHtml(branchName)}"
                        data-sessionname="${escapeHtml(sessionName)}"
                        data-institutename="${escapeHtml(instituteName)}"
                        data-admissionno="${escapeHtml(admissionNo)}"
                        data-balance="${escapeHtml(balance.toString())}"
                        data-issuedtypes="${escapeHtml(issuedList)}"
                        title="Issue Certificate">
                    <i class="ti ti-file-certificate"></i>
                </button>
                ${historyBtnHtml}
            </div>
        `;

        return [
            `<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle rounded-pill">${index + 1}</span>`,
            `<span class="fw-semibold text-dark">${escapeHtml(admissionNo || '-')}</span>`,
            `<span class="text-dark">${escapeHtml(regNo)}</span>`,
            `<span class="text-dark">${escapeHtml(rollNo)}</span>`,
            `<div class="fw-semibold text-dark">${escapeHtml(studentName || '-')}</div>`,
            `<div class="text-dark">${escapeHtml(fatherName)}</div>`,
            `<span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle rounded-pill"><i class="ti ti-school me-1"></i>${escapeHtml(courseName)}</span>`,
            `<span class="badge bg-success-subtle text-success-emphasis border border-success-subtle rounded-pill"><i class="ti ti-layout-grid me-1"></i>${escapeHtml(branchName)}</span>`,
            `<span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle rounded-pill"><i class="ti ti-calendar-time me-1"></i>${escapeHtml(sessionName)}</span>`,
            statusHtml,
            balanceHtml,
            issuedBadge,
            totalIssuedHtml,
            actionHtml
        ];
    });

    $('#issueTableLayout').html(`
        <div class="table-responsive">
            <table class="table table-bordered table-sm table-hover mb-0 align-middle" id="issueStudentTable"></table>
        </div>
    `);

    if ($.fn.DataTable.isDataTable('#issueStudentTable')) {
        $('#issueStudentTable').DataTable().destroy();
        $('#issueStudentTable').empty();
    }

    issueStudentTableInstance = $('#issueStudentTable').DataTable({
        data: rows,
        paging: true,
        lengthChange: false,
        searching: false,
        ordering: false,
        info: true,
        autoWidth: false,
        scrollX: true,
        destroy: true,
        pageLength: 10,
        columnDefs: [
            { targets: -1, className: 'text-center', width: '90px' }
        ],
        columns: [
            { title: 'Sr No' },
            { title: 'Adm No' },
            { title: 'Reg No' },
            { title: 'Roll No' },
            { title: 'Student Name' },
            { title: 'Father Name' },
            { title: 'Class' },
            { title: 'Section' },
            { title: 'Session' },
            { title: 'Status' },
            { title: 'Balance' },
            { title: 'Issued Types' },
            { title: 'Total' },
            { title: 'Action' }
        ]
    });
}

async function openIssueModal(meta) {
    try {
        resetIssueForm();
        selectedStudentMeta = meta;

        const selectedType = String(meta.certificateType || '').trim().toUpperCase();

        $('#ModalInstitute').val(meta.institute || '');
        $('#ModalSession').val(meta.session || '');
        $('#ModalCourse').val(meta.course || '');
        $('#ModalBranch').val(meta.branch || '');
        $('#ModalStudentID').val(meta.studentId || '');
        $('#ModalCertificateType').val(selectedType);

        $('#selectedCertificateBadge').html(`<i class="ti ti-file-certificate me-1"></i> Certificate Type: ${formatCertificateType(selectedType)}`);
        $('#printCountBadge').html(`<i class="ti ti-printer me-1"></i> Print Count: 0`);

        fillIssueStudentCard(meta);

        const modalEl = document.getElementById('issueCertificateModal');
        if (!modalEl) {
            ShowNotification("warning", "Issue popup not available on page", "center");
            return;
        }

        if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
            ShowNotification("danger", "Bootstrap modal is not loaded properly", "center");
            return;
        }

        issueCertificateModalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
        issueCertificateModalInstance.show();

        await loadStudentAutoData(meta);

        if (selectedType && shouldLoadDynamicQuestions(selectedType)) {
            $('#dynamicQuestionCard').show();
            $('#dynamicQuestionContainer').html(`
                <div class="text-center py-3">
                    <div class="spinner-border spinner-border-sm text-primary me-2"></div>
                    Loading questions...
                </div>
            `);

            await loadCertificateQuestionsForIssue(meta, selectedType);
        } else {
            currentCertificateQuestionList = [];
            $('#dynamicQuestionCard').hide();
            $('#dynamicQuestionContainer').html(`
                <div class="text-center py-3 text-muted small">No extra questions.</div>
            `);
        }
    } catch (error) {
        console.error(error);
        ShowNotification("danger", "Unable to load student details", "center");
    }
}

function fillIssueStudentCard(meta) {
    $('#DisplayStudentNameText').text(meta.studentName || '-');
    $('#DisplayAdmissionNoText').text(meta.admissionNo || '-');
    $('#DisplayFatherNameText').text(meta.fatherName || '-');
    $('#DisplayMotherNameText').text(meta.motherName || '-');
    $('#DisplayDobText').text('-');
    $('#DisplayClassText').text(meta.className || '-');
    $('#DisplayBranchText').text(meta.branchName || '-');
    $('#DisplaySessionText').text(meta.sessionName || '-');
    $('#DisplayInstituteText').text(meta.instituteName || '-');
    $('#DisplayStudentIdText').text(meta.studentId || '-');
    $('#DisplayCategoryText').text('-');
    $('#DisplayCategoryFlagText').text('-');
    $('#DisplayDuesText').text('-');
    $('#DisplayRelaxationText').text('-');
    $('#DisplaySchoolNoText').text('-');
    $('#DisplayAffiliationNoText').text('-');
    $('#DisplayRenewedText').text('-');
    $('#DisplayRegistrationNoText').text('-');
    $('#DisplaySerialNoText').text('-');
    setStudentPhotoSafe(meta.photo || '');
} function fillIssueStudentCard(meta) {
    $('#DisplayStudentNameText').text(meta.studentName || '-');
    $('#DisplayAdmissionNoText').text(meta.admissionNo || '-');
    $('#DisplayFatherNameText').text(meta.fatherName || '-');
    $('#DisplayMotherNameText').text(meta.motherName || '-');

    $('#DisplayDobText').text('-');
    $('#DisplayClassText').text(meta.className || '-');
    $('#DisplayBranchText').text(meta.branchName || '-');
    $('#DisplaySessionText').text(meta.sessionName || '-');
    $('#DisplayInstituteText').text(meta.instituteName || '-');
    $('#DisplayStudentIdText').text(meta.studentId || '-');
    $('#DisplayCategoryText').text('-');
    $('#DisplayCategoryFlagText').text('-');
    $('#DisplayDuesText').text('-');
    $('#DisplayRelaxationText').text('-');
    $('#DisplaySchoolNoText').text('-');
    $('#DisplayAffiliationNoText').text('-');
    $('#DisplayRenewedText').text('-');
    $('#DisplayRegistrationNoText').text('-');
    $('#DisplaySerialNoText').text('-');

    $('#DisplayDobText').closest('.col-xl-3, .col-md-4, .col-6').hide();
    $('#DisplayCategoryText').closest('.col-xl-3, .col-md-4, .col-6').hide();
    $('#DisplayRegistrationNoText').closest('.col-xl-3, .col-md-4, .col-6').hide();
    $('#DisplayCategoryFlagText').closest('.col-xl-2, .col-lg-3, .col-md-4, .col-6').hide();
    $('#DisplayDuesText').closest('.col-xl-2, .col-lg-3, .col-md-4, .col-6').hide();
    $('#DisplayRelaxationText').closest('.col-xl-2, .col-lg-3, .col-md-4, .col-6').hide();
    $('#DisplaySerialNoText').closest('.col-xl-2, .col-lg-3, .col-md-4, .col-6').hide();
    $('#DisplaySchoolNoText').closest('.col-xl-2, .col-lg-3, .col-md-4, .col-6').hide();
    $('#DisplayAffiliationNoText').closest('.col-xl-2, .col-lg-3, .col-md-4, .col-6').hide();
    $('#DisplayRenewedText').closest('.col-xl-6, .col-lg-6, .col-md-8, .col-12').hide();

    $('#DisplayClassText').closest('.col-xl-3, .col-md-4, .col-6').show();
    $('#DisplayBranchText').closest('.col-xl-3, .col-md-4, .col-6').show();
    $('#DisplaySessionText').closest('.col-xl-3, .col-md-4, .col-6').show();
    $('#DisplayStudentIdText').closest('.col-xl-3, .col-md-4, .col-6').show();
    $('#DisplayInstituteText').closest('.col-xl-3, .col-md-4, .col-6').show();

    setStudentPhotoSafe(meta.photo || '');
}
async function loadStudentAutoData(meta) {
    currentStudentAutoData = null;

    try {
        const parms = {
            StudID: meta.studentId || meta.admissionNo || '',
            StudentID: meta.studentId || meta.admissionNo || '',
            Institute: $('#IssueSchoolID').val() || meta.institute || '',
            Batch: $('#IssueSessionId').val() || meta.session || '',
            Session: $('#IssueSessionId').val() || meta.session || '',
            Course: $('#IssueCourseId').val() || meta.course || '',
            Branch: $('#IssueBranchId').val() || meta.branch || '',
            mode: 'GetStudentSearchForTC'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const data = normalizeResultArray(res);

        if (Array.isArray(data) && data.length > 0) {
            currentStudentAutoData = data[0];
            applyStudentAutoData(currentStudentAutoData, meta);
        }
    } catch (error) {
        console.error(error);
    }
}

function applyStudentAutoData(data, meta) {
    const setText = (selector, value, fallback = '-') => {
        const finalVal = (value !== undefined && value !== null && String(value).trim() !== '') ? value : fallback;
        $(selector).text(finalVal);
    };

    const toggleField = (selector, value, fallback = '') => {
        const $el = $(selector);
        const $box = $el.closest('.col-xl-3, .col-xl-2, .col-lg-3, .col-lg-6, .col-md-4, .col-md-8, .col-md-6, .col-6, .col-12');
        const finalVal = (value !== undefined && value !== null && String(value).trim() !== '') ? value : fallback;

        if (finalVal && String(finalVal).trim() !== '' && finalVal !== '-') {
            $el.text(finalVal);
            $box.show();
        } else {
            $el.text('-');
            $box.hide();
        }
    };

    setText('#DisplayStudentNameText', getValueByKeyContains(data, ['studentname', 'sname'], meta.studentName || '-'));
    setText('#DisplayAdmissionNoText', getValueByKeyContains(data, ['admno', 'admissionno', 'studentid'], meta.admissionNo || meta.studentId || '-'));
    setText('#DisplayFatherNameText', getValueByKeyContains(data, ['fathername'], meta.fatherName || '-'));
    setText('#DisplayMotherNameText', getValueByKeyContains(data, ['mothername'], meta.motherName || '-'));

    toggleField('#DisplayDobText', getValueByKeyContains(data, ['dob'], ''));
    toggleField('#DisplayClassText', getValueByKeyContains(data, ['course_name', 'coursename'], meta.className || ''));
    toggleField('#DisplayBranchText', getValueByKeyContains(data, ['branch_name', 'branchname'], meta.branchName || ''));
    toggleField('#DisplaySessionText', getValueByKeyContains(data, ['session_name', 'batch_name'], meta.sessionName || ''));
    toggleField('#DisplayStudentIdText', getValueByKeyContains(data, ['studentid', 'stu_id'], meta.studentId || ''));
    toggleField('#DisplayCategoryText', getValueByKeyContains(data, ['category_name'], ''));
    toggleField('#DisplayInstituteText', getValueByKeyContains(data, ['institutename'], meta.instituteName || ''));
    toggleField('#DisplayRegistrationNoText', getValueByKeyContains(data, ['registrationno'], ''));
    toggleField('#DisplayCategoryFlagText', getValueByKeyContains(data, ['category'], ''));
    toggleField('#DisplayDuesText', getValueByKeyContains(data, ['dues'], ''));
    toggleField('#DisplayRelaxationText', getValueByKeyContains(data, ['relaxation'], ''));
    toggleField('#DisplaySerialNoText', getValueByKeyContains(data, ['serialno'], ''));
    toggleField('#DisplaySchoolNoText', getValueByKeyContains(data, ['schoolno'], ''));
    toggleField('#DisplayAffiliationNoText', getValueByKeyContains(data, ['affliationno', 'affiliationno'], ''));
    toggleField('#DisplayRenewedText', getValueByKeyContains(data, ['renewed'], ''));

    setStudentPhotoSafe(getValueByKeyContains(data, ['picture'], meta.photo || ''));
}

function resetIssueForm() {
    if ($('#formIssueCertificate').length) {
        $('#formIssueCertificate')[0].reset();
    }

    currentCertificateQuestionList = [];
    currentStudentAutoData = null;
    selectedStudentMeta = null;

    setTodayDate();

    $('#ModalInstitute').val('');
    $('#ModalSession').val('');
    $('#ModalCourse').val('');
    $('#ModalBranch').val('');
    $('#ModalStudentID').val('');
    $('#ModalCertificateType').val('');

    $('#selectedCertificateBadge').html(`<i class="ti ti-file-certificate me-1"></i> Certificate Type: -`);
    $('#printCountBadge').html(`<i class="ti ti-printer me-1"></i> Print Count: 0`);

    $('#DisplayStudentNameText').text('Student Name');
    $('#DisplayAdmissionNoText').text('-');
    $('#DisplayFatherNameText').text('-');
    $('#DisplayMotherNameText').text('-');
    $('#DisplayDobText').text('-');
    $('#DisplayClassText').text('-');
    $('#DisplayBranchText').text('-');
    $('#DisplaySessionText').text('-');
    $('#DisplayInstituteText').text('-');
    $('#DisplayStudentIdText').text('-');
    $('#DisplayCategoryText').text('-');
    $('#DisplayCategoryFlagText').text('-');
    $('#DisplayDuesText').text('-');
    $('#DisplayRelaxationText').text('-');
    $('#DisplaySchoolNoText').text('-');
    $('#DisplayAffiliationNoText').text('-');
    $('#DisplayRenewedText').text('-');
    $('#DisplayRegistrationNoText').text('-');
    $('#DisplaySerialNoText').text('-');

    $('#dynamicQuestionContainer').html(`<div class="text-center py-3 text-muted small">No extra questions.</div>`);
    $('#dynamicQuestionCard').hide();

    setStudentPhotoSafe('');

    if ($("#formIssueCertificate").data('validator')) {
        $("#formIssueCertificate").validate().resetForm();
        $('#formIssueCertificate').find('.is-invalid, .is-valid').removeClass('is-invalid is-valid');
    }
}

async function loadCertificateQuestionsForIssue(meta, selectedType) {
    try {
        const payload = {
            Mode: 'GETFORFORM',
            InstituteID: $('#ModalInstitute').val() || $('#IssueSchoolID').val() || meta.institute || '',
            SessionID: $('#ModalSession').val() || $('#IssueSessionId').val() || meta.session || '',
            ClassID: $('#ModalCourse').val() || $('#IssueCourseId').val() || meta.course || '',
            BranchID: $('#ModalBranch').val() || $('#IssueBranchId').val() || meta.branch || '',
            ApplicableFor: selectedType,
            IsActive: true
        };

        const res = await new IMSClient().request('/master/TCQuestionMaster', 'POST', payload, true);
        const data = normalizeResultArray(res);

        if (!Array.isArray(data) || data.length === 0) {
            currentCertificateQuestionList = [];
            $('#dynamicQuestionCard').hide();
            $('#dynamicQuestionContainer').html(`<div class="text-center py-3 text-muted small">No extra questions.</div>`);
            return;
        }

        currentCertificateQuestionList = [...data];
        $('#dynamicQuestionCard').show();
        renderDynamicQuestions(data);
    } catch (error) {
        currentCertificateQuestionList = [];
        $('#dynamicQuestionCard').hide();
        $('#dynamicQuestionContainer').html(`<div class="text-center py-3 text-danger small">Unable to load questions.</div>`);
        console.error(error);
    }
}

function renderDynamicQuestions(questionList) {
    const $container = $('#dynamicQuestionContainer');

    if (!Array.isArray(questionList) || !questionList.length) {
        $container.html(`<div class="text-center py-3 text-muted small">No extra questions.</div>`);
        return;
    }

    let html = `<div class="row g-2">`;

    questionList.forEach((item, index) => {
        const id = parseInt(getValueByKeyContains(item, ['tcquestionid', 'questionid'], 0), 10);
        const text = getValueByKeyContains(item, ['questiontext'], '');
        const type = String(getValueByKeyContains(item, ['questiontype'], 'TEXT')).toUpperCase();
        const placeholder = getValueByKeyContains(item, ['placeholdertext', 'placeholder'], '');
        const optionValues = getValueByKeyContains(item, ['optionvalues'], '');
        const isMandatory = normalizeBool(getValueByKeyContains(item, ['ismandatory'], false));

        let fieldHtml = '';
        const fieldId = `CERTQ_${id}`;

        if (type === 'TEXTAREA') {
            fieldHtml = `
                <textarea class="form-control form-control-sm cert-dynamic-question"
                          id="${fieldId}"
                          data-questionid="${id}"
                          data-questiontext="${escapeHtml(text)}"
                          data-questiontype="${type}"
                          data-ismandatory="${isMandatory ? '1' : '0'}"
                          rows="2"
                          placeholder="${escapeHtml(placeholder || 'Enter answer')}"></textarea>
            `;
        } else if (type === 'DATE') {
            fieldHtml = `
                <input type="date"
                       class="form-control form-control-sm cert-dynamic-question"
                       id="${fieldId}"
                       data-questionid="${id}"
                       data-questiontext="${escapeHtml(text)}"
                       data-questiontype="${type}"
                       data-ismandatory="${isMandatory ? '1' : '0'}" />
            `;
        } else if (type === 'NUMBER') {
            fieldHtml = `
                <input type="number"
                       class="form-control form-control-sm cert-dynamic-question"
                       id="${fieldId}"
                       data-questionid="${id}"
                       data-questiontext="${escapeHtml(text)}"
                       data-questiontype="${type}"
                       data-ismandatory="${isMandatory ? '1' : '0'}"
                       placeholder="${escapeHtml(placeholder || 'Enter number')}" />
            `;
        } else if (type === 'YESNO') {
            fieldHtml = `
                <select class="form-select form-select-sm cert-dynamic-question"
                        id="${fieldId}"
                        data-questionid="${id}"
                        data-questiontext="${escapeHtml(text)}"
                        data-questiontype="${type}"
                        data-ismandatory="${isMandatory ? '1' : '0'}">
                    <option value="">--Select--</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            `;
        } else if (type === 'DROPDOWN') {
            const options = parseOptionValues(optionValues);
            let optionHtml = `<option value="">--Select--</option>`;
            options.forEach(opt => {
                optionHtml += `<option value="${escapeHtml(opt)}">${escapeHtml(opt)}</option>`;
            });

            fieldHtml = `
                <select class="form-select form-select-sm cert-dynamic-question"
                        id="${fieldId}"
                        data-questionid="${id}"
                        data-questiontext="${escapeHtml(text)}"
                        data-questiontype="${type}"
                        data-ismandatory="${isMandatory ? '1' : '0'}">
                    ${optionHtml}
                </select>
            `;
        } else {
            fieldHtml = `
                <input type="text"
                       class="form-control form-control-sm cert-dynamic-question"
                       id="${fieldId}"
                       data-questionid="${id}"
                       data-questiontext="${escapeHtml(text)}"
                       data-questiontype="${type}"
                       data-ismandatory="${isMandatory ? '1' : '0'}"
                       placeholder="${escapeHtml(placeholder || 'Enter answer')}" />
            `;
        }

        html += `
            <div class="col-xl-6 col-lg-6 col-md-12">
                <div class="border rounded-3 p-2 h-100">
                    <label class="form-label small fw-semibold mb-1">
                        ${index + 1}. ${escapeHtml(text)}
                        ${isMandatory ? '<span class="text-danger">*</span>' : ''}
                    </label>
                    ${fieldHtml}
                </div>
            </div>
        `;
    });

    html += `</div>`;
    $container.html(html);
}

function collectDynamicQuestionAnswers() {
    const answers = [];
    let isValid = true;

    $('.cert-dynamic-question').each(function () {
        const $field = $(this);
        const questionId = parseInt($field.data('questionid') || 0, 10);
        const questionText = $field.data('questiontext') || '';
        const questionType = ($field.data('questiontype') || 'TEXT').toUpperCase();
        const isMandatory = String($field.data('ismandatory') || '0') === '1';
        const answer = String($field.val() || '').trim();

        if (isMandatory && !answer) {
            isValid = false;
            $field.addClass('is-invalid');
        } else {
            $field.removeClass('is-invalid');
        }

        answers.push({
            QuestionID: questionId.toString(),
            QuestionText: questionText,
            QuestionType: questionType,
            Answer: answer,
            AnswerDisplay: answer,
            ControlType: questionType
        });
    });

    return { isValid, answers };
}

async function saveCertificate() {
    if (isIssueSaving) return;
    if (!$('#formIssueCertificate').valid()) return;

    const selectedType = ($('#ModalCertificateType').val() || '').trim().toUpperCase();

    if (!isSupportedCertificateType(selectedType)) {
        ShowNotification("warning", "Invalid Certificate Type", "center");
        return;
    }

    let questionAnswers = [];

    if (shouldLoadDynamicQuestions(selectedType) && currentCertificateQuestionList.length > 0) {
        const dynamicResult = collectDynamicQuestionAnswers();

        if (!dynamicResult.isValid) {
            ShowNotification("warning", "Please fill all required additional details", "center");
            return;
        }

        questionAnswers = dynamicResult.answers || [];
    }

    const confirmResult = await Swal.fire({
        title: `Confirm ${formatCertificateType(selectedType)} Certificate Issue`,
        text: "Are you sure you want to issue this certificate?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Issue',
        cancelButtonText: 'Cancel'
    });

    if (!confirmResult.isConfirmed) return;

    const btn = $('#btnSaveCertificate');
    const oldHtml = btn.html();

    isIssueSaving = true;
    btn.prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-1"></span> Saving...`);

    try {
        const parms = {
            Institute: $('#ModalInstitute').val() || $('#IssueSchoolID').val() || '',
            Session: $('#ModalSession').val() || $('#IssueSessionId').val() || '',
            Course: $('#ModalCourse').val() || $('#IssueCourseId').val() || '',
            Branch: $('#ModalBranch').val() || $('#IssueBranchId').val() || '',
            StudentID: $('#ModalStudentID').val() || '',
            Type: selectedType,
            Date: $('#IssueDate').val() || '',
            Remark: $('#Remark').val() || '',
            QuestionAnswerJson: JSON.stringify(questionAnswers),
            CUser: $('#hdnUserID').val() || $('#UserID').val() || '',
            mode: 'SaveCertificate'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);

        if (!res?.statusCode || res.statusCode === 200) {
            await Swal.fire({
                icon: 'success',
                title: `${formatCertificateType(selectedType)} Certificate Issued Successfully`,
                text: res?.message || 'Saved successfully'
            });

            if (issueCertificateModalInstance) {
                issueCertificateModalInstance.hide();
            }

            setTimeout(async function () {
                await fetchIssueStudentList();
            }, 300);
        } else {
            await Swal.fire({
                icon: 'warning',
                title: 'Unable to Process',
                text: res?.message || 'Operation failed'
            });
        }
    } catch (error) {
        console.error(error);
        await Swal.fire({
            icon: 'error',
            title: 'Something Went Wrong',
            text: 'Error while saving certificate request.'
        });
    } finally {
        isIssueSaving = false;
        btn.prop('disabled', false).html(oldHtml);
    }
}

async function openCertificateHistory(meta) {
    try {
        const modalEl = document.getElementById('certificateHistoryModal');

        if (!modalEl) {
            ShowNotification("warning", "History popup not available on page", "center");
            return;
        }

        if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
            ShowNotification("danger", "Bootstrap modal is not loaded properly", "center");
            return;
        }

        historyModalInstance = bootstrap.Modal.getInstance(modalEl);
        if (!historyModalInstance) {
            historyModalInstance = new bootstrap.Modal(modalEl, {
                backdrop: true,
                keyboard: true,
                focus: true
            });
        }

        $('#historyContainer').html(`
            <div class="text-center py-4">
                <div class="spinner-border spinner-border-sm text-primary me-2"></div>
                <span class="small text-muted">Loading certificate history...</span>
            </div>
        `);

        historyModalInstance.show();

        const parms = {
            Institute: meta.institute || '',
            Session: meta.session || '',
            Course: meta.course || '',
            Branch: meta.branch || '',
            StudentID: meta.studentId || '',
            mode: 'GetCertificateHistory'
        };

        const res = await new IMSClient().request('/student/IssueTcNso', 'POST', parms, true);
        const data = normalizeResultArray(res);

        if (!Array.isArray(data) || data.length === 0) {
            $('#historyContainer').html(`
                <div class="text-center py-4">
                    <span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle px-3 py-2">
                        <i class="ti ti-history-off me-1"></i> No certificate history found
                    </span>
                </div>
            `);
            return;
        }

        let html = `
            <div class="table-responsive">
                <table class="table table-sm table-bordered table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width:55px;" class="text-center">#</th>
                            <th style="min-width:140px;">Type</th>
                            <th style="min-width:130px;">Issue Date</th>
                            <th style="min-width:180px;">Remark</th>
                            <th style="width:90px;" class="text-center">Print</th>
                            <th style="min-width:130px;">Printed</th>
                            <th style="min-width:130px;">Created</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        data.forEach((item, index) => {
            const certificateType = formatCertificateType(item.certificateType || '-');
            const issueDate = item.issueDate ? item.issueDate : '-';
            const issueRemark = item.remark ? item.remark : '-';
            const printCount = (item.printCount ?? 0);
            const printedDate = item.printedDate ? item.printedDate : '-';
            const createdDate = item.createdDate ? item.createdDate : '-';

            const printBadgeClass = parseInt(printCount, 10) > 0
                ? 'bg-success-subtle text-success-emphasis border border-success-subtle'
                : 'bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle';

            html += `
                <tr>
                    <td class="text-center small">${index + 1}</td>
                    <td>
                        <span class="badge bg-info-subtle text-info-emphasis border border-info-subtle rounded-pill px-2 py-1 small">
                            <i class="ti ti-file-certificate me-1"></i>${escapeHtml(certificateType)}
                        </span>
                    </td>
                    <td class="small">${escapeHtml(issueDate)}</td>
                    <td class="small text-truncate" style="max-width:220px;" title="${escapeHtml(issueRemark)}">
                        ${escapeHtml(issueRemark)}
                    </td>
                    <td class="text-center">
                        <span class="badge ${printBadgeClass} rounded-pill px-2 py-1 small">
                            ${escapeHtml(String(printCount))}
                        </span>
                    </td>
                    <td class="small">${escapeHtml(printedDate)}</td>
                    <td class="small">${escapeHtml(createdDate)}</td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        $('#historyContainer').html(html);
    } catch (error) {
        console.error(error);

        $('#historyContainer').html(`
            <div class="text-center py-4">
                <span class="badge bg-danger-subtle text-danger-emphasis border border-danger-subtle px-3 py-2">
                    <i class="ti ti-alert-circle me-1"></i> Unable to load history
                </span>
            </div>
        `);

        ShowNotification("danger", "Unable to load certificate history", "center");
    }
}

function resetAllFilters() {
    if ($('#form_issueCertificate').length) {
        $('#form_issueCertificate')[0].reset();
    }

    if ($("#form_issueCertificate").data('validator')) {
        $("#form_issueCertificate").validate().resetForm();
        $('#form_issueCertificate').find('.is-invalid, .is-valid').removeClass('is-invalid is-valid');
    }

    initIssueEmptyState();
    setLastUpdated();

    setTimeout(function () {
        $('.ims-institute').trigger('change');
    }, 300);
}

function normalizeResultArray(res) {
    if (!res) return [];

    if (Array.isArray(res)) return res;
    if (Array.isArray(res.result)) return res.result;
    if (Array.isArray(res.data)) return res.data;
    if (Array.isArray(res.Data)) return res.Data;
    if (Array.isArray(res.d)) return res.d;

    if (typeof res.d === 'string') {
        try {
            const parsed = JSON.parse(res.d);
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) { }
    }

    return [];
}

function normalizeBool(val) {
    return val === true || val === "true" || val === 1 || val === "1";
}

function parseOptionValues(optionValues) {
    if (!optionValues) return [];

    return String(optionValues)
        .split(/[\n,|]/g)
        .map(x => x.trim())
        .filter(x => x !== '');
}

function getNoImageUrl() {
    return '/theme/admin/assets/images/avatar/07.png';
}

function normalizeBase64Image(value) {
    if (!value) return '';

    const v = String(value).trim();
    if (!v) return '';

    if (v.startsWith('data:image')) return v;
    if (v.length > 100) return 'data:image/png;base64,' + v;

    return v;
}

function setStudentPhotoSafe(photoValue) {
    const $img = $('#studentProfileImage');
    if (!$img.length) return;

    const noImage = getNoImageUrl();
    const src = normalizeBase64Image(photoValue);

    $img.off('error.certimg').on('error.certimg', function () {
        $(this).attr('src', noImage);
    });

    $img.attr('src', src || noImage);
}

function getValueByKeyContains(obj, keys, defaultValue = '') {
    if (!obj || typeof obj !== 'object') return defaultValue;

    const objKeys = Object.keys(obj);

    const normalize = (v) => String(v || '').replace(/[\s_\-]/g, '').toLowerCase();

    const normalizedObjKeys = objKeys.map(k => ({
        original: k,
        normalized: normalize(k)
    }));

    const normalizedWanted = (keys || []).map(k => normalize(k));

    for (const wanted of normalizedWanted) {
        const found = normalizedObjKeys.find(x => x.normalized === wanted);
        if (found) {
            const val = obj[found.original];
            if (val !== undefined && val !== null && String(val).trim() !== '') return val;
        }
    }

    for (const wanted of normalizedWanted) {
        const found = normalizedObjKeys.find(x => x.normalized.includes(wanted) || wanted.includes(x.normalized));
        if (found) {
            const val = obj[found.original];
            if (val !== undefined && val !== null && String(val).trim() !== '') return val;
        }
    }

    return defaultValue;
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}