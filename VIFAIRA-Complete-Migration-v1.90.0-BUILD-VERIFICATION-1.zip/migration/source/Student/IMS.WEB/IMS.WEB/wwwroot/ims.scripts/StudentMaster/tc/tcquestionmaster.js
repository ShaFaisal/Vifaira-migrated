﻿let tcQuestionSortable = null;

$(function () {
    $('#form_filter_tc_question select').on('change', function () {
        fetchTCQuestions();
    });

    loadParentQuestions();

    $('#addNewTCQuestionButton').on('click', function () {
        if (!canAddTCQuestion()) {
            ShowNotification("danger", "You do not have permission to add Question.", "center");
            return;
        }

        resetTCQuestionForm();
        $('#addNewTCQuestionButton').addClass('d-none');
        $('#tc_question_table_layout').addClass('d-none');
        $('#form_tc_question_layout').removeClass('d-none');

        setTimeout(function () {
            loadParentQuestions('#ParentQuestionID', 0, '');
            toggleOptionValuesField('#QuestionType', '#OptionValues');
            loadApplicableForQuestions('#ParentQuestionID');
        }, 300);
    });

    $('#closeTCQuestionBtn').on('click', function (e) {
        e.preventDefault();
        if (canAddTCQuestion()) {
            $('#addNewTCQuestionButton').removeClass('d-none');
        }
        $('#form_tc_question_layout').addClass('d-none');
        $('#tc_question_table_layout').removeClass('d-none');
        resetTCQuestionForm();
    });

    $('#QuestionType').on('change', function () {
        toggleOptionValuesField('#QuestionType', '#OptionValues');
    });

    $('#Edit_QuestionType').on('change', function () {
        toggleOptionValuesField('#Edit_QuestionType', '#Edit_OptionValues');
    });

    $('#InstituteId, #SessionID, #ClassID, #BranchID').on('change', function () {
        loadParentQuestions('#ParentQuestionID', $('#TCQuestionID').val() || 0, $('#ParentQuestionID').val() || '');
        loadApplicableForQuestions('#ParentQuestionID');
    });

    $('#Edit_InstituteId, #Edit_SessionID, #Edit_ClassID, #Edit_BranchID').on('change', function () {
        loadParentQuestions('#Edit_ParentQuestionID', $('#Edit_TCQuestionID').val() || 0, $('#Edit_ParentQuestionID').val() || '');
        loadApplicableForQuestions('#Edit_ParentQuestionID');
    });

    $("#form_tc_question").validate({
        rules: {
            QuestionCode: { required: true },
            QuestionText: { required: true },
            QuestionType: { required: true },
            InstituteId: { required: true },
            ApplicableFor: { required: true }
        },
        messages: {
            QuestionCode: { required: "Please enter Question Code" },
            QuestionText: { required: "Please enter Question Text" },
            QuestionType: { required: "Please select Question Type" },
            InstituteId: { required: "Please select Institute" },
            ApplicableFor: { required: "Please select Certificate Type" }
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            if (element.closest('.form-check').length) {
                error.insertAfter(element.closest('.form-check'));
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        },
        submitHandler: function (form, event) {
            event.preventDefault();

            if (!canAddTCQuestion()) {
                ShowNotification("danger", "You do not have permission to add Question.", "center");
                return false;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to save this Question?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, save it!',
                cancelButtonText: 'No, cancel',
                buttonsStyling: false,
                customClass: {
                    confirmButton: 'btn btn-primary me-2',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    saveTCQuestion(form, false);
                }
            });

            return false;
        }
    });

    $("#form_Edit_tc_question").validate({
        rules: {
            QuestionCode: { required: true },
            QuestionText: { required: true },
            QuestionType: { required: true },
            InstituteId: { required: true },
            ApplicableFor: { required: true }
        },
        messages: {
            QuestionCode: { required: "Please enter Question Code" },
            QuestionText: { required: "Please enter Question Text" },
            QuestionType: { required: "Please select Question Type" },
            InstituteId: { required: "Please select Institute" },
            ApplicableFor: { required: "Please select Certificate Type" }
        },
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            if (element.closest('.form-check').length) {
                error.insertAfter(element.closest('.form-check'));
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        },
        submitHandler: function (form, event) {
            event.preventDefault();

            if (!canEditTCQuestion()) {
                ShowNotification("danger", "You do not have permission to update Question.", "center");
                return false;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to update this Question?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, update it!',
                cancelButtonText: 'No, cancel',
                buttonsStyling: false,
                customClass: {
                    confirmButton: 'btn btn-primary me-2',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    saveTCQuestion(form, true);
                }
            });

            return false;
        }
    });

    if (!canAddTCQuestion()) {
        $('#addNewTCQuestionButton').addClass('d-none');
    }

    fetchTCQuestions();
});

function fetchTCQuestions() {
    const instituteId = $('#InstituteFilter').val() || '';
    const sessionId = $('#SessionFilter').val() || '';
    const classId = $('#ClassFilter').val() || '';
    const branchId = $('#BranchFilter').val() || '';
    const applicableFor = $('#ApplicableForFilter').val() || '';
    const isActiveVal = $('#IsActiveFilter').val();
    const isActive = isActiveVal === '' ? null : normalizeBool(isActiveVal);

    if (!instituteId) {
        createTCQuestionTable([]);
        if (!canAddTCQuestion()) {
            $('#addNewTCQuestionButton').addClass('d-none');
        }
        return;
    }

    const payload = {
        Action: 'LIST',
        Mode: 'LIST',
        InstituteID: instituteId,
        SessionID: sessionId,
        ClassID: classId,
        BranchID: branchId,
        ApplicableFor: applicableFor,
        IsActive: isActive
    };

    new IMSClient().request('/master/TCQuestionMaster', 'POST', payload, true)
        .then((res) => {
            if (res.statusCode === 200) {
                createTCQuestionTable(res.result || []);
            } else {
                createTCQuestionTable([]);
                ShowNotification("danger", res.message || "Failed to load Questions", "center");
            }
        })
        .catch((err) => {
            createTCQuestionTable([]);
            ShowNotification("danger", err.message || "Something went wrong", "center");
        });
}

function createTCQuestionTable(data) {
    const tableId = '#tcQuestionTable';
    const tbodyId = '#tc_question_table_body';

    if ($.fn.DataTable.isDataTable(tableId)) {
        $(tableId).DataTable().clear().destroy();
    }

    if (tcQuestionSortable) {
        tcQuestionSortable.destroy();
        tcQuestionSortable = null;
    }

    const canEdit = window.userRole && window.userRole.isEdit === true;
    const canDelete = window.userRole && window.userRole.isDelete === true;
    const canChangeStatus = window.userRole && window.userRole.isActive === true;
    const hasActionMenu = canEdit || canDelete || canChangeStatus;

    $(tbodyId).empty();

    if (!data || data.length === 0) {
        $(tbodyId).html(`
            <tr id="no_tc_question_placeholder">
                <td colspan="12" class="text-center py-5">
                    <div class="d-flex flex-column align-items-center gap-2 text-muted">
                        <i class="ti ti-help-octagon fs-1 text-secondary"></i>
                        <span class="fw-semibold">No Questions Available</span>
                        <small>Select institute / add a new Question</small>
                    </div>
                </td>
            </tr>
        `);
        return;
    }

    data.forEach(item => {
        const id = item.tcQuestionID || item.TCQuestionID || 0;
        const isActive = normalizeBool(item.isActive ?? item.IsActive);
        const isMandatory = normalizeBool(item.isMandatory ?? item.IsMandatory);
        const applicableFor = item.applicableFor ?? item.ApplicableFor ?? '-';
        const applicableForIcon = getApplicableForIcon(applicableFor);

        const actions = `
            ${canEdit ? `
                <li>
                    <a class="dropdown-item"
                       href="javascript:void(0)"
                       onclick="onEditTCQuestion(${id})">
                        <i class="ti ti-edit me-1 text-primary"></i> Edit
                    </a>
                </li>` : ``}

            ${canChangeStatus ? `
                <li>
                    <a class="dropdown-item"
                       href="javascript:void(0)"
                       onclick="onToggleTCQuestionStatus(${id}, ${isActive ? 0 : 1})">
                        <i class="ti ${isActive ? 'ti-player-pause' : 'ti-check'} me-1 ${isActive ? 'text-warning' : 'text-success'}"></i>
                        ${isActive ? 'Deactivate' : 'Activate'}
                    </a>
                </li>` : ``}

            ${canDelete ? `
                <li>
                    <a class="dropdown-item text-danger"
                       href="javascript:void(0)"
                       onclick="onDeleteTCQuestion(${id})">
                        <i class="ti ti-trash me-1"></i> Delete
                    </a>
                </li>` : ``}
        `;

        $(tbodyId).append(`
            <tr class="align-middle" data-id="${id}">
                <td class="text-center">
                    <span class="drag-handle d-inline-flex align-items-center justify-content-center ${canEdit ? 'cursor-move' : ''}" style="width:32px;height:32px;${canEdit ? '' : 'opacity:.4;pointer-events:none;'}">
                        <i class="ti ti-grip-vertical fs-5 text-muted"></i>
                    </span>
                </td>
                <td>
                    <span class="badge bg-primary-subtle text-primary border px-2 py-1">
                        ${escapeHtml(item.questionCode ?? item.QuestionCode ?? '-')}
                    </span>
                </td>
                <td>
                    <div class="fw-semibold text-dark">${escapeHtml(item.questionText ?? item.QuestionText ?? '-')}</div>
                    ${(item.showOnValue ?? item.ShowOnValue) ? `
                        <small class="text-muted d-block mt-1">
                            <i class="ti ti-link me-1"></i>
                            Show On: <b>${escapeHtml(item.showOnValue ?? item.ShowOnValue)}</b>
                        </small>` : ``}
                </td>
                <td>
                    <span class="badge bg-info-subtle text-info border px-2 py-1">
                        ${escapeHtml(item.questionType ?? item.QuestionType ?? '-')}
                    </span>
                </td>
                <td>
                    <span class="badge ${applicableForIcon.class} border px-2 py-1">
                        <i class="${applicableForIcon.icon} me-1"></i> ${escapeHtml(applicableFor)}
                    </span>
                </td>
                <td>${badgeWithName(item.instituteID ?? item.InstituteID, item.instituteName ?? item.InstituteName, 'building', 'info')}</td>
                <td>${badgeWithName(item.sessionID ?? item.SessionID, item.sessionName ?? item.SessionName, 'calendar', 'success')}</td>
                <td>${badgeWithName(item.classID ?? item.ClassID, item.className ?? item.ClassName, 'school', 'warning')}</td>
                <td>${badgeWithName(item.branchID ?? item.BranchID, item.branchName ?? item.BranchName, 'git-branch', 'secondary')}</td>
                <td>
                    ${isMandatory
                ? `<span class="badge bg-danger-subtle text-danger border">Yes</span>`
                : `<span class="badge bg-secondary-subtle text-secondary border">No</span>`
            }
                </td>
                <td>
                    ${isActive
                ? `<span class="badge bg-success-subtle text-success border">Active</span>`
                : `<span class="badge bg-danger-subtle text-danger border">Inactive</span>`
            }
                </td>
                <td class="text-center">
                    ${hasActionMenu ? `
                    <div class="dropdown">
                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="ti ti-dots-vertical"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                            ${actions}
                        </ul>
                    </div>` : ``}
                </td>
            </tr>
        `);
    });

    $(tableId).DataTable({
        order: [],
        pageLength: 50,
        lengthChange: false,
        paging: false,
        info: false,
        searching: false,
        responsive: true
    });

    initTCQuestionSortable();
}

function getApplicableForIcon(applicableFor) {
    const type = (applicableFor || '').toUpperCase();
    switch (type) {
        case 'TC': return { icon: 'ti ti-file', class: 'bg-primary-subtle text-primary' };
        case 'NSO': return { icon: 'ti ti-checkbox', class: 'bg-success-subtle text-success' };
        case 'PROVISIONAL': return { icon: 'ti ti-school', class: 'bg-warning-subtle text-warning' };
        case 'CHARACTER': return { icon: 'ti ti-star', class: 'bg-info-subtle text-info' };
        case 'MIGRATION': return { icon: 'ti ti-globe', class: 'bg-secondary-subtle text-secondary' };
        case 'DMC': return { icon: 'ti ti-chart-bar', class: 'bg-danger-subtle text-danger' };
        case 'BONAFIDE': return { icon: 'ti ti-id', class: 'bg-dark-subtle text-dark' };
        default: return { icon: 'ti ti-question-mark', class: 'bg-secondary-subtle text-secondary' };
    }
}

function initTCQuestionSortable() {
    const tbody = document.querySelector('#tc_question_table_body');
    if (!tbody) return;
    if (!canEditTCQuestion()) return;
    if (typeof Sortable === 'undefined') return;

    tcQuestionSortable = new Sortable(tbody, {
        handle: '.drag-handle',
        animation: 150,
        ghostClass: 'table-active',
        onEnd: function () {
            saveDraggedTCQuestionOrder();
        }
    });
}

function saveDraggedTCQuestionOrder() {
    if (!canEditTCQuestion()) {
        ShowNotification("danger", "You do not have permission to update display order.", "center");
        fetchTCQuestions();
        return;
    }

    const rows = $('#tc_question_table_body tr[data-id]');
    if (!rows.length) return;

    const orderList = [];

    rows.each(function (index) {
        const id = parseInt($(this).attr('data-id'), 10);
        if (!isNaN(id)) {
            orderList.push({
                TCQuestionID: id,
                DisplayOrder: index + 1
            });
        }
    });

    if (!orderList.length) return;

    new IMSClient().request('/master/TCQuestionMaster', 'POST', {
        Action: 'BULKUPDATEORDER',
        Mode: 'BULKUPDATEORDER',
        OrderJson: JSON.stringify(orderList)
    }, true)
        .then(res => {
            if (res.statusCode === 200) {
                ShowNotification("success", res.message || "Display order updated", "center");
                setTimeout(fetchTCQuestions, 300);
            } else {
                ShowNotification("danger", res.message || "Order update failed", "center");
                fetchTCQuestions();
            }
        })
        .catch(err => {
            ShowNotification("danger", err.message || "Something went wrong", "center");
            fetchTCQuestions();
        });
}

function saveTCQuestion(form, isEdit) {
    const $btn = isEdit ? $("#UpdateTCQuestionBtn") : $("#SaveTCQuestion");
    const originalText = isEdit ? "Save changes" : "SAVE";

    $btn.addClass("pe-none").html(`
        <span class="spinner-border spinner-border-sm me-2 ms-2" role="status"></span>
        Please Wait...
    `);

    const $form = $(form);

    const payload = {
        Action: 'SAVE',
        Mode: 'SAVE',
        TCQuestionID: isEdit ? ($('#Edit_TCQuestionID').val() || 0) : ($('#TCQuestionID').val() || 0),
        InstituteID: isEdit ? ($('#Edit_InstituteId').val() || '') : ($('#InstituteId').val() || ''),
        SessionID: isEdit ? ($('#Edit_SessionID').val() || '') : ($('#SessionID').val() || ''),
        ClassID: isEdit ? ($('#Edit_ClassID').val() || '') : ($('#ClassID').val() || ''),
        BranchID: isEdit ? ($('#Edit_BranchID').val() || '') : ($('#BranchID').val() || ''),
        ApplicableFor: isEdit ? ($('#Edit_ApplicableFor').val() || '') : ($('#ApplicableFor').val() || ''),
        QuestionCode: isEdit ? ($('#Edit_QuestionCode').val() || '') : ($('#QuestionCode').val() || ''),
        QuestionText: isEdit ? ($('#Edit_QuestionText').val() || '') : ($('#QuestionText').val() || ''),
        QuestionType: isEdit ? ($('#Edit_QuestionType').val() || '') : ($('#QuestionType').val() || ''),
        DisplayOrder: parseInt(isEdit ? ($('#Edit_DisplayOrder').val() || 1) : ($('#DisplayOrder').val() || 1), 10),
        IsMandatory: isEdit ? $('#Edit_IsMandatory').is(':checked') : $('#IsMandatory').is(':checked'),
        IsActive: isEdit ? $('#Edit_IsActive').is(':checked') : $('#IsActive').is(':checked'),
        PlaceholderText: isEdit ? ($('#Edit_PlaceholderText').val() || '') : ($('#PlaceholderText').val() || ''),
        OptionValues: isEdit ? ($('#Edit_OptionValues').val() || '') : ($('#OptionValues').val() || ''),
        ParentQuestionID: toNullableInt(isEdit ? $('#Edit_ParentQuestionID').val() : $('#ParentQuestionID').val()),
        ShowOnValue: isEdit ? ($('#Edit_ShowOnValue').val() || '') : ($('#ShowOnValue').val() || ''),
        ValidationType: isEdit ? ($('#Edit_ValidationType').val() || '') : ($('#ValidationType').val() || '')
    };

    new IMSClient().request('/master/TCQuestionMaster', 'POST', payload, true)
        .then((res) => {
            if (res.statusCode === 200) {
                ShowNotification("primary", res.message || "Saved successfully", "center");

                if (isEdit) {
                    form.reset();
                    $form.validate().resetForm();
                    $form.find('.is-valid, .is-invalid').removeClass('is-valid is-invalid');
                    $('#editTCQuestionModal').modal('hide');
                } else {
                    resetTCQuestionForm();
                    if (canAddTCQuestion()) {
                        $('#addNewTCQuestionButton').removeClass('d-none');
                    }
                    $('#form_tc_question_layout').addClass('d-none');
                    $('#tc_question_table_layout').removeClass('d-none');
                }

                setTimeout(() => {
                    fetchTCQuestions();
                    loadParentQuestions();
                }, 500);
            } else {
                ShowNotification("danger", res.message || "Save failed", "center");
            }
        })
        .catch((err) => {
            ShowNotification("danger", err.message || "Something went wrong", "center");
        })
        .finally(() => {
            $btn.removeClass("pe-none").html(originalText);
        });
}

function onEditTCQuestion(id) {
    if (!canEditTCQuestion()) {
        ShowNotification("danger", "You do not have permission to edit Question.", "center");
        return;
    }

    new IMSClient().request('/master/TCQuestionMaster', 'POST', {
        Action: 'GETBYID',
        Mode: 'GETBYID',
        TCQuestionID: id
    }, true)
        .then((res) => {
            if (res.statusCode === 200) {
                const data = Array.isArray(res.result) ? res.result[0] : res.result;
                if (!data) {
                    ShowNotification("danger", "Record not found", "center");
                    return;
                }

                populateTCQuestionEditForm(data);
                $('#editTCQuestionModal').modal('show');
            } else {
                ShowNotification("danger", res.message || "Unable to fetch record", "center");
            }
        })
        .catch((err) => {
            ShowNotification("danger", err.message || "Something went wrong", "center");
        });
}

function populateTCQuestionEditForm(data) {
    const $form = $('#form_Edit_tc_question');
    $form[0].reset();

    if ($form.validate) {
        $form.validate().resetForm();
    }
    $form.find('.is-valid, .is-invalid').removeClass('is-valid is-invalid');

    $('#Edit_TCQuestionID').val(data.tcQuestionID ?? data.TCQuestionID ?? 0);
    $('#Edit_QuestionCode').val(data.questionCode ?? data.QuestionCode ?? '');
    $('#Edit_QuestionText').val(data.questionText ?? data.QuestionText ?? '');
    $('#Edit_QuestionType').val(data.questionType ?? data.QuestionType ?? '');
    $('#Edit_DisplayOrder').val(data.displayOrder ?? data.DisplayOrder ?? 1);
    $('#Edit_PlaceholderText').val(data.placeholderText ?? data.PlaceholderText ?? '');
    $('#Edit_OptionValues').val(data.optionValues ?? data.OptionValues ?? '');
    $('#Edit_ShowOnValue').val(data.showOnValue ?? data.ShowOnValue ?? '');
    $('#Edit_ValidationType').val(data.validationType ?? data.ValidationType ?? '');
    $('#Edit_ApplicableFor').val(data.applicableFor ?? data.ApplicableFor ?? '');
    $('#Edit_IsMandatory').prop('checked', normalizeBool(data.isMandatory ?? data.IsMandatory));
    $('#Edit_IsActive').prop('checked', normalizeBool(data.isActive ?? data.IsActive));

    const instituteVal = data.instituteID ?? data.InstituteID ?? '';
    const sessionVal = data.sessionID ?? data.SessionID ?? '';
    const classVal = data.classID ?? data.ClassID ?? '';
    const branchVal = data.branchID ?? data.BranchID ?? '';
    const parentId = data.parentQuestionID ?? data.ParentQuestionID ?? '';

    $('#Edit_InstituteId').val(instituteVal).trigger('change');

    setTimeout(() => {
        $('#Edit_SessionID').val(sessionVal).trigger('change');

        setTimeout(() => {
            $('#Edit_ClassID').val(classVal).trigger('change');

            setTimeout(() => {
                $('#Edit_BranchID').val(branchVal).trigger('change');
                loadParentQuestions('#Edit_ParentQuestionID', $('#Edit_TCQuestionID').val(), parentId);
                loadApplicableForQuestions('#Edit_ParentQuestionID');
                toggleOptionValuesField('#Edit_QuestionType', '#Edit_OptionValues');
            }, 600);
        }, 600);
    }, 600);
}

function loadApplicableForQuestions(targetSelector = '#ParentQuestionID') {
    const applicableFor = $('#ApplicableFor').val() || '';
    const $select = $(targetSelector);

    if (!applicableFor && targetSelector === '#ParentQuestionID') return;

    const applicableForValue = targetSelector === '#ParentQuestionID'
        ? ($('#ApplicableFor').val() || '')
        : ($('#Edit_ApplicableFor').val() || '');

    $select.find('option').each(function () {
        const $option = $(this);
        const optionText = $option.text();
        if (optionText.includes(`[${applicableForValue}]`)) {
            $option.show();
        } else if ($option.val() === '') {
            $option.show();
        } else if (applicableForValue === '') {
            $option.show();
        } else {
            $option.hide();
        }
    });
}

function onDeleteTCQuestion(id) {
    if (!canDeleteTCQuestion()) {
        ShowNotification("danger", "You do not have permission to delete Question.", "center");
        return;
    }

    Swal.fire({
        title: 'Are you sure?',
        text: `This will permanently delete the Question.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-danger me-2',
            cancelButton: 'btn btn-secondary'
        }
    }).then(result => {
        if (result.isConfirmed) {
            new IMSClient().request('/master/TCQuestionMaster', 'POST', {
                Action: 'DELETE',
                Mode: 'DELETE',
                TCQuestionID: id
            }, true)
                .then(res => {
                    if (res.statusCode === 200) {
                        ShowNotification("success", res.message || "Deleted successfully", "center");
                        setTimeout(() => {
                            fetchTCQuestions();
                            loadParentQuestions();
                        }, 500);
                    } else {
                        ShowNotification("danger", res.message || "Delete failed", "center");
                    }
                })
                .catch(err => {
                    ShowNotification("danger", err.message || "Something went wrong", "center");
                });
        }
    });
}

function onToggleTCQuestionStatus(id, status) {
    if (!canStatusTCQuestion()) {
        ShowNotification("danger", "You do not have permission to change status.", "center");
        return;
    }

    const isActivate = parseInt(status, 10) === 1;

    Swal.fire({
        title: 'Are you sure?',
        text: isActivate ? 'Do you want to activate this question?' : 'Do you want to deactivate this question?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: isActivate ? 'Yes, activate it!' : 'Yes, deactivate it!',
        cancelButtonText: 'Cancel',
        buttonsStyling: false,
        customClass: {
            confirmButton: 'btn btn-primary me-2',
            cancelButton: 'btn btn-secondary'
        }
    }).then(result => {
        if (result.isConfirmed) {
            new IMSClient().request('/master/TCQuestionMaster', 'POST', {
                Action: 'TOGGLEACTIVE',
                Mode: 'TOGGLEACTIVE',
                TCQuestionID: id,
                IsActive: isActivate
            }, true)
                .then(res => {
                    if (res.statusCode === 200) {
                        ShowNotification("success", res.message || "Status updated", "center");
                        setTimeout(fetchTCQuestions, 500);
                    } else {
                        ShowNotification("danger", res.message || "Status update failed", "center");
                    }
                })
                .catch(err => {
                    ShowNotification("danger", err.message || "Something went wrong", "center");
                });
        }
    });
}

function loadParentQuestions(targetSelector = '#ParentQuestionID', currentId = 0, selectedValue = '') {
    let instituteId = '';
    let sessionId = '';
    let classId = '';
    let branchId = '';
    let applicableFor = '';

    if (targetSelector === '#ParentQuestionID') {
        instituteId = $('#InstituteId').val() || '';
        sessionId = $('#SessionID').val() || '';
        classId = $('#ClassID').val() || '';
        branchId = $('#BranchID').val() || '';
        applicableFor = $('#ApplicableFor').val() || '';
    } else if (targetSelector === '#Edit_ParentQuestionID') {
        instituteId = $('#Edit_InstituteId').val() || '';
        sessionId = $('#Edit_SessionID').val() || '';
        classId = $('#Edit_ClassID').val() || '';
        branchId = $('#Edit_BranchID').val() || '';
        applicableFor = $('#Edit_ApplicableFor').val() || '';
    } else {
        instituteId = $('#InstituteFilter').val() || '';
        sessionId = $('#SessionFilter').val() || '';
        classId = $('#ClassFilter').val() || '';
        branchId = $('#BranchFilter').val() || '';
        applicableFor = $('#ApplicableForFilter').val() || '';
    }

    const $ddl = $(targetSelector);
    $ddl.empty().append(`<option value="">-- None --</option>`);

    if (!instituteId) {
        return;
    }

    new IMSClient().request('/master/TCQuestionMaster', 'POST', {
        Action: 'LIST',
        Mode: 'LIST',
        InstituteID: instituteId,
        SessionID: sessionId,
        ClassID: classId,
        BranchID: branchId,
        ApplicableFor: applicableFor,
        IsActive: true
    }, true)
        .then((res) => {
            if (res.statusCode === 200 && Array.isArray(res.result)) {
                res.result.forEach(item => {
                    const id = item.tcQuestionID ?? item.TCQuestionID;
                    const text = item.questionText ?? item.QuestionText ?? '';
                    const code = item.questionCode ?? item.QuestionCode ?? '';
                    const itemApplicableFor = item.applicableFor ?? item.ApplicableFor ?? '';

                    if (parseInt(id, 10) === parseInt(currentId || 0, 10)) return;

                    $ddl.append(`
                        <option value="${id}" data-applicable="${escapeHtml(itemApplicableFor)}">
                            [${escapeHtml(itemApplicableFor)}] ${escapeHtml(code)} - ${escapeHtml(text)}
                        </option>
                    `);
                });

                if (selectedValue) {
                    $ddl.val(selectedValue);
                }
            }
        })
        .catch(() => { });
}

function resetTCQuestionForm() {
    const $form = $('#form_tc_question');

    if ($form.length && $form[0]) {
        $form[0].reset();
    }

    $('#TCQuestionID').val(0);
    $('#DisplayOrder').val(1);
    $('#IsActive').prop('checked', true);
    $('#IsMandatory').prop('checked', false);
    $('#ApplicableFor').val('');

    if ($form.validate) {
        $form.validate().resetForm();
    }

    $form.find('.is-valid, .is-invalid').removeClass('is-valid is-invalid');
    $('#ParentQuestionID').html('<option value="">-- None --</option>');
    toggleOptionValuesField('#QuestionType', '#OptionValues');
}

function toggleOptionValuesField(typeSelector, optionSelector) {
    const typeVal = ($(typeSelector).val() || '').toLowerCase();
    const $option = $(optionSelector);

    if (typeVal === 'dropdown' || typeVal === 'yesno') {
        $option.prop('readonly', false);

        if (typeVal === 'yesno' && !$option.val()) {
            $option.val('Yes,No');
        }
    } else {
        $option.val('');
        $option.prop('readonly', true);
    }
}

function canAddTCQuestion() {
    return window.userRole && window.userRole.isAdd === true;
}

function canEditTCQuestion() {
    return window.userRole && window.userRole.isEdit === true;
}

function canDeleteTCQuestion() {
    return window.userRole && window.userRole.isDelete === true;
}

function canStatusTCQuestion() {
    return window.userRole && window.userRole.isActive === true;
}

function normalizeBool(val) {
    return val === true || val === "true" || val === 1 || val === "1";
}

function toNullableInt(val) {
    if (val === null || val === undefined || val === '') return null;
    const num = parseInt(val, 10);
    return isNaN(num) ? null : num;
}

function escapeHtml(value) {
    if (value === null || value === undefined) return '';
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function badgeWithName(value, name, icon = 'circle', color = 'secondary') {
    const idText = value && String(value).trim() !== '' ? escapeHtml(value) : 'COMMON';
    const nameText = name && String(name).trim() !== '' ? escapeHtml(name) : 'COMMON';
    const isCommon = idText === 'COMMON' || nameText === 'COMMON';

    if (isCommon) {
        return `<span class="badge bg-secondary-subtle text-secondary border px-2 py-1" title="COMMON">
                    <i class="ti ti-world me-1"></i> COMMON
                </span>`;
    }

    return `<span class="badge bg-${color}-subtle text-${color} border px-2 py-1" title="${nameText}">
                <i class="ti ti-${icon} me-1"></i> ${nameText}
            </span>`;
}