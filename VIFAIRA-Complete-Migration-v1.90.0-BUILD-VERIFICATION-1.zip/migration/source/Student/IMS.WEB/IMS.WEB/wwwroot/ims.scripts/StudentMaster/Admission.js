﻿$(document).ready(function () {
    $('.ims-institute').on('change', function () {

        const instituteId = $(this).val();
        const source = $(this).closest('form');
        handleInstituteTypeOnFilterChange(instituteId, source);
    });

    $('input[name="resetOption"]').on('change', function () {
        const selectedValue = $(this).val();

        if (selectedValue === 'RESET') {
            $('#manualPasswordSection').show();
            $('#sendMailSection').show();
        } else {
            $('#manualPasswordSection').hide();
            $('#sendMailSection').hide();
        }
    });


    $(document).on('click', '.toggle-password', function () {
        var target = $(this).data('target');
        var input = $(target);
        var icon = $(this).find('i');

        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            icon.removeClass('ti-eye').addClass('ti-eye-off');
        } else {
            input.attr('type', 'password');
            icon.removeClass('ti-eye-off').addClass('ti-eye');
        }
    });


    $(document).on("click", ".reset-btn", function () {

        var encoded = $(this).attr("data-item");

        var data = JSON.parse(decodeURIComponent(encoded));

        // Bind values to modal
        $("#mStudentName").text(data.student_name);
        $("#mFatherName").text(data.father_name);
        $("#mCourse").text(data.course_Name);
        $("#mSemester").text(data.semester_Name);
        $("#mMobile").text(data.studentMobile);
        $("#mStatus").text(data.status);

        // Hidden field
        $("#hdAdmissionNo").val(data.adm_admissionno);

        // Clear password fields
        $("#newPassword").val("");
        $("#confirmPassword").val("");
        $("#sendMail").prop("checked", false);
        $("#passwordError").html("");

        // Open modal
        $("#resetPasswordModal").modal("show");
    });



    $('#addNewButton').on('click', (e) => {
        $('#admission_table_layout').addClass('d-none')
        $('#addmission_layout').removeClass('d-none')
        $('#addNewButton').addClass('d-none')
        $('#searchStudent').removeClass('d-none')


    })
    $('#searchStudent').on('click', (e) => {

        $('#admission_table_layout').removeClass('d-none')
        $('#addmission_layout').addClass('d-none')
        $('#addNewButton').removeClass('d-none')
        $('#searchStudent').addClass('d-none')
    })

    const token = new URLSearchParams(window.location.search).get("token");
    if (token) {
        GetRegistration(decodeURIComponent(token));
        $('#addNewButton').click()

    }

    $('#isLateral').on('change', function () {
        if ($(this).is(':checked')) {
            // $('#letBatch').removeClass('d-none');
            $('#Institute_ID').data("action", 'letBatch,Program,Branch').change()
            $('#Course_ID').val('')
            $('#Branch_ID').val('')
            $('#Section_ID').val('')
            $('#Semester_ID').val('')

        } else {
            //   $('#letBatch').addClass('d-none');
            $('#Institute_ID').data("action", 'ActiveSession,Program,Branch').change()
            $('#Batch_ID').val('');

        }
    });

    $('#isHostelReq').on('change', function () {
        if ($(this).is(':checked')) {
            $('#isMess').removeClass('d-none');
        } else {
            $('#isMess').addClass('d-none');
        }
    });

    $('#RegNo').on('keypress', function (e) {
        if (e.which === 13) {
            e.preventDefault();
            GetRegistration($(this).val());
        }
    });

    const admissionForm = $("#form_admission");
    admissionForm.validate({
        ignore: [],
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",
        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            if (element.parent(".input-group").length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        }
    });


    $(".btn-next").on("click", function (e) {
        e.preventDefault();
        const currentTab = $(".tab-pane.active");
        const currentIndex = $(".tab-pane").index(currentTab);
        const nextTab = $(".tab-pane").eq(currentIndex + 1);

        let isValid = true;
        currentTab.find("input:visible, select:visible, textarea:visible").each(function () {
            if (!admissionForm.validate().element(this)) {
                isValid = false;
            }
        });

        if (!isValid) {
            const firstInvalid = currentTab.find(".is-invalid").first();
            $("html, body").animate({ scrollTop: firstInvalid.offset().top - 100 }, 200);
            return;
        }

        if (nextTab.length) {
            const nextId = nextTab.attr("id");
            $('[data-bs-target="#' + nextId + '"]').tab("show");
            $("html, body").animate({ scrollTop: 0 }, 200);
        }
    });


    $(".btn-prev").on("click", function (e) {
        e.preventDefault();
        const currentTab = $(".tab-pane.active");
        const currentIndex = $(".tab-pane").index(currentTab);
        const prevTab = $(".tab-pane").eq(currentIndex - 1);

        if (prevTab.length) {
            const prevId = prevTab.attr("id");
            $('[data-bs-target="#' + prevId + '"]').tab("show");
            $("html, body").animate({ scrollTop: 0 }, 200);
        }
    });

    admissionForm.on("submit", function (e) {
        e.preventDefault();

        let isValid = true;
        let firstInvalidField = null;

        admissionForm.find("input, select, textarea").each(function () {
            if (!admissionForm.validate().element(this)) {
                if (!firstInvalidField) firstInvalidField = this;
                isValid = false;
            }
        });


        if (!isValid) {
            const invalidTabPane = $(firstInvalidField).closest(".tab-pane");
            const invalidTabId = invalidTabPane.attr("id");

            d
            $('[data-bs-target="#' + invalidTabId + '"]').tab("show");
            $("html, body").animate({
                scrollTop: $(firstInvalidField).offset().top - 100
            }, 400);

            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to save this data?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, save it!',
            cancelButtonText: 'No, cancel',
            buttonsStyling: false,
            customClass: {
                confirmButton: 'btn btn-primary me-2',
                cancelButton: 'btn btn-secondary'
            }
        }).then(async (result) => {
            if (result.isConfirmed) {
                const $btn = $("#SaveRecord");
                $btn.addClass("pe-none").html(`
                <span class="spinner-border spinner-border-sm me-2 ms-2" role="status"></span>
                Please Wait...
            `);

                try {
                    const formData = new FormData(admissionForm[0]);
                    formData.append("HostelReq", $('#isHostelReq').is(':checked'));
                    formData.append("TransportReq", $('#isTransportReq').is(':checked'));
                    formData.append("PhysicallyChallenged", $('#isPhysicallyChallenged').is(':checked'));
                    formData.append("MessReq", $('#isMessReq').is(':checked'));
                    formData.append("iSLateralEntry", $('#isLateral').is(':checked'));
                    formData.append("CreateDuesOnSave", $('#isCreateDues').is(':checked'));
                    formData.append("Mode", "insert");



                    const res = await new IMSClient().request('/Student/Admission', 'POST', formData, true);

                    if (res.statusCode === 200) {

                        Swal.fire({
                            title: 'Success!',
                            text: res.message,
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            timer: 3000,
                            timerProgressBar: true,
                            allowOutsideClick: false,
                            allowEscapeKey: false,
                            didClose: () => {

                                window.location ="Admin/Student/Admission";
                            }
                        }).then((result) => {
                            if (result.isConfirmed) {

                                window.location = "Admin/Student/Admission";
                            }
                        });

                    } else {
                        Swal.fire('Error', res.message, 'error');
                    }
                } catch (err) {
                    Swal.fire('Error', err.message || "Something went wrong", 'error');
                } finally {
                    $btn.removeClass("pe-none").html("SAVE");
                }
            }
        });
    });


    $('#filter-form').on('submit', function (e) {
        e.preventDefault();



        GetSearchTableData(this);

    });

});

async function handleInstituteTypeOnFilterChange(inst, $form) {

    if (!$form || !$form.length) return;

    const $semWrapper = $form.find('#sem');
    const $branchSelect = $form.find('.ims-branch');
    const $groupSec = $form.find('.ims-groupSec');
    const $semesterId = $form.find('#Semester_ID');
    const $semester = $form.find('#Semester');


    if ($groupSec.length) {

        $groupSec
            .empty()
            .append('<option value="">-- Select --</option>')

            .trigger('change');
    }



    if (!inst) {
        $semWrapper.removeClass('d-none');
        return;
    }

    const res = await new IMSClient().request(
        '/DropDownList/GetBindList',
        'POST',
        { InId: inst, Action: 'GetInstituteType' },
        true
    );

    const type = res?.result?.[0]?.value || '';

    $semesterId.val('').removeAttr('required');


    if (type === 'School') {

        $semWrapper.addClass('d-none');

        $branchSelect
            .attr('data-action', 'Groups')
            .attr('data-bind', 'ims-groupSec');

        $form.find('#layisLateral').addClass('d-none');

        $form.find('#lblprogram')
            .html('Class <span class="text-danger">*</span>');
        $form.find('#lblprogram2').text('Class');

        $form.find('#lblbranch')
            .html('Section <span class="text-danger">*</span>');
        $form.find('#lblbranch2').text('Section');

    } else {

        $semesterId.attr('required', true);


        $branchSelect
            .removeAttr('data-action')
            .removeAttr('data-bind');

        $semWrapper.removeClass('d-none');

        $form.find('#layisLateral').removeClass('d-none');

        $form.find('#lblprogram')
            .html('Course <span class="text-danger">*</span>');
        $form.find('#lblprogram2').text('Course');

        $form.find('#lblbranch')
            .html('Branch <span class="text-danger">*</span>');
        $form.find('#lblbranch2').text('Branch');
    }
}


async function GetRegistration(RegID) {
    const sesId = window.currentUser?.ActiveSession;
    const UserId = window.currentUser?.UserId;

    try {
        const response = await new IMSClient().request("/Student/Registration", "POST", {
            Action: 'RegByID',
            RegNo: RegID,
            CreateBy: UserId,

        }, true);

        const resultData = response.result ?? [];

        console.log(resultData)
        if (resultData.length > 0) {
            bindStudentData(resultData[0]);
        }
    } catch (error) {
        Swal.fire('Error', error.message || "Error loading data", 'error');
    }
}
function bindStudentData(data) {
    if (!data) return;


    $("#RegNo").val(data.regID || "").attr("readonly", true);
    $("#layRegId").text("Registration Id: " + data.regID || "");
    $("#FirstName").val(data.firstName || "");
    $("#MiddleName").val(data.middleName || "");
    $("#LastName").val(data.lastName || "");

    SetDateWithDatePicker('DOB', data.studDOB);


    $("#StudentMobile").val(data.studMobile || "");
    $("#StudentEmail").val(data.studEmail || "");
    $("#AAdharCardNo").val(data.studAadhar || "");
    $("#StudPancard").val(data.studPancard || "");
    $("#Gender").val(data.gender || "");


    $("#Category").val(data.category || "");
    $("#NameF").val(data.fatherName || "");
    $("#MobileF").val(data.fatherMob || "");
    $("#EmailF").val(data.fatherEmail || "");

    $("#NameM").val(data.motherName || "");
    $("#MobileM").val(data.motherMob || "");
    $("#EmailM").val(data.motherEmail || "");


    $("#PerAddress").val(data.currAddress || "");
    $("#PerCity").val(data.city || "");
    $("#PerDistrict").val(data.district || "");
    $("#PerPincode").val(data.zipcode || "");


    $("#Institute_ID").val(data.instituteId).trigger("change");
    $("#PerCountry").val(data.countryID).trigger("change");


    setTimeout(() => {
        $("#PerState").val(data.state || "");
        $("#Course_ID").val(data.program).trigger("change");

        setTimeout(() => {
            $("#Branch_ID").val(data.branch).trigger("change");
        }, 2000);
    }, 1000);
}

async function GetSearchTableData(formData) {
    const $btn = $('#btnSearch');
    const originalHtml = $btn.html();

    $btn.prop('disabled', true).html(`
        <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
        Loading...
    `);

    try {

        const fd = new FormData(formData);
        fd.append('Mode', 'StudentSearchDetail');
        fd.append('Gender', $('#GenderFilter').val());
        fd.append('Category', $('#CategoryFilter').val());
        const response = await new IMSClient().request("/Student/Search", "POST", fd, true);
        console.log(response.result)

        convertArraydm(response.result);
        $btn.prop('disabled', false).html(originalHtml);


    } catch (error) {
        console.log(error)
        $('#Grideview').html('<p class="text-center text-danger">Error loading data</p>');
        $btn.prop('disabled', false).html(originalHtml);
    }
}

function convertArraydm(data) {

    const arr = [];


    var canedit = window.userRole && window.userRole.isEdit === true;
    var canreset = window.userRole && window.userRole.isExt1 === true;
    var canlogin = window.userRole && window.userRole.isActive === true;
    data.forEach((item, index) => {

        /* ================= ACTION DROPDOWN ================= */

        let actionmenu = `
        <div class="dropdown text-center">
            <button class="btn btn-sm btn-outline-primary dropdown-toggle"
                type="button"
                data-bs-toggle="dropdown"
                aria-expanded="false">
                <i class="ti ti-settings"></i>
            </button>
            <ul class="dropdown-menu">
        `;

        if (canedit) {
            actionmenu += `
                <li>
                    <a class="dropdown-item"
                       href="updatestuddetails?token=${item.hash}"
                       target="_blank">
                        <i class="ti ti-edit me-2"></i> Update Details
                    </a>
                </li>
            `;
        }

        if (canlogin) {
            actionmenu += `
                <li>
                    <a class="dropdown-item"
                       href="javascript:void(0)"
                       onclick="toggleStudentLogin('${item.adm_admissionno}', ${item.loginStatus})">
                        <i class="ti ti-lock me-2"></i>
                        ${item.loginStatus === 1 ? 'Disable Login' : 'Enable Login'}
                    </a>
                </li>
            `;
        }

        if (canreset) {
            actionmenu += `
                <li>
                    <a class="dropdown-item text-warning reset-btn"
                       href="javascript:void(0)"
                       data-item="${encodeURIComponent(JSON.stringify(item))}">
                        <i class="ti ti-refresh me-2"></i> Password Reset
                    </a>
                </li>
            `;
        }

        actionmenu += `
            </ul>
        </div>
        `;

        /* ================= ROW DATA ================= */

        arr.push([
            `<b class="text-primary">${index + 1}</b>`,

            `<b class="text-primary">${item.student_name || 'N/A'}</b>`,

            `<span class="badge bg-primary px-3 py-2">
                <i class="ti ti-user me-1"></i>
                ${item.adm_admissionno || 'N/A'}
             </span>`,

            item.adm_rollno || '—',

            item.father_name || 'N/A',

            item.mother_name || 'N/A',

            `<span class="badge bg-info px-3 py-2">
                ${item.batch_Name || 'N/A'}
             </span>`,

            `<span class="badge bg-secondary px-3 py-2">
                ${item.course_Name || 'N/A'}
             </span>`,

            item.branch_Name || 'N/A',

            `<span class="badge bg-warning text-dark px-3 py-2">
                <i class="ti ti-phone me-1"></i>
                ${item.studentMobile || 'N/A'}
             </span>`,

            `<span class="text-muted small">
                <i class="ti ti-calendar me-1"></i>
                ${item.admissionDate || 'N/A'}
             </span>`,

            `<span class="badge bg-dark px-3 py-2">
                ${item.semester_Name || 'N/A'}
             </span>`,

            item.status === "Active"
                ? `<span class="badge bg-success px-3 py-2">
                       <i class="ti ti-check me-1"></i> Active
                   </span>`
                : `<span class="badge bg-danger px-3 py-2">
                       <i class="ti ti-x me-1"></i> ${item.status || 'N/A'}
                   </span>`,

            actionmenu
        ]);
    });

    datasetstudenttable(arr);
}
function datasetstudenttable(dataset) {

    $('#grideview').html(`
        <table class="display table table-sm table-striped table-bordered w-100"
               id="studenttable"></table>
    `);

    $('#studenttable').DataTable({
        data: dataset,
        paging: true,
        searching: false,
        pageLength: 10,
        lengthChange: false,
        info: true,
        autoWidth: false,
        scrollX: true,
        scrollCollapse: true,
        destroy: true,
        responsive: true,
        order: [],
        columns: [
            { title: "Sr No" },
            { title: "Student Name" },
            { title: "Admission No" },
            { title: "Roll No" },
            { title: "Father's Name" },
            { title: "Mother's Name" },
            { title: "Batch" },
            { title: "Program" },
            { title: "Branch" },
            { title: "Mobile" },
            { title: "Admission Date" },
            { title: "Semester" },
            { title: "Status" },
            { title: "Actions", className: "text-center" }
        ]
    });
}

async function submitResetPassword() {
    const resetOption = $('input[name="resetOption"]:checked').val();

    var admNo = $("#hdAdmissionNo").val();
    var pass = $("#newPassword").val();
    var confirm = $("#confirmPassword").val();
    var sendMail = $("#sendMail").is(":checked");
    if (resetOption === 'RESET') {
        $("#passwordError").html("");
        $("#passwordError").removeClass("text-danger text-success").addClass("text-danger");
        $(".password-check").removeClass("text-success text-danger").addClass("text-muted");
        if (!pass) {
            $("#passwordError").html('<i class="ti ti-alert-circle me-1"></i> Enter password');
            return;
        }
        if (pass.length < 6) {
            $("#passwordError").html('<i class="ti ti-alert-circle me-1"></i> Password must be at least 6 characters');
            $("#lengthCheck").removeClass("text-muted").addClass("text-danger");
            return;
        } else {
            $("#lengthCheck").removeClass("text-muted text-danger").addClass("text-success");
        }

        if (pass !== confirm) {
            $("#passwordError").html('<i class="ti ti-alert-circle me-1"></i> Password and confirm password do not match');
            $("#matchCheck").removeClass("text-muted").addClass("text-danger");
            return;
        } else {
            $("#matchCheck").removeClass("text-muted text-danger").addClass("text-success");
        }

        if (!/\d/.test(pass)) {
            $("#passwordError").html('<i class="ti ti-alert-circle me-1"></i> Password must contain at least one number');
            $("#numberCheck").removeClass("text-muted").addClass("text-danger");
            return;
        } else {
            $("#numberCheck").removeClass("text-muted text-danger").addClass("text-success");
        }

        if (!/[a-zA-Z]/.test(pass)) {
            $("#passwordError").html('<i class="ti ti-alert-circle me-1"></i> Password must contain at least one letter');
            $("#letterCheck").removeClass("text-muted").addClass("text-danger");
            return;
        } else {
            $("#letterCheck").removeClass("text-muted text-danger").addClass("text-success");
        }
    }
    var request = {
        UserId: admNo,
        Password: pass,
        IsConfirmMailSend: sendMail,
        Mode: resetOption
    };

    $("#passwordError").html('<div class="spinner-border spinner-border-sm me-2"></div> Processing...');
    $("#passwordError").removeClass("text-danger").addClass("text-info");
    const res = await new IMSClient().request('/Auth/ResetPassword', 'POST', request, true);
    if (res.statusCode === 200) {
        $("#passwordError").html('<i class="ti ti-circle-check me-1"></i> Password reset successfully');
        $("#passwordError").removeClass("text-danger text-info").addClass("text-success");
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: res.message || 'Password has been reset successfully',
            confirmButtonText: 'OK',
            confirmButtonColor: '#3085d6'
        });


        setTimeout(function () {
            $("#resetPasswordModal").modal("hide");
            $("#newPassword").val("");
            $("#confirmPassword").val("");
            $("#sendMail").prop("checked", false);
            $(".password-check").removeClass("text-success text-danger").addClass("text-muted");
            $("#passwordError").html("");
        }, 1500);

    } else {
        $("#passwordError").html('<i class="ti ti-alert-circle me-1"></i> ' + (res.message || "Failed to reset password"));
        $("#passwordError").removeClass("text-info").addClass("text-danger");
    }

}

async function toggleStudentLogin(userId, status) {

    if (!userId) {
        ShowNotification("error", "UserId is required");
        return false;
    }

    const nextStatus = status === 1 ? '2' : '1';

    const actionText = status === 1 ? "Disable" : "Enable";

    const result = await Swal.fire({
        title: actionText + " Login?",
        text: "Are you sure you want to " + actionText.toLowerCase() + " login for this user?",
        icon: "question",
        showCancelButton: true,
        confirmButtonText: "Yes, " + actionText,
        cancelButtonText: "Cancel",
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33"
    });

    if (!result.isConfirmed) {
        return false;
    }

    const request = {
        UserId: userId,
        Type: nextStatus,
        Mode: 'UpdateStatus'
    };

    try {

        const res = await new IMSClient().request(
            '/Auth/UpdateLoginStatus',
            'POST',
            request,
            true
        );

        if (res.statusCode === 200) {

            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: res.message || 'Login status updated successfully',
                confirmButtonText: 'OK'
            });

            $('#filter-form')[0].submit()

            return true;

        } else {

            Swal.fire({
                icon: 'warning',
                title: 'Warning',
                text: res.message || 'Failed to update login status',
                confirmButtonText: 'OK'
            });

            return false;
        }

    } catch (error) {

        console.error("UpdateLoginStatus Error:", error);

        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Something went wrong while updating status',
            confirmButtonText: 'OK'
        });

        return false;
    }
}