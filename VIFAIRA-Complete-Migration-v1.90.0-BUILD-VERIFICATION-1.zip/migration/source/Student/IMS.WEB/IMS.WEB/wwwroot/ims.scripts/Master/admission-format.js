﻿var dataTable = null;

$(document).ready(function () {
    loadFormats();

    $('#InstituteFilter, #Institute').on('change', function () {
        var instituteId = $(this).val();
        if (instituteId) {
            if ($(this).attr('id') === 'InstituteFilter') {
                loadFormats();
            }
        }
    });

    $('#CourseFilter').on('change', function () {
        loadFormats();
    });

    $('#BranchFilter').on('change', function () {
        loadFormats();
    });

    $('#statusFilter').on('change', function () {
        if (!validateInstituteSelection()) {
            ShowNotification('warning', 'Please select an institute first');
            $('#InstituteFilter').focus();
            return;
        }
        loadFormats();
    });

    $('#filterBtn').click(function () {
        if (!validateInstituteSelection()) {
            ShowNotification('warning', 'Please select an institute first');
            $('#InstituteFilter').focus();
            return;
        }
        loadFormats();
    });

    $('#searchText').keypress(function (e) {
        if (e.which == 13) {
            if (!validateInstituteSelection()) {
                ShowNotification('warning', 'Please select an institute first');
                $('#InstituteFilter').focus();
                return;
            }
            loadFormats();
        }
    });

    $('#selectAll').change(function () {
        $('.format-checkbox').prop('checked', this.checked);
    });

    $('#saveFormatBtn').click(function () {
        if (!validateFormInstitute()) {
            ShowNotification('warning', 'Please select an institute');
            $('#Institute').focus();
            return;
        }
        if (!$('#pattern').val()) {
            ShowNotification('warning', 'Pattern is required');
            $('#pattern').focus();
            return;
        }
        if (!$('#instituteValue').val()) {
            ShowNotification('warning', 'Institute Value is required');
            $('#instituteValue').focus();
            return;
        }
        var isEdit = $('#editFormatId').val() != '0' && $('#editFormatId').val() != '';
        var mode = isEdit ? 'UPDATE' : 'INSERT';
        saveFormat(mode);
    });

    $('#addFormatModal').on('hidden.bs.modal', function () {
        resetForm();
    });

    $('#testGenerateBtn').click(function () {
        testFormatGeneration();
    });

    $(document).on('click', '.pattern-tag', function (e) {
        e.preventDefault();
        var tag = $(this).data('tag');
        if (tag) {
            insertPattern(tag);
        }
    });

    $(document).on('click', '.action-item', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var action = $(this).data('action');
        var id = $(this).data('id');
        var status = $(this).data('status');
        switch (action) {
            case 'edit':
                editFormat(id);
                break;
            case 'view':
                viewFormat(id);
                break;
            case 'test':
                testFormat(id);
                break;
            case 'toggle':
                toggleFormatStatus(id, status);
                break;
            case 'delete':
                deleteFormat(id);
                break;
            default:
                console.warn('Unknown action:', action);
        }
    });
});

function validateInstituteSelection() {
    var instituteId = $('#InstituteFilter').val();
    if (!instituteId || instituteId === '') {
        $('#InstituteFilter').addClass('is-invalid');
        return false;
    } else {
        $('#InstituteFilter').removeClass('is-invalid');
        return true;
    }
}

function validateFormInstitute() {
    var instituteId = $('#Institute').val();
    if (!instituteId || instituteId === '') {
        $('#Institute').addClass('is-invalid');
        return false;
    } else {
        $('#Institute').removeClass('is-invalid');
        return true;
    }
}

function loadFormats() {
    if (!validateInstituteSelection()) {
        showEmptyStateWithMessage('Please select an institute to view formats');
        updateSummaryCounts([]);
        $('#totalRecords').text('0');
        $('#showingCount').text('0');
        return;
    }

    var formData = new FormData();
    formData.append('Mode', 'LIST');
    formData.append('Institute_ID', $('#InstituteFilter').val() || '');
    formData.append('FormatID', '');
    formData.append('IsActive', $('#statusFilter').val()=="1" || '');
    formData.append('SearchText', $('#searchText').val() || '');
    formData.append('Course_ID', $('#CourseFilter').val() || '');
    formData.append('Branch_ID', $('#BranchFilter').val() || '');

    $('#formatTableBody').html(getLoadingState(6));
    showEmptyState();
    updateSummaryCounts([]);
    $('#totalRecords').text('0');
    $('#showingCount').text('0');
    destroyDataTable();
    new IMSClient().request('/master/AdmissionFormat', 'POST', formData, true)
        .then(function (res) {
            if (res.statusCode === 200 && res.result && res.result.length > 0) {
                renderFormatsTable(res.result);
                updateSummaryCounts(res.result);
                $('#totalRecords').text(res.result.length);
                $('#showingCount').text(res.result.length);
                initializeDataTable();
            } else {
                showEmptyState();
                updateSummaryCounts([]);
                $('#totalRecords').text('0');
                $('#showingCount').text('0');
                destroyDataTable();
            }
        })
        .catch(function (err) {
            showEmptyState();
            ShowNotification('error', typeof err === 'string' ? err : 'Failed to load formats');
            updateSummaryCounts([]);
            $('#totalRecords').text('0');
            $('#showingCount').text('0');
            destroyDataTable();
        });
}

function renderFormatsTable(formats) {
    var html = '';
    $.each(formats, function (index, item) {
        var statusBadge = item.isActive == true ?
            '<span class="badge bg-success-subtle text-success-emphasis border border-success-subtle"><i class="ti ti-check me-1"></i>Active</span>' :
            '<span class="badge bg-danger-subtle text-danger-emphasis border border-danger-subtle"><i class="ti ti-ban me-1"></i>Inactive</span>';
        var configHtml = '<div class="d-flex flex-wrap gap-1">' +
            '<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle px-2">Seq:' + (item.sequenceLength || 3) + '</span>' +
            '<span class="badge bg-info-subtle text-info-emphasis border border-info-subtle px-2">Year:' + (item.yearDigits || 2) + '</span>' +
            (item.separator ? '<span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle px-2">Sep:' + item.separator + '</span>' : '') +
            (item.resetDaily == true ? '<span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle px-2">Daily Reset</span>' : '') +
            '</div>';
        var formatTypeBadge = '';
        if (item.formatType === 'Default') {
            formatTypeBadge = '<span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle">Default</span>';
        } else if (item.formatType === 'Course Specific') {
            formatTypeBadge = '<span class="badge bg-info-subtle text-info-emphasis border border-info-subtle">Course</span>';
        } else if (item.formatType === 'Branch Specific') {
            formatTypeBadge = '<span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle">Branch</span>';
        } else if (item.formatType === 'Course & Branch Specific') {
            formatTypeBadge = '<span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle">Course+Branch</span>';
        }
        var lateralBadge = item.isLateral == true ?
            '<span class="badge bg-info-subtle text-info-emphasis border border-info-subtle ms-1">Lateral</span>' :
            '';
        var formatName = item.formatName || 'Format-' + item.formatID;
        var courseDisplay = item.courseName || item.courseId || 'N/A';
        var branchDisplay = item.branchName || item.branchId || 'N/A';
        html += '<tr>' +
            '<td class="ps-3">' +
            '<input type="checkbox" class="form-check-input format-checkbox" value="' + item.formatID + '">' +
            '</td>' +
            '<td>' +
            '<div class="d-flex align-items-center">' +
            '<div class="bg-primary-subtle rounded-circle p-2 me-2">' +
            '<i class="ti ti-id text-primary"></i>' +
            '</div>' +
            '<div>' +
            '<h6 class="mb-0 fw-semibold text-dark">' + escapeHtml(formatName) + '</h6>' +
            '<small class="text-muted">' + formatTypeBadge + lateralBadge + '</small>' +
            '<div class="small text-muted mt-1">' +
            '<span class="badge  text-dark border me-1">Course: ' + escapeHtml(courseDisplay) + '</span>' +
            '<span class="badge  text-dark border">Branch: ' + escapeHtml(branchDisplay) + '</span>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</td>' +
            '<td>' +
            '<code class=" rounded px-2 py-1 border">' + escapeHtml(item.pattern || 'N/A') + '</code>' +
            '<div class="small text-muted mt-1">Sample: ' + escapeHtml(item.sampleNumber || 'N/A') + '</div>' +
            '</td>' +
            '<td>' + configHtml + '</td>' +
            '<td class="text-center">' + statusBadge + '</td>' +
            '<td class="text-center">' +
            '<div class="dropdown">' +
            '<button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">' +
            '<i class="ti ti-dots-vertical"></i>' +
            '</button>' +
            '<ul class="dropdown-menu dropdown-menu-end">' +
            '<li><a class="dropdown-item action-item" href="javascript:void(0)" data-action="edit" data-id="' + item.formatID + '">' +
            '<i class="ti ti-edit me-2"></i>Edit</a></li>' +
            '<li><a class="dropdown-item action-item" href="javascript:void(0)" data-action="view" data-id="' + item.formatID + '">' +
            '<i class="ti ti-eye me-2"></i>View</a></li>' +
            '<li><a class="dropdown-item action-item" href="javascript:void(0)" data-action="test" data-id="' + item.formatID + '">' +
            '<i class="ti ti-test-pipe me-2"></i>Test</a></li>' +
            '<li><hr class="dropdown-divider"></li>' +
            '<li><a class="dropdown-item action-item" href="javascript:void(0)" data-action="toggle" data-id="' + item.formatID + '" data-status="' + item.isActive + '">' +
            '<i class="ti ti-' + (item.isActive == true ? 'ban' : 'check') + ' me-2"></i>' + (item.isActive == true ? 'Deactivate' : 'Activate') + '</a></li>' +
            '<li><a class="dropdown-item action-item text-danger" href="javascript:void(0)" data-action="delete" data-id="' + item.formatID + '">' +
            '<i class="ti ti-trash me-2"></i>Delete</a></li>' +
            '</ul>' +
            '</div>' +
            '</td>' +
            '</tr>';
    });
    $('#formatTableBody').html(html);
}

function initializeDataTable() {
    if (typeof $.fn.DataTable !== 'undefined') {
        destroyDataTable();
        dataTable = $('#formatTable').DataTable({
            paging: true,
            searching: false,
            ordering: true,
            info: true,
            pageLength: 10,
            lengthMenu: [10, 25, 50, 100],
            responsive: true,
            autoWidth: false,
            columnDefs: [
                { orderable: false, targets: [0, 5] },
                { className: 'text-center', targets: [4, 5] }
            ],
            language: {
                emptyTable: 'No formats available',
                info: 'Showing _START_ to _END_ of _TOTAL_ formats',
                infoEmpty: 'Showing 0 to 0 of 0 formats',
                infoFiltered: '(filtered from _MAX_ total formats)',
                lengthMenu: 'Show _MENU_ formats',
                loadingRecords: 'Loading...',
                processing: 'Processing...',
                search: 'Search:',
                zeroRecords: 'No matching formats found',
                paginate: {
                    first: '<i class="ti ti-chevrons-left"></i>',
                    last: '<i class="ti ti-chevrons-right"></i>',
                    next: '<i class="ti ti-chevron-right"></i>',
                    previous: '<i class="ti ti-chevron-left"></i>'
                }
            },
            drawCallback: function () {
                $('.dataTables_paginate').addClass('pagination-sm');
                $('.dataTables_length').addClass('d-none');
                $('.dataTables_filter').addClass('d-none');
                $('.dataTables_info').addClass('text-muted small');
                $('#pagination').html($('.dataTables_paginate'));
            }
        });
        $('#pagination').html($('.dataTables_paginate'));
    }
}

function destroyDataTable() {
    if (dataTable !== null) {
        try {
            dataTable.destroy();
        } catch (e) {
            console.log('DataTable destroy error:', e);
        }
        dataTable = null;
    }
}

function showEmptyStateWithMessage(message) {
    destroyDataTable();
    $('#formatTableBody').html(
        '<tr><td colspan="6" class="text-center py-5">' +
        '<div class="text-muted">' +
        '<i class="ti ti-building fs-1 mb-3 d-block"></i>' +
        '<p class="mb-2 fw-medium">' + (message || 'No data available') + '</p>' +
        '<small class="text-muted">Please select an institute to continue</small>' +
        '</div>' +
        '</td></tr>'
    );
}

function showEmptyState() {
    destroyDataTable();
    $('#formatTableBody').html(
        '<tr><td colspan="6" class="text-center py-5">' +
        '<div class="text-muted">' +
        '<i class="ti ti-database-off fs-1 mb-3 d-block"></i>' +
        '<p class="mb-2 fw-medium">No admission formats found</p>' +
        '<small class="text-muted">Click "New Format" to create your first format</small>' +
        '</div>' +
        '</td></tr>'
    );
}

function updateSummaryCounts(formats) {
    var active = 0,
        inactive = 0,
        lateral = 0;
    $.each(formats, function (index, item) {
        if (item.isActive == true) active++;
        else inactive++;
        if (item.isLateral == true) lateral++;
    });
    $('#activeCount').text(active);
    $('#inactiveCount').text(inactive);
    $('#totalCount').text(formats.length);
    $('#lateralCount').text(lateral);
}

function saveFormat(mode) {
    var formatId = $('#editFormatId').val();
    var formData = new FormData();
    formData.append('Mode', mode);
    formData.append('Institute_ID', $('#Institute').val() || '');
    formData.append('FormatID', formatId || '');
    formData.append('FormatName', $('#formatName').val() || '');
    formData.append('InstituteValue', $('#instituteValue').val() || '');
    formData.append('Course_ID', $('#Course').val() || '');
    formData.append('CourseValue', $('#courseValue').val() || '');
    formData.append('Branch_ID', $('#Branch').val() || '');
    formData.append('BranchValue', $('#branchValue').val() || '');
    formData.append('Pattern', $('#pattern').val() || '');
    formData.append('YearValue', $('#yearValue').val() || '');
    formData.append('YearDigits', $('#yearDigits').val() || '2');
    formData.append('Separator', $('#separator').val() || '');
    formData.append('StartSequence', $('#startSequence').val() || '1');
    formData.append('ResetDaily', $('#resetDaily').is(':checked') ? 'true' : 'false');
    formData.append('SequenceLength', $('#sequenceLength').val() || '3');
    formData.append('MaxSequenceLength', $('#maxSequenceLength').val() || '6');
    formData.append('isLateral', $('#isLateral').is(':checked') ? 'true' : 'false');
    formData.append('IsActiveInput', $('#isActive').is(':checked'));
    formData.append('CreatedBy', 'admin');
    formData.append('UpdatedBy', 'admin');

    new IMSClient().request('/master/AdmissionFormat', 'POST', formData, true)
        .then(function (res) {
            if (res.statusCode === 200) {
                ShowNotification('success', mode === 'INSERT' ? 'Format added successfully!' : 'Format updated successfully!');
                $('#addFormatModal').modal('hide');
                resetForm();
                loadFormats();
            } else {
                ShowNotification('error', res.message || 'Failed to save format');
            }
        })
        .catch(function (err) {
            ShowNotification('error', typeof err === 'string' ? err : 'Failed to save format');
        });
}

function resetForm() {
    $('#addFormatForm')[0].reset();
    $('#addFormatForm').removeClass('was-validated');
    $('#editFormatId').val('0');
    $('#modalTitleBadge').html('<i class="ti ti-plus me-1"></i>New Format');
    $('#resetDaily').prop('checked', false);
    $('#isLateral').prop('checked', false);
    $('#isActive').prop('checked', true);
    $('#sequenceLength').val(3);
    $('#startSequence').val(1);
    $('#maxSequenceLength').val(6);
    $('#yearDigits').val(2);
    $('#separator').val('');
    $('#yearValue').val('');
    $('#formatName').val('');
    $('#instituteValue').val('');
    $('#courseValue').val('');
    $('#branchValue').val('');
    $('#pattern').val('');
    $('#testInputId').val('');
    $('#testOutputId').val('');
}

function editFormat(formatId) {
    var formData = new FormData();
    formData.append('Mode', 'LIST');
    formData.append('Institute_ID', $('#InstituteFilter').val() || '');
    formData.append('FormatID', formatId);

    new IMSClient().request('/master/AdmissionFormat', 'POST', formData, true)
        .then(function (res) {


            if (res.statusCode === 200 && res.result && res.result.length > 0) {
                var item = res.result[0];
                $('#editFormatId').val(item.formatID);
                $('#modalTitleBadge').html('<i class="ti ti-edit me-1"></i>Edit Format');
                $('#formatName').val(item.formatName || '');
                $('#instituteValue').val(item.instituteValue || '');
                $('#courseValue').val(item.courseValue || '');
                $('#branchValue').val(item.branchValue || '');
                $('#pattern').val(item.pattern || '');
                $('#yearValue').val(item.yearValue || '');
                $('#yearDigits').val(item.yearDigits || '2');
                $('#separator').val(item.separator || '');
                $('#startSequence').val(item.startSequence || '1');
                $('#resetDaily').prop('checked', item.resetDaily == true);
                $('#sequenceLength').val(item.sequenceLength || '3');
                $('#maxSequenceLength').val(item.maxSequenceLength || '6');
                $('#isLateral').prop('checked', item.isLateral == true);
                $('#isActive').prop('checked', item.isActive == true);
                if (item.instituteId) {
                    $('#Institute').val(item.instituteId).trigger('change');
                    setTimeout(function () {
                        if (item.courseId) {
                            $('#Course').val(item.courseId).trigger('change');
                        }
                        setTimeout(function () {
                            if (item.branchId) {
                                $('#Branch').val(item.branchId).trigger('change');
                            }
                        }, 300);
                    }, 300);
                }
                $('#addFormatModal').modal('show');
            } else {
                ShowNotification('error', 'Format not found');
            }
        })
        .catch(function (err) {
            ShowNotification('error', typeof err === 'string' ? err : 'Failed to load format');
        });
}

function viewFormat(formatId) {
    var formData = new FormData();
    formData.append('Mode', 'LIST');
    formData.append('Institute_ID', $('#InstituteFilter').val() || '');
    formData.append('FormatID', formatId);

    new IMSClient().request('/master/AdmissionFormat', 'POST', formData, true)
        .then(function (res) {
            if (res.statusCode === 200 && res.result && res.result.length > 0) {
                var item = res.result[0];
                var detailsHtml = '<div class="table-responsive">' +
                    '<table class="table table-sm table-bordered">' +
                    '<tr><td class="fw-bold" style="width:150px;">Format ID</td><td>' + item.formatID + '</td></tr>' +
                    '<tr><td class="fw-bold">Format Name</td><td>' + escapeHtml(item.formatName || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Institute</td><td>' + escapeHtml(item.instituteId || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Institute Value</td><td>' + escapeHtml(item.instituteValue || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Course</td><td>' + escapeHtml(item.courseName || item.courseId || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Course Value</td><td>' + escapeHtml(item.courseValue || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Branch</td><td>' + escapeHtml(item.branchName || item.branchId || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Branch Value</td><td>' + escapeHtml(item.branchValue || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Pattern</td><td><code>' + escapeHtml(item.pattern || 'N/A') + '</code></td></tr>' +
                    '<tr><td class="fw-bold">Sample Number</td><td><code>' + escapeHtml(item.sampleNumber || 'N/A') + '</code></td></tr>' +
                    '<tr><td class="fw-bold">Year Value</td><td>' + (item.yearValue || 'N/A') + '</td></tr>' +
                    '<tr><td class="fw-bold">Year Digits</td><td>' + (item.yearDigits || '2') + '</td></tr>' +
                    '<tr><td class="fw-bold">Separator</td><td>' + (item.separator || 'None') + '</td></tr>' +
                    '<tr><td class="fw-bold">Start Sequence</td><td>' + (item.startSequence || '1') + '</td></tr>' +
                    '<tr><td class="fw-bold">Sequence Length</td><td>' + (item.sequenceLength || '3') + '</td></tr>' +
                    '<tr><td class="fw-bold">Max Sequence Length</td><td>' + (item.maxSequenceLength || '6') + '</td></tr>' +
                    '<tr><td class="fw-bold">Reset Daily</td><td>' + (item.resetDaily == true ? 'Yes' : 'No') + '</td></tr>' +
                    '<tr><td class="fw-bold">Lateral Entry</td><td>' + (item.isLateral == true ? 'Yes' : 'No') + '</td></tr>' +
                    '<tr><td class="fw-bold">Status</td><td>' + (item.isActive == true ? 'Active' : 'Inactive') + '</td></tr>' +
                    '<tr><td class="fw-bold">Format Type</td><td>' + escapeHtml(item.formatType || 'N/A') + '</td></tr>' +
                    (item.createdDate ? '<tr><td class="fw-bold">Created Date</td><td>' + new Date(item.createdDate).toLocaleString() + '</td></tr>' : '') +
                    (item.createdBy ? '<tr><td class="fw-bold">Created By</td><td>' + escapeHtml(item.createdBy) + '</td></tr>' : '') +
                    (item.updatedDate ? '<tr><td class="fw-bold">Updated Date</td><td>' + new Date(item.updatedDate).toLocaleString() + '</td></tr>' : '') +
                    (item.updatedBy ? '<tr><td class="fw-bold">Updated By</td><td>' + escapeHtml(item.updatedBy) + '</td></tr>' : '') +
                    '</table>' +
                    '</div>';
                ShowModal('Format Details', detailsHtml, 'Close');
            } else {
                ShowNotification('error', 'Format not found');
            }
        })
        .catch(function (err) {
            ShowNotification('error', typeof err === 'string' ? err : 'Failed to load format details');
        });
}

function toggleFormatStatus(formatId, currentStatus) {
    var newStatus = !currentStatus;
    var action = newStatus ? 'Activate' : 'Deactivate';
    if (!confirm('Are you sure you want to ' + action + ' this format?')) {
        return;
    }
    var formData = new FormData();
    formData.append('Mode', 'TOGGLE');
    formData.append('Institute_ID', $('#InstituteFilter').val() || '');
    formData.append('FormatID', formatId);
    formData.append('IsActiveInput', newStatus);
    formData.append('UpdatedBy', 'admin');

    new IMSClient().request('/master/AdmissionFormat', 'POST', formData, true)
        .then(function (res) {
            if (res.statusCode === 200) {
                ShowNotification('success', 'Format ' + action.toLowerCase() + 'd successfully!');
                loadFormats();
            } else {
                ShowNotification('error', res.message || 'Failed to ' + action.toLowerCase() + ' format');
            }
        })
        .catch(function (err) {
            ShowNotification('error', typeof err === 'string' ? err : 'Failed to ' + action.toLowerCase() + ' format');
        });
}

function deleteFormat(formatId) {
    if (!confirm('Are you sure you want to delete this format? This action cannot be undone.')) {
        return;
    }
    var formData = new FormData();
    formData.append('Mode', 'DELETE');
    formData.append('Institute_ID', $('#InstituteFilter').val() || '');
    formData.append('FormatID', formatId);
    formData.append('DeletedBy', 'admin');

    new IMSClient().request('/master/AdmissionFormat', 'POST', formData, true)
        .then(function (res) {
            if (res.statusCode === 200) {
                ShowNotification('success', 'Format deleted successfully!');
                loadFormats();
            } else {
                ShowNotification('error', res.message || 'Failed to delete format');
            }
        })
        .catch(function (err) {
            ShowNotification('error', typeof err === 'string' ? err : 'Failed to delete format');
        });
}

function testFormat(formatId) {
    var formData = new FormData();
    formData.append('Mode', 'TEST');
    formData.append('Institute_ID', $('#InstituteFilter').val() || '');
    formData.append('FormatID', formatId);

    new IMSClient().request('/master/AdmissionFormat', 'POST', formData, true)
        .then(function (res) {
            console.log(res)
            if (res.statusCode === 200 && res.result && res.result.length > 0) {
                var item = res.result[0];
                $('#testInputId').val(item.sampleNumber || '');
                $('#testOutputId').val('');
                $('#testModal').modal('show');
            } else {
                ShowNotification('error', 'Format not found');
            }
        })
        .catch(function (err) {
            ShowNotification('error', typeof err === 'string' ? err : 'Failed to load format');
        });
}

function testFormatGeneration() {
    var inputId = $('#testInputId').val();
    if (!inputId) {
        ShowNotification('warning', 'Please enter an input ID');
        return;
    }
    var generatedId = inputId + '-GEN-' + Math.floor(Math.random() * 1000);
    $('#testOutputId').val(generatedId);
    ShowNotification('success', 'ID generated successfully!');
}

function insertPattern(tag) {
    var patternInput = document.getElementById('pattern');
    if (!patternInput) {
        console.error('Pattern input not found');
        return;
    }
    var cursorPos = patternInput.selectionStart || 0;
    var text = patternInput.value;
    if (text.includes(tag)) {
        var newText = text.replace(tag, '');
        patternInput.value = newText;
        patternInput.focus();
        return;
    }
    var before = text.substring(0, cursorPos);
    var after = text.substring(cursorPos);
    var newText = before + tag + after;
    patternInput.value = newText;
    var newCursorPos = cursorPos + tag.length;
    patternInput.selectionStart = newCursorPos;
    patternInput.selectionEnd = newCursorPos;
    patternInput.focus();
}

function getLoadingState(colspan) {
    return '<tr><td colspan="' + colspan + '" class="text-center py-4">' +
        '<div class="spinner-border text-primary" role="status">' +
        '<span class="visually-hidden">Loading...</span>' +
        '</div>' +
        '<h6 class="text-muted mt-2">Loading...</h6>' +
        '</td></tr>';
}

function escapeHtml(text) {
    if (!text) return '';
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function ShowNotification(type, message) {
    if (typeof Swal !== 'undefined') {
        var icon = 'info';
        var title = 'Info';
        if (type === 'success') {
            icon = 'success';
            title = 'Success';
        } else if (type === 'error') {
            icon = 'error';
            title = 'Error';
        } else if (type === 'warning') {
            icon = 'warning';
            title = 'Warning';
        }
        Swal.fire({
            icon: icon,
            title: title,
            text: message || 'Operation completed',
            confirmButtonColor: '#0d6efd',
            confirmButtonText: 'OK'
        });
    } else {
        alert(message || 'Operation completed');
    }
}

function ShowModal(title, content, buttonText) {
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: title || 'Details',
            html: content || '',
            showCloseButton: true,
            showConfirmButton: true,
            confirmButtonText: buttonText || 'Close',
            width: '90%',
            maxWidth: '700px'
        });
    } else {
        alert(content || 'No content');
    }
}