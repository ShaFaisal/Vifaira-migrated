const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";

export async function studentRequest(operation, payload) {
  const response = await fetch(`${API_BASE}/student/${operation}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(payload ?? {})
  });
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
  if (!response.ok) {
    const error = new Error(data?.error || `Request failed (${response.status})`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}
