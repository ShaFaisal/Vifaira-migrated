import React, { Suspense, useEffect, useState } from "react";
import { Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { generatedRoutes } from "./services/generatedRoutes.js";

const TAB_KEY = "vifaira.tabs";

function Shell() {
  const location = useLocation();
  const navigate = useNavigate();
  const [tabs, setTabs] = useState(() => JSON.parse(localStorage.getItem(TAB_KEY) || "[]"));

  useEffect(() => {
    if (!tabs.some(t => t.path === location.pathname)) {
      setTabs(old => [...old, {
        path: location.pathname,
        title: location.pathname.split("/").filter(Boolean).at(-1) || "Home",
        pinned: false
      }]);
    }
  }, [location.pathname]);

  useEffect(() => localStorage.setItem(TAB_KEY, JSON.stringify(tabs)), [tabs]);

  const closeTab = path => {
    const next = tabs.filter(t => t.path !== path || t.pinned);
    setTabs(next);
    if (path === location.pathname) navigate(next.at(-1)?.path || "/");
  };

  const togglePin = path => {
    setTabs(old => old.map(t => t.path === path ? { ...t, pinned: !t.pinned } : t));
  };

  return (
    <div className="vifaira-shell">
      <aside className="vifaira-sidebar">
        <div className="brand"><span className="brand-mark">VF</span><span>VIFAIRA ERP</span></div>
        <div className="side-group"><div className="side-label">Student</div>{generatedRoutes.filter(r => r.path.startsWith("/admin/student/")).slice(0, 14).map(r => (
          <button className={`side-btn ${r.path === location.pathname ? "active" : ""}`} key={r.path} onClick={() => navigate(r.path)}>
            {r.path.split("/").at(-1)}
          </button>
        ))}</div>
      </aside>
      <main className="vifaira-main">
        <header className="vifaira-top"><span className="crumb">ERP / {location.pathname.split("/").filter(Boolean).slice(-2).join(" / ") || "Home"}</span><div className="top-actions"><button className="icon-btn" onClick={() => document.documentElement.classList.toggle("compact")}>UI</button></div></header>
        <nav className="vifaira-tabs" style={{display:"none"}}>
          {tabs.map(t => (
            <span key={t.path} className={t.path === location.pathname ? "active" : ""}>
              <button onClick={() => navigate(t.path)}>{t.title}</button>
              <button onClick={() => togglePin(t.path)}>{t.pinned ? "★" : "☆"}</button>
              <button onClick={() => closeTab(t.path)}>×</button>
            </span>
          ))}
        </nav>
        <Suspense fallback={<div>Loading…</div>}>
          <Routes>
            <Route path="/" element={<Navigate to={generatedRoutes[0]?.path || "/"} replace />} />
            {generatedRoutes.map(r => {
              const Page = React.lazy(r.component);
              return <Route key={r.path} path={r.path} element={<Page />} />;
            })}
            <Route path="*" element={<div>Route not mapped</div>} />
          </Routes>
        </Suspense>
      </main>
    </div>
  );
}

export function App() {
  return <Shell />;
}
