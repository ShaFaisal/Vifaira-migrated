import React, { useMemo, useState } from "react";
import { migrationModules } from "./migrationModules";

export default function ModuleRouteWorkbench({ initialModule = "" }) {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(initialModule || migrationModules[0]?.key || "");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return migrationModules;
    return migrationModules.filter((item) =>
      item.name.toLowerCase().includes(q) || item.key.includes(q)
    );
  }, [query]);

  const current = migrationModules.find((item) => item.key === active) ?? null;

  return (
    <section className="migration-module-workbench">
      <div className="migration-module-workbench__toolbar">
        <div>
          <div className="migration-module-workbench__eyebrow">VIFAIRA ERP</div>
          <h2 className="migration-module-workbench__title">Module Workbench</h2>
        </div>
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search modules..."
          aria-label="Search modules"
        />
      </div>

      <div className="migration-module-workbench__body">
        <aside className="migration-module-workbench__nav" aria-label="Modules">
          {filtered.map((item) => (
            <button
              key={item.key}
              type="button"
              className={item.key === active ? "is-active" : ""}
              onClick={() => setActive(item.key)}
            >
              <span>{item.name}</span>
              <small>{item.routeCount}</small>
            </button>
          ))}
        </aside>

        <main className="migration-module-workbench__content">
          {current ? (
            <>
              <div className="migration-module-workbench__header">
                <div>
                  <span className="migration-module-workbench__label">Module</span>
                  <h3>{current.name}</h3>
                </div>
                <span className="migration-module-workbench__status">
                  {current.backendStatus}
                </span>
              </div>

              <div className="migration-module-workbench__grid">
                <article>
                  <strong>{current.routeCount}</strong>
                  <span>Backend routes</span>
                </article>
                <article>
                  <strong>{current.frontendFiles?.length ?? 0}</strong>
                  <span>Related UI sources</span>
                </article>
              </div>

              <div className="migration-module-workbench__notice">
                Business behavior is intentionally not fabricated. This shell only
                exposes source-backed module metadata until each endpoint has a
                verified request/response contract.
              </div>
            </>
          ) : (
            <div className="migration-module-workbench__empty">
              No module matches your search.
            </div>
          )}
        </main>
      </div>
    </section>
  );
}
