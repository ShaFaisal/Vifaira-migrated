import React, { useMemo, useState } from "react";
import { moduleRouteManifest } from "./moduleRouteManifest";

function normalizeModule(value) {
  return String(value || "").trim().toLowerCase();
}

export default function MigratedModulePage({ moduleName }) {
  const module = useMemo(() => {
    const key = normalizeModule(moduleName);
    return moduleRouteManifest.find((item) => normalizeModule(item.module) === key) || null;
  }, [moduleName]);

  const [search, setSearch] = useState("");

  const routes = useMemo(() => {
    if (!module) return [];
    const q = search.trim().toLowerCase();
    if (!q) return module.routeNames;
    return module.routeNames.filter(([method, path]) =>
      method.toLowerCase().includes(q) || path.toLowerCase().includes(q)
    );
  }, [module, search]);

  if (!module) {
    return <div className="p-4 text-body-secondary">Module not found.</div>;
  }

  return (
    <div className="container-fluid py-3">
      <div className="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <div>
          <div className="small text-body-secondary text-uppercase">Migrated module</div>
          <h1 className="h4 mb-0">{module.module}</h1>
        </div>
        <span className="badge text-bg-secondary">{module.routes} routes</span>
      </div>

      <div className="card border-0 shadow-sm">
        <div className="card-body">
          <div className="row g-2 mb-3">
            <div className="col-12 col-md-5">
              <input
                className="form-control"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search endpoint..."
              />
            </div>
          </div>

          <div className="table-responsive">
            <table className="table table-sm align-middle mb-0">
              <thead>
                <tr><th>Method</th><th>Endpoint</th><th>Status</th></tr>
              </thead>
              <tbody>
                {routes.map(([method, path]) => (
                  <tr key={`${method}:${path}`}>
                    <td><span className="badge text-bg-light border">{method}</span></td>
                    <td><code>{path}</code></td>
                    <td>
                      <span className="badge text-bg-warning">
                        Contract verification pending
                      </span>
                    </td>
                  </tr>
                ))}
                {!routes.length && (
                  <tr><td colSpan="3" className="text-center text-body-secondary py-4">
                    No endpoint matches the search.
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>

          {module.placeholderSignals > 0 && (
            <div className="alert alert-warning mt-3 mb-0">
              {module.placeholderSignals} backend placeholder signal(s) remain.
              Business behavior is not marked complete until the source-backed
              request, response, validation and persistence contract is verified.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
