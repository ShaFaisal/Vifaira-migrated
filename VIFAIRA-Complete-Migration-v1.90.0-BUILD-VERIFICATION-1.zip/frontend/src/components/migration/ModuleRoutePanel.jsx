import React, { useMemo } from "react";
import { moduleRouteManifest } from "./moduleRouteManifest";

export function ModuleRoutePanel({ moduleName }) {
  const module = useMemo(
    () => moduleRouteManifest.find(
      (item) => item.module.toLowerCase() === String(moduleName || "").toLowerCase()
    ),
    [moduleName]
  );

  if (!module) return <div className="migration-route-panel__empty">Module not found.</div>;

  return (
    <div className="migration-route-panel">
      <div className="migration-route-panel__summary">
        <strong>{module.routes}</strong>
        <span>confirmed routes</span>
      </div>
      <div className="migration-route-panel__list">
        {module.routeNames.map(([method, path]) => (
          <div className="migration-route-panel__item" key={`${method}:${path}`}>
            <span className={`migration-route-panel__method is-${method.toLowerCase()}`}>{method}</span>
            <code>{path}</code>
          </div>
        ))}
      </div>
      <div className="migration-route-panel__warning">
        {module.placeholderSignals
          ? `${module.placeholderSignals} backend placeholder signal(s) remain.`
          : "No placeholder signal detected in the audited source."}
      </div>
    </div>
  );
}
