export const migrationModules = [
  {
    "key": "fees",
    "name": "fees",
    "routeCount": 22,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/FeesDetails.jsx",
      "frontend/src/pages/generated/FeeStructure.jsx"
    ]
  },
  {
    "key": "employee",
    "name": "employee",
    "routeCount": 19,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/EmployeeSearch.jsx",
      "frontend/src/pages/generated/Employee_Index.jsx"
    ]
  },
  {
    "key": "examsetup",
    "name": "examsetup",
    "routeCount": 19,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "student",
    "name": "student",
    "routeCount": 14,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/StudentModule.jsx",
      "frontend/src/services/studentApi.js",
      "frontend/src/pages/generated/Student_MentorAllocation.jsx",
      "frontend/src/pages/generated/ClassStudentWiseSubject.jsx",
      "frontend/src/pages/generated/Student_Index.jsx",
      "frontend/src/pages/generated/StudentLedger.jsx",
      "frontend/src/pages/generated/StudentSearchModal.jsx",
      "frontend/src/pages/generated/StudentAttendanceReport.jsx",
      "frontend/src/pages/generated/StudentReport.jsx",
      "frontend/src/pages/generated/StudentWiseMarksEntry.jsx"
    ]
  },
  {
    "key": "frontdesk",
    "name": "frontdesk",
    "routeCount": 13,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "libraryconfig",
    "name": "libraryconfig",
    "routeCount": 12,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/LibraryConfig_Relaxation.jsx"
    ]
  },
  {
    "key": "master",
    "name": "master",
    "routeCount": 12,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/CounselorMaster.jsx",
      "frontend/src/pages/generated/BookTypeMaster.jsx",
      "frontend/src/pages/generated/ResourceMaster.jsx",
      "frontend/src/pages/generated/IndicatorCategoryMaster.jsx",
      "frontend/src/pages/generated/LevelMaster.jsx",
      "frontend/src/pages/generated/ConductionMaster.jsx",
      "frontend/src/pages/generated/BookMaster.jsx",
      "frontend/src/pages/generated/Master_Index.jsx",
      "frontend/src/pages/generated/ConsultantMaster.jsx",
      "frontend/src/pages/generated/IndicatorMaster.jsx",
      "frontend/src/pages/generated/VoucherMaster.jsx",
      "frontend/src/pages/generated/TimeSlotMaster.jsx",
      "frontend/src/pages/generated/LeaveMaster.jsx",
      "frontend/src/pages/generated/Library_SubjectMaster.jsx",
      "frontend/src/pages/generated/SubSubjectMaster.jsx",
      "frontend/src/pages/generated/SubjectMaster.jsx",
      "frontend/src/pages/generated/DocumentMaster.jsx",
      "frontend/src/pages/generated/GroupMaster.jsx"
    ]
  },
  {
    "key": "academics",
    "name": "academics",
    "routeCount": 11,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "library",
    "name": "library",
    "routeCount": 11,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/Library_SubjectMaster.jsx",
      "frontend/src/pages/generated/LibraryReport_IssueReturn.jsx",
      "frontend/src/pages/generated/LibraryConfig_Relaxation.jsx"
    ]
  },
  {
    "key": "fee",
    "name": "fee",
    "routeCount": 10,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/FeesDetails.jsx",
      "frontend/src/pages/generated/FeeReceipt.jsx",
      "frontend/src/pages/generated/FeeStructure.jsx"
    ]
  },
  {
    "key": "payroll",
    "name": "payroll",
    "routeCount": 10,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/PayrollMonthCreation.jsx",
      "frontend/src/pages/generated/Payroll_Index.jsx"
    ]
  },
  {
    "key": "attendance",
    "name": "attendance",
    "routeCount": 8,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/MonthlyAttendance.jsx",
      "frontend/src/pages/generated/CMarkAttendance.jsx",
      "frontend/src/pages/generated/StudentAttendanceReport.jsx",
      "frontend/src/pages/generated/DeleteAttendance.jsx",
      "frontend/src/pages/generated/CQRAttendance.jsx",
      "frontend/src/pages/generated/MarkAttendance.jsx",
      "frontend/src/pages/generated/ViewAttendance.jsx",
      "frontend/src/pages/generated/CAttendanceReports.jsx"
    ]
  },
  {
    "key": "crm",
    "name": "crm",
    "routeCount": 8,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/CRMDashboard.jsx"
    ]
  },
  {
    "key": "hr",
    "name": "hr",
    "routeCount": 8,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/HRPolicyMapingRpt.jsx",
      "frontend/src/pages/generated/HRMonthCreation.jsx",
      "frontend/src/pages/generated/HR_Index.jsx"
    ]
  },
  {
    "key": "libconfig",
    "name": "libconfig",
    "routeCount": 8,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "report",
    "name": "report",
    "routeCount": 7,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/TCReport.jsx",
      "frontend/src/pages/generated/CTTReports.jsx",
      "frontend/src/pages/generated/CustomReport.jsx",
      "frontend/src/pages/generated/StockReport.jsx",
      "frontend/src/pages/generated/ReportCard.jsx",
      "frontend/src/pages/generated/ReportCert.jsx",
      "frontend/src/pages/generated/DuesReport.jsx",
      "frontend/src/pages/generated/EnquiryReport.jsx",
      "frontend/src/pages/generated/ReceiptReport.jsx",
      "frontend/src/pages/generated/StudentAttendanceReport.jsx",
      "frontend/src/pages/generated/StudentReport.jsx",
      "frontend/src/pages/generated/HeadwiseReport.jsx",
      "frontend/src/pages/generated/CAttendanceReports.jsx",
      "frontend/src/pages/generated/LibraryReport_IssueReturn.jsx",
      "frontend/src/pages/generated/MiscReport.jsx"
    ]
  },
  {
    "key": "assignment",
    "name": "assignment",
    "routeCount": 6,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/ViewAssignment.jsx"
    ]
  },
  {
    "key": "account",
    "name": "account",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "auth",
    "name": "auth",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/Author.jsx"
    ]
  },
  {
    "key": "base",
    "name": "base",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "examreport",
    "name": "examreport",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "feereport",
    "name": "feereport",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "libraryreport",
    "name": "libraryreport",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/LibraryReport_IssueReturn.jsx"
    ]
  },
  {
    "key": "marksentry",
    "name": "marksentry",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/RemarksEntry.jsx",
      "frontend/src/pages/generated/SubjectWiseMarksEntry.jsx",
      "frontend/src/pages/generated/StudentWiseMarksEntry.jsx",
      "frontend/src/pages/generated/MarksEntryPermission.jsx"
    ]
  },
  {
    "key": "payrollreport",
    "name": "payrollreport",
    "routeCount": 5,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "accountreport",
    "name": "accountreport",
    "routeCount": 4,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "libperiodicals",
    "name": "libperiodicals",
    "routeCount": 4,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "transport",
    "name": "transport",
    "routeCount": 4,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/Transport_Index.jsx",
      "frontend/src/pages/generated/TransportForm.jsx"
    ]
  },
  {
    "key": "config",
    "name": "config",
    "routeCount": 3,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/Config_Index.jsx",
      "frontend/src/pages/generated/AdmissionFormatConfig.jsx",
      "frontend/src/pages/generated/LibraryConfig_Relaxation.jsx"
    ]
  },
  {
    "key": "dashboard",
    "name": "dashboard",
    "routeCount": 3,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/CRMDashboard.jsx",
      "frontend/src/pages/generated/Dashboard.jsx",
      "frontend/src/pages/generated/Dashboard_Index.jsx"
    ]
  },
  {
    "key": "home",
    "name": "home",
    "routeCount": 3,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/HomeWork.jsx"
    ]
  },
  {
    "key": "libstock",
    "name": "libstock",
    "routeCount": 3,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "notification",
    "name": "notification",
    "routeCount": 3,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "timetable",
    "name": "timetable",
    "routeCount": 3,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/TimeTableEntry.jsx",
      "frontend/src/pages/generated/TimeTable.jsx",
      "frontend/src/pages/generated/TimeTableSetup.jsx"
    ]
  },
  {
    "key": "configsetting",
    "name": "configsetting",
    "routeCount": 2,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "consultant",
    "name": "consultant",
    "routeCount": 2,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": [
      "frontend/src/pages/generated/ConsultantMaster.jsx"
    ]
  },
  {
    "key": "export",
    "name": "export",
    "routeCount": 1,
    "backendStatus": "UI_BUILD_QUEUE",
    "routes": []
  },
  {
    "key": "baseapi",
    "name": "baseapi",
    "routeCount": 0,
    "backendStatus": "INFRASTRUCTURE",
    "routes": []
  }
];

export function getMigrationModule(key) {
  return migrationModules.find((item) => item.key === key) ?? null;
}
