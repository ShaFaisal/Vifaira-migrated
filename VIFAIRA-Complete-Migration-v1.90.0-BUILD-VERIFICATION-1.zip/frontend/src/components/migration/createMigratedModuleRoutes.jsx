import React from "react";
import MigratedModulePage from "./MigratedModulePage";
import { moduleRouteManifest } from "./moduleRouteManifest";

export function createMigratedModuleRoutes(prefix = "/migration") {
  return moduleRouteManifest.map((item) => ({
    path: `${prefix}/${item.key}`,
    element: <MigratedModulePage moduleName={item.module} />,
  }));
}
