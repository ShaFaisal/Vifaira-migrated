export const moduleRouteManifest = [
  {
    "module": "academics",
    "routes": 11,
    "placeholderSignals": 11,
    "routeNames": [
      "/classteachersetup",
      "/timetablesetup",
      "/resourcemaster",
      "/timeslotmaster",
      "/groupmaster",
      "/subjectallocation",
      "/lecturecancelation",
      "/timetable",
      "/groupallocation",
      "/lessionplan",
      "/reports"
    ]
  },
  {
    "module": "account",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/ledger",
      "/vouchermaster",
      "/vouchersearch",
      "/voucherentry",
      "/voucherupdate"
    ]
  },
  {
    "module": "accountreport",
    "routes": 4,
    "placeholderSignals": 4,
    "routeNames": [
      "/daybook",
      "/ledgerstatement",
      "/trialbalance",
      "/balancesheet"
    ]
  },
  {
    "module": "assignment",
    "routes": 6,
    "placeholderSignals": 6,
    "routeNames": [
      "/uploadassingment",
      "/uploadnotes",
      "/assinghw",
      "/checkhw",
      "/viewassignment",
      "/homework"
    ]
  },
  {
    "module": "attendance",
    "routes": 8,
    "placeholderSignals": 8,
    "routeNames": [
      "/markattendance",
      "/deleteattendance",
      "/attendancemarkingstatus",
      "/attcriteriawise",
      "/facultyattsummary",
      "/viewattendance",
      "/studentattendancereport",
      "/manage"
    ]
  },
  {
    "module": "auth",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/login",
      "/resetpassword",
      "/updateloginstatus",
      "/logout",
      "/checkauth"
    ]
  },
  {
    "module": "base",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/isdropdownloaded",
      "/getdropdownlist",
      "/refreshdropdowns",
      "/getcachestats",
      "/clearcache"
    ]
  },
  {
    "module": "baseapi",
    "routes": 0,
    "placeholderSignals": 0,
    "routeNames": []
  },
  {
    "module": "config",
    "routes": 3,
    "placeholderSignals": 3,
    "routeNames": [
      "/getwebconfig",
      "/smtpconfig",
      "/userrolemanage"
    ]
  },
  {
    "module": "configsetting",
    "routes": 2,
    "placeholderSignals": 2,
    "routeNames": [
      "/userrolemaping",
      "/index"
    ]
  },
  {
    "module": "consultant",
    "routes": 2,
    "placeholderSignals": 2,
    "routeNames": [
      "/consultantmaster",
      "/counselormaster"
    ]
  },
  {
    "module": "crm",
    "routes": 8,
    "placeholderSignals": 8,
    "routeNames": [
      "/enquirysource",
      "/tasktype",
      "/coursewisecounselor",
      "/assignquerye",
      "/crmdashboard",
      "/enquiry",
      "/visitorbook",
      "/crmcommaster"
    ]
  },
  {
    "module": "dashboard",
    "routes": 3,
    "placeholderSignals": 3,
    "routeNames": [
      "/getuserdashord",
      "/getdashboardwidgetdata",
      "/getprofile"
    ]
  },
  {
    "module": "employee",
    "routes": 19,
    "placeholderSignals": 19,
    "routeNames": [
      "/index",
      "/incrementsalary",
      "/hrpolicymapingrpt",
      "/thingstodo",
      "/latecomersrpt",
      "/customrpt",
      "/joinresigndtls",
      "/documentmaster",
      "/emppunch",
      "/flexitimeschedular",
      "/empregularabsentrpt",
      "/inoutstatusrpt",
      "/attsearch",
      "/currleavebal",
      "/empleave",
      "/monthlyattendance",
      "/leavedetails",
      "/monthlybalance",
      "/monthwiseattdetails"
    ]
  },
  {
    "module": "examreport",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/reportcard",
      "/printreportcard",
      "/gradesheet",
      "/studentreport",
      "/classwiserptsetup"
    ]
  },
  {
    "module": "examsetup",
    "routes": 19,
    "placeholderSignals": 19,
    "routeNames": [
      "/subjectmaster",
      "/exammaster",
      "/conductionmaster",
      "/creditpointsetup",
      "/termwisesubject",
      "/termwiseexam",
      "/semesterwiseexammaxmarks",
      "/gradingsetup",
      "/indicatorcategorymaster",
      "/indicatorgrade",
      "/indicatormaster",
      "/indicatorentry",
      "/examdatesheet",
      "/simpleadmitcard",
      "/previewshadmitcard",
      "/classstudentwisesubject",
      "/printorder",
      "/studentsubjectmanagement",
      "/subgroupmanagement"
    ]
  },
  {
    "module": "export",
    "routes": 1,
    "placeholderSignals": 1,
    "routeNames": [
      "/download"
    ]
  },
  {
    "module": "fee",
    "routes": 10,
    "placeholderSignals": 10,
    "routeNames": [
      "/feestructure",
      "/defaultstructure",
      "/applydues",
      "/relaxation",
      "/registrationreceipt",
      "/feereceipt",
      "/refund",
      "/ledger",
      "/feesdetails",
      "/receiptdetails"
    ]
  },
  {
    "module": "feereport",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/duesreport",
      "/studentledger",
      "/miscreport",
      "/dailycollection",
      "/receiptreport"
    ]
  },
  {
    "module": "fees",
    "routes": 22,
    "placeholderSignals": 22,
    "routeNames": [
      "/installmentdatefees",
      "/savefeestrecture",
      "/getfeestrecture",
      "/loaddefaultfeestructdata",
      "/adddefaultfeestructure",
      "/applydue",
      "/saveapplydue",
      "/relaxation",
      "/saverelaxation",
      "/searchrelaxrecord",
      "/cancelrelax",
      "/receiptsummary",
      "/createdue",
      "/createreceipt",
      "/getcancelreceipt",
      "/getreceptmore",
      "/cancelreceipt",
      "/printreceipt",
      "/getrefunddetails",
      "/refundsaverequest",
      "/refundcancel",
      "/printrefund"
    ]
  },
  {
    "module": "frontdesk",
    "routes": 13,
    "placeholderSignals": 13,
    "routeNames": [
      "/consultantmaster",
      "/counselormaster",
      "/insentive",
      "/incentivedetails",
      "/enquirydetails",
      "/tasktype",
      "/coursecounselor",
      "/crmdashboard",
      "/newenquiry",
      "/assignquery",
      "/confirmenquiry",
      "/enquiryreport",
      "/visitorbook"
    ]
  },
  {
    "module": "home",
    "routes": 3,
    "placeholderSignals": 3,
    "routeNames": [
      "/index",
      "/login",
      "/forgotpassword"
    ]
  },
  {
    "module": "hr",
    "routes": 8,
    "placeholderSignals": 8,
    "routeNames": [
      "/index",
      "/employeesearch",
      "/standardtiming",
      "/gaptiming",
      "/manualpunch",
      "/aprovalsetting",
      "/leavemaster",
      "/leavepolicy"
    ]
  },
  {
    "module": "libconfig",
    "routes": 8,
    "placeholderSignals": 8,
    "routeNames": [
      "/booktypemaster",
      "/itemtype",
      "/bookprefix",
      "/finepolicy",
      "/finecategory",
      "/holiday",
      "/status",
      "/applyfine"
    ]
  },
  {
    "module": "libperiodicals",
    "routes": 4,
    "placeholderSignals": 4,
    "routeNames": [
      "/magazinesubscription",
      "/magazinejournal",
      "/newspapersetup",
      "/newspaperentry"
    ]
  },
  {
    "module": "library",
    "routes": 11,
    "placeholderSignals": 11,
    "routeNames": [
      "/subjectmaster",
      "/subsubject",
      "/language",
      "/publisher",
      "/author",
      "/vendor",
      "/gift",
      "/location",
      "/bookmaster",
      "/member",
      "/issuereturn"
    ]
  },
  {
    "module": "libraryconfig",
    "routes": 12,
    "placeholderSignals": 12,
    "routeNames": [
      "/booktypemaster",
      "/itemtype",
      "/bookprefix",
      "/finepolicy",
      "/finesetup",
      "/finecategory",
      "/applyfine",
      "/status",
      "/bookbank",
      "/relaxation",
      "/holiday",
      "/issuebooksetup"
    ]
  },
  {
    "module": "libraryreport",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/opac",
      "/issuereturn",
      "/bookbinding",
      "/bookdetails",
      "/fine"
    ]
  },
  {
    "module": "libstock",
    "routes": 3,
    "placeholderSignals": 3,
    "routeNames": [
      "/periodsetup",
      "/stockverification",
      "/stockreport"
    ]
  },
  {
    "module": "marksentry",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/subjectwisemarksentrty",
      "/studentwisemarksentry",
      "/userpermissionformarksentry",
      "/remarksentry",
      "/assignmentmaster"
    ]
  },
  {
    "module": "master",
    "routes": 12,
    "placeholderSignals": 12,
    "routeNames": [
      "/institute",
      "/batch",
      "/session",
      "/branch",
      "/course",
      "/department",
      "/course",
      "/sessprogallocation",
      "/getmappedsemlist",
      "/sectionmaster",
      "/tcquestionmaster",
      "/admissionformat"
    ]
  },
  {
    "module": "notification",
    "routes": 3,
    "placeholderSignals": 3,
    "routeNames": [
      "/notificationhubnoti",
      "/notificationhubgroup",
      "/markholiday"
    ]
  },
  {
    "module": "payroll",
    "routes": 10,
    "placeholderSignals": 10,
    "routeNames": [
      "/index",
      "/salaryhead",
      "/levelmaster",
      "/hrmonthcreation",
      "/rdledgerbalance",
      "/salarysetup",
      "/payrollmonthcreation",
      "/leaveentry",
      "/salarycalculation",
      "/setpaiddays"
    ]
  },
  {
    "module": "payrollreport",
    "routes": 5,
    "placeholderSignals": 5,
    "routeNames": [
      "/index",
      "/salarydetails",
      "/empdetails",
      "/salaryslip",
      "/headwisereport"
    ]
  },
  {
    "module": "report",
    "routes": 7,
    "placeholderSignals": 7,
    "routeNames": [
      "/duesreport",
      "/studledger",
      "/dailycollection",
      "/receiptreport",
      "/miscreport",
      "/receipthistorydetails",
      "/feesdetails"
    ]
  },
  {
    "module": "student",
    "routes": 14,
    "placeholderSignals": 14,
    "routeNames": [
      "/registration",
      "/admission",
      "/search",
      "/updatestudent",
      "/uploadphoto",
      "/promote",
      "/suffling",
      "/idcard",
      "/idcardpreview",
      "/mentor",
      "/issuetcnso",
      "/printtcnso",
      "/bulktaskmanager",
      "/bulktaskexecute"
    ]
  },
  {
    "module": "timetable",
    "routes": 3,
    "placeholderSignals": 3,
    "routeNames": [
      "/manage",
      "/timetableentrymanage",
      "/timetablesubstitutionmanage"
    ]
  },
  {
    "module": "transport",
    "routes": 4,
    "placeholderSignals": 4,
    "routeNames": [
      "/index",
      "/getlist",
      "/get",
      "/save"
    ]
  }
];

export const getModuleRouteManifest = (moduleName) =>
  moduleRouteManifest.find(
    (item) => item.module.toLowerCase() === String(moduleName || "").toLowerCase()
  ) || null;
