import React from "react";

export default function NotificationMarkHoliday() {
  return (
    <section data-migration-source="Admin/Notification/MarkHoliday">
      <header>
        <h1>MarkHoliday</h1>
        <small>Source: Admin/Notification/MarkHoliday</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
