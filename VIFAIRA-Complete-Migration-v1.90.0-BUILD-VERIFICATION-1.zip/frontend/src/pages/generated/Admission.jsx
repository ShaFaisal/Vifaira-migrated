import React from "react";
import StudentModule from "../StudentModule.jsx";

export default function StudentPage() {
  return <StudentModule operation="admission" />;
}
