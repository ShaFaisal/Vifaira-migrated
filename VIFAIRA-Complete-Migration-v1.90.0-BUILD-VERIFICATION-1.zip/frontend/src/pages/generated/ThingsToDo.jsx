import React from "react";

export default function EmployeeThingsToDo() {
  return (
    <section data-migration-source="Admin/Employee/ThingsToDo">
      <header>
        <h1>ThingsToDo</h1>
        <small>Source: Admin/Employee/ThingsToDo</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
