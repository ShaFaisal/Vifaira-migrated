import React from "react";

export default function HRIndex() {
  return (
    <section data-migration-source="Admin/HR/Index">
      <header>
        <h1>Index</h1>
        <small>Source: Admin/HR/Index</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
