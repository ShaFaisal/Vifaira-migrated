import React from "react";

export default function FrontDeskTaskType() {
  return (
    <section data-migration-source="Admin/FrontDesk/TaskType">
      <header>
        <h1>TaskType</h1>
        <small>Source: Admin/FrontDesk/TaskType</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
