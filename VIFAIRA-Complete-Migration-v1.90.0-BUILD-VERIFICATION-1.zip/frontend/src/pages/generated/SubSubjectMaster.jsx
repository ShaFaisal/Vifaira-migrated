import React from "react";

export default function LibrarySubSubjectMaster() {
  return (
    <section data-migration-source="Admin/Library/SubSubjectMaster">
      <header>
        <h1>SubSubjectMaster</h1>
        <small>Source: Admin/Library/SubSubjectMaster</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
