import React from "react";

export default function ErrorError() {
  return (
    <section data-migration-source="root/Error/Error">
      <header>
        <h1>Error</h1>
        <small>Source: root/Error/Error</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
