import React from "react";

export default function ExamReportReportCard() {
  return (
    <section data-migration-source="Admin/ExamReport/ReportCard">
      <header>
        <h1>ReportCard</h1>
        <small>Source: Admin/ExamReport/ReportCard</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
