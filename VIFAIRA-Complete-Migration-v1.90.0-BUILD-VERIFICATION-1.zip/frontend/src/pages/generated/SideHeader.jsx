import React from "react";

export default function SharedSideHeader() {
  return (
    <section data-migration-source="Admin/Shared/_SideHeader">
      <header>
        <h1>_SideHeader</h1>
        <small>Source: Admin/Shared/_SideHeader</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
