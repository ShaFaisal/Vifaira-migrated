import React from "react";

export default function HomeForgotPassword() {
  return (
    <section data-migration-source="root/Home/ForgotPassword">
      <header>
        <h1>ForgotPassword</h1>
        <small>Source: root/Home/ForgotPassword</small>
      </header>
      <div className="migration-page">
        <p>This React route is structurally mapped from the original MVC view.</p>
        <p className="migration-review">UI markup, page-specific JavaScript and API bindings require the original source files for exact conversion.</p>
      </div>
    </section>
  );
}
