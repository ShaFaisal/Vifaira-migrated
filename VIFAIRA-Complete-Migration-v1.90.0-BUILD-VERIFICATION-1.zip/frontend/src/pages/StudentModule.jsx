import React, { useMemo, useState } from "react";
import { studentRequest } from "../services/studentApi.js";

const operations = {
  registration: { title: "Registration", description: "Student registration workspace", route: "/registration" },
  admission: { title: "Admission", description: "Student admission workspace", route: "/admission" },
  search: { title: "Student Search", description: "Search and inspect student records", route: "/search" },
  updatestudent: { title: "Update Student", description: "Update an existing student record", route: "/updatestudent" },
  uploadphoto: { title: "Student Photo", description: "Upload or update a student photo", route: "/uploadphoto" },
  promote: { title: "Promotion", description: "Student promotion workspace", route: "/promote" },
  suffling: { title: "Student Shuffling", description: "Student class/section shuffling workspace", route: "/suffling" },
  idcard: { title: "ID Card", description: "Student ID card operation", route: "/idcard" },
  idcardpreview: { title: "ID Card Preview", description: "Preview student ID card", route: "/idcardpreview" },
  mentor: { title: "Mentor Allocation", description: "Student mentor allocation workspace", route: "/mentor" },
  issuetcnso: { title: "Issue TC / NSO", description: "Student TC/NSO operation", route: "/issuetcnso" },
  printtcnso: { title: "Print TC / NSO", description: "Print student TC/NSO", route: "/printtcnso" },
  bulktaskmanager: { title: "Bulk Task Manager", description: "Manage supported bulk student tasks", route: "/bulktaskmanager" },
  bulktaskexecute: { title: "Bulk Task Execute", description: "Execute a supported bulk student task", route: "/bulktaskexecute" }
};

const pretty = value => JSON.stringify(value, null, 2);

export default function StudentModule({ operation }) {
  const meta = operations[operation] || operations.search;
  const [payload, setPayload] = useState("{}\n");
  const [response, setResponse] = useState(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState(null);
  const [history, setHistory] = useState([]);
  const [searchText, setSearchText] = useState("");

  const supported = useMemo(() => Boolean(operations[operation]), [operation]);

  async function execute() {
    let body;
    try {
      body = JSON.parse(payload || "{}");
    } catch (error) {
      setStatus({ type: "err", text: "Request payload is not valid JSON." });
      return;
    }
    setBusy(true);
    setStatus(null);
    try {
      const data = await studentRequest(operation, body);
      setResponse(data);
      setHistory(items => [{ at: new Date().toLocaleTimeString(), ok: true }, ...items].slice(0, 8));
      setStatus({ type: "ok", text: "Request completed successfully." });
    } catch (error) {
      setResponse(error.data || { error: error.message });
      setHistory(items => [{ at: new Date().toLocaleTimeString(), ok: false }, ...items].slice(0, 8));
      setStatus({ type: error.status === 501 ? "warn" : "err", text: error.status === 501 ? "UI is wired to the confirmed route, but the current backend still reports this operation as not implemented." : error.message });
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setPayload("{}\n");
    setResponse(null);
    setStatus(null);
  }

  return (
    <div className="page-wrap">
      <div className="page-head">
        <div>
          <div className="eyebrow">Student Management</div>
          <h1 className="page-title">{meta.title}</h1>
          <p className="page-sub">{meta.description}</p>
        </div>
        <span className="route-badge">POST /api/student{meta.route}</span>
      </div>

      <div className="grid">
        <section className="card half">
          <div className="card-head"><div className="card-title">Operation</div><span className="route-badge">{supported ? "CONNECTED" : "UNMAPPED"}</span></div>
          <div className="card-body">
            <div className="metric-row">
              <div className="metric"><b>Student</b><span>Module</span></div>
              <div className="metric"><b>POST</b><span>Transport</span></div>
              <div className="metric"><b>{history.length}</b><span>Requests this session</span></div>
            </div>
            <div className="notice" style={{marginTop:12}}>The UI uses only routes confirmed by the migrated Student route contract. Exact business payload fields remain source-dependent.</div>
            <div className="field" style={{marginTop:14}}>
              <label>Quick context / student reference</label>
              <input value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="Optional reference" />
            </div>
            <div className="actions">
              <button className="primary" onClick={execute} disabled={busy}>{busy ? "Processing…" : "Execute Operation"}</button>
              <button className="secondary" onClick={reset}>Reset</button>
            </div>
            {status && <div className={`status ${status.type}`}>{status.text}</div>}
          </div>
        </section>

        <section className="card half">
          <div className="card-head"><div className="card-title">Request Payload</div><button className="ghost-btn" onClick={() => setPayload(pretty({}))}>Format</button></div>
          <div className="card-body">
            <div className="field"><label>JSON body</label><textarea value={payload} onChange={e => setPayload(e.target.value)} spellCheck="false" /></div>
          </div>
        </section>

        <section className="card half">
          <div className="card-head"><div className="card-title">Response</div></div>
          <div className="card-body">
            {response ? <pre className="response">{pretty(response)}</pre> : <div className="empty">No response yet</div>}
          </div>
        </section>

        <section className="card half">
          <div className="card-head"><div className="card-title">Session Activity</div></div>
          <div className="card-body">
            {history.length ? history.map((item, index) => <div key={`${item.at}-${index}`} className="status" style={{marginTop:index ? 7 : 0}}>{item.at} · {item.ok ? "Success" : "Request returned an error"}</div>) : <div className="empty">No requests in this session</div>}
          </div>
        </section>
      </div>
    </div>
  );
}
