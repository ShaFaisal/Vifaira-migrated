# VIFAIRA Complete Migration — v1.27 CLEAN

This package contains migrated React/Express code only.

## Migration status
- Original MVC/.NET source: excluded
- React frontend: included
- Express backend: included
- Framework/build configuration: preserved only where evidenced by the migrated source
- Business placeholders: not replaced with fabricated logic

See `migration/FRONTEND-STRUCTURE-v1.27.json` for the detected frontend structure.
